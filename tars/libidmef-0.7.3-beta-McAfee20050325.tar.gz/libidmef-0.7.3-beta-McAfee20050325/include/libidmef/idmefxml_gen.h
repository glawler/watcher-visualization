/*
idmefxml_gen.h: header file for libidmef message generation functions
Author: Adam Migus, NAI Labs, (amigus@nai.com)

Copyright (c) 2001 Networks Associates Technology Inc.

This library is released under the GNU GPL and BSD software licenses.
You may choose to use one or the other, BUT NOT BOTH.  The GNU GPL
license is located in the file named COPYING.  The BSD license is located
in the file named COPYING.BSD.  Please contact us if there are any
questions.

$Id: idmefxml_gen.h,v 1.1 2004/07/31 00:43:55 dkindred Exp $
*/

#ifndef _IDMEFXML_GEN_H
#define _IDMEFXML_GEN_H 1

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

xmlDocPtr build_idmef_message_doc(const IDMEFmessage *message, 
                                  int include_doctype, int validate);
xmlChar *generate_idmef_message(const IDMEFmessage *message, int *length_out,
                                int include_doctype, int validate);

xmlNodePtr build_address(const IDMEFaddress *address);
xmlNodePtr build_userid(const IDMEFuserid *userid);
xmlNodePtr build_user(const IDMEFuser *user);
xmlNodePtr build_SNMPservice(const IDMEFSNMPservice *SNMPservice);
xmlNodePtr build_webservice(const IDMEFwebservice *webservice);
xmlNodePtr build_service(const IDMEFservice *service);
xmlNodePtr build_process(const IDMEFprocess *process);
xmlNodePtr build_node(const IDMEFnode *node);
xmlNodePtr build_source(const IDMEFsource *source);
xmlNodePtr build_fileaccess(const IDMEFfileaccess *fileaccess);
xmlNodePtr build_linkage(const IDMEFlinkage *linkage);
xmlNodePtr build_inode(const IDMEFinode *inode);
xmlNodePtr build_checksum(const IDMEFchecksum *checksum);
xmlNodePtr build_file(const IDMEFfile *file);
xmlNodePtr build_filelist(const IDMEFfilelist *filelist);
xmlNodePtr build_target(const IDMEFtarget *target);
xmlNodePtr build_classification(const IDMEFclassification *classification);
xmlNodePtr build_reference(const IDMEFreference *reference);
xmlNodePtr build_analyzer(const IDMEFanalyzer *analyzer);
xmlNodePtr build_impact(const IDMEFimpact *impact);
xmlNodePtr build_action(const IDMEFaction *action);
xmlNodePtr build_confidence(const IDMEFconfidence *confidence);
xmlNodePtr build_assessment(const IDMEFassessment *assessment);
xmlNodePtr build_toolalert(const IDMEFtoolalert *toolalert);
xmlNodePtr build_overflowalert(const IDMEFoverflowalert *overflowalert);
xmlNodePtr build_correlationalert(const IDMEFcorrelationalert *calert);
xmlNodePtr build_additionaldata(const IDMEFadditionaldata *additionaldata);
xmlNodePtr build_alert(const IDMEFalert *alert);
xmlNodePtr build_heartbeat(const IDMEFheartbeat *heartbeat);
xmlNodePtr build_idmef_message(const IDMEFmessage *message);

#ifdef __cplusplus
}      /* end of extern "C" */
#endif /* __cplusplus */

/* Make emacs handle 8-column indentation used in this file:
 * Local Variables:
 * c-basic-offset:8
 * indent-tabs-mode:t
 * tab-width:8
 * End: */

#endif /* _IDMEFXML_GEN_H */
