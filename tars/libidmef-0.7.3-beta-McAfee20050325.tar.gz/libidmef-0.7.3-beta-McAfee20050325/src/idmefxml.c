/************************************************************************
 * libidmef: A library to create IDMEF messages in XML format.
 * Author: Joe McAlerney, Silicon Defense, (joey@SiliconDefense.com)
 *
 * Copyright (c) 2000,2001 by Silicon Defense (http://www.silicondefense.com/)
 * Copyright (c) 2004 Networks Associates Technology, Inc. All rights reserved.
 * 
 * This library is released under the GNU GPL and BSD software licenses.
 * You may choose to use one or the other, BUT NOT BOTH.  The GNU GPL
 * license is located in the file named COPYING.  The BSD license is located
 * in the file named COPYING.BSD.  Please contact us if there are any
 * questions.
 **************************************************************************/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include <stdio.h>
#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#endif
#ifdef HAVE_STDARG_H
#include <stdarg.h>
#endif
#ifdef HAVE_STRING_H
#include <string.h>
#endif
#ifdef HAVE_STRINGS_H
#include <strings.h>
#endif
#include <math.h>
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#if TIME_WITH_SYS_TIME
# include <sys/time.h>
# include <time.h>
#else
# if HAVE_SYS_TIME_H
#  include <sys/time.h>
# else
#  include <time.h>
# endif
#endif

#include <libxml/tree.h>
#include <libxml/xmlmemory.h>
#include <libxml/parser.h>
#include <libxml/valid.h>
#include <libxml/entities.h>
#include <libxml/debugXML.h>
#include <libxml/xmlIO.h>
#include <libxml/xmlerror.h>

#include <libidmef/idmefxml_global.h>
#include <libidmef/idmefxml.h>

/* static functions */

static void *idmef_malloc_default(void *arg, size_t size);
static void *idmef_realloc_default(void *arg, void *ptr, size_t size);
static void idmef_free_default(void *arg, void *ptr);

static void idmef_log_default(void *arg, int level, const char *fmt, 
                              va_list ap);


/* The config is global for now, but should probably be passed around
 * everywhere so we can support multiple configs in the same process.
 * But it would probably be easier to convert to C++ at that point.
 */
static IDMEFlib_config *idmef_config;


/* xmlNodeGetContent() expands entity references, but xmlNodeSetContent()
 * doesn't encode them (bug?).  This function will encode entities and
 * then set content.  Note that xmlSetProp() encodes entities automatically.
 */
static void
encodeAndSetContent(xmlNodePtr node, const xmlChar *raw_content)
{
  xmlChar *encoded_content = xmlEncodeEntitiesReentrant(NULL, raw_content);
  xmlNodeSetContent(node, encoded_content);
  xmlFree(encoded_content);
}

/*************************************************************************
 * With the exception of newSimpleElement, each of these "new" functions 
 * accepts an xmlNodePtr, and a variable list of parameters, which should be
 * xmlNodePtrs as well.  The parameters must be passed in the order specified
 * by the DTD.  The functions will check to see if all required parameters 
 * were passed.  If not, it will return NULL.  Possible parameters are
 * displayed above the functions.
 *
 * Notes: At least ONE parameter is required in each function.  This parameter
 *        is labled 'first'. 
 *
 *        You must pass NULL in as the last argument. This is to let the 
 *        function know when to quit reading in arguments.  Failure to do this
 *        will result in "undefined behavior".
 *************************************************************************/
 
/*********************************************************************
 *********************************************************************
 *****								 *****
 *****			The Message Classes			 *****
 *****								 *****
 *********************************************************************
 *********************************************************************/

/*==================================================================
 * Name: newIDMEF_Message
 *
 * Declaration: xmlNodePtr newIDMEF_Message(xmlNodePtr, ...);
 *
 * Possible parameters:
 *
 *   ATTRIBUTES
 *   xmlNodePtr version: optional
 *
 *   SUB-ELEMENTS
 *   xmlNodePtr Alert    : zero or more
 *   xmlNodePtr Heartbeat: zero or more
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the root element
 *
 * Example:
 *	    if(newIDMEF_Message(theAlert, NULL))
 *              printCurrentMessage(stdout);
 *===================================================================*/

xmlNodePtr newIDMEF_Message(xmlNodePtr first, ...)
{
  xmlNodePtr p, theRoot;
  va_list ap;
  xmlChar *tmp_content = NULL;

  theRoot = xmlNewNode(NULL,"IDMEF-Message");
  
  /* Set the IDMEF Version attribute */
  xmlSetProp(theRoot, "version", IDMEF_MESSAGE_VERSION);

  if(first == NULL) /* do we have at least one parameter? */
    return theRoot;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);
       
     switch(*(p->name))
     {
          case 'v':
          if(strcmp(p->name, "version") == 0)
	  {   
 	     xmlSetProp(theRoot, "version", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"IDMEF-Message");
          break;
        case 'A':
          if(strcmp(p->name, "Alert") == 0)
  	    xmlAddChild(theRoot, p);
          else
            badNode(p,"IDMEF-Message");
          break;
        case 'H':
          if(strcmp(p->name, "Heartbeat") == 0)
 	     xmlAddChild(theRoot, p);
          else
            badNode(p,"IDMEF-Message");
          break;
        default:
          badNode(p,"IDMEF-Message");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(theRoot);
}

/*==================================================================
 * Name: newAlert
 *
 * Declaration: xmlNodePtr newAlert(xmlNodePtr, ...);
 *
 * Possible parameters:
 * 
 *   ATTRIBUTES
 *   xmlNodePtr ident  : optional
 +
 *   SUB-ELEMENTS
 *   xmlNodePtr Analyzer        : exactly one
 *   xmlNodePtr CreateTime      : exactly one
 *   xmlNodePtr DetectTime      : zero or one
 *   xmlNodePtr AnalyzerTime    : zero or one
 *   xmlNodePtr Source          : zero or more
 *   xmlNodePtr Target          : zero or more
 *   xmlNodePtr Classification  : exactly one
 +   xmlNodePtr Assessment      : zero or one
 *   xmlNodePtr ToolAlert       : zero or one
 *   xmlNodePtr OverflowAlert   : zero or one
 *   xmlNodePtr CorrelationAlert: zero or one
 *   xmlNodePtr AdditionalData  : zero or more
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created Alert node.
 *
 * Example:
 *	    xmlNodePtr theAlert = newAlert(myidentd, myCreateTime,
 *                                         myAnalyzer,myClassification,
 *                                         mySource,myTarget, NULL);
 *
 *===================================================================*/

xmlNodePtr newAlert(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"Alert");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newAlert(): xmlNewNode(NULL,\"Alert\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;
       
     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
        case 'm':
	  if(strcmp(p->name, "messageid") == 0)
	  {
	      xmlSetProp(cur, "messageid", tmp_content);
	      xmlFreeNode(p);
	   }         
	   else
	      badNode(p,"Alert");
           break;
        case 'T':
          switch(*(p->name + 1))
	  {
   	     case 'a':
               if(strcmp(p->name, "Target") == 0)
  	          xmlAddChild(cur, p);
               else
                  badNode(p,"Alert");
               break;
     	     case 'o':
               if(strcmp(p->name, "ToolAlert") == 0)
	       {
   	         /* check to see if an alert subclass already exists */
		 if(hasElement(cur,"CorrelationAlert") ||
                    hasElement(cur,"OverflowAlert") ||
                    hasElement(cur,"ToolAlert"))
		 {
		   idmef_error("idmefxml.c: DTD Violation - Parent Alert already contains a CorrelationAlert, OverflowAlert, or ToolAlert");
                   xmlFree(p);
                 }
                 else
  	          xmlAddChild(cur, p);
               }
               else
                  badNode(p,"Alert");
               break;
  	     default:
               badNode(p,"Alert");
	  }
          break;
        case 'A':
          switch(*(p->name + 1))
	  {
	     case 'n':   /* Analyzer or AnalyzerTime */
               if((strcmp(p->name, "Analyzer") == 0) ||
		  (strcmp(p->name, "AnalyzerTime") == 0)) 
  	          xmlAddChild(cur, p);
               else
                  badNode(p,"Alert");
               break;
     	     case 'd':
               if(strcmp(p->name, "AdditionalData") == 0)
  	          xmlAddChild(cur, p);
               else
                  badNode(p,"Alert");
               break;
     	     case 's':
               if(strcmp(p->name, "Assessment") == 0)
  	          xmlAddChild(cur, p);
               else
                  badNode(p,"Alert");
               break;
    	     default:
               badNode(p,"Alert");   
          }
          break;
        case 'C':
          switch(*(p->name + 1))
	  {
     	     case 'l':
               if(strcmp(p->name, "Classification") == 0)
  	          xmlAddChild(cur, p);
               else
                  badNode(p,"Alert");
               break;
     	     case 'o':
               if(strcmp(p->name, "CorrelationAlert") == 0)
	       {
   	         /* check to see if an alert subclass already exists */
		 if(hasElement(cur,"CorrelationAlert") ||
                    hasElement(cur,"OverflowAlert") ||
                    hasElement(cur,"ToolAlert"))
		 {
		   idmef_error("idmefxml.c: DTD Violation - Parent Alert already contains a CorrelationAlert, OverflowAlert, or ToolAlert");
                   xmlFree(p);
                 }
                 else
  	          xmlAddChild(cur, p);
               }
               else
                  badNode(p,"Alert");
               break;
     	     case 'r':
               if(strcmp(p->name, "CreateTime") == 0)
  	          xmlAddChild(cur, p);
               else
                  badNode(p,"Alert");
               break;
    	     default:
               badNode(p,"Alert");   
          }
          break;
        case 'D':
          if(strcmp(p->name, "DetectTime") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"Alert");
          break;
        case 'S':
          if(strcmp(p->name, "Source") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"Alert");
          break;
        case 'O':
          if(strcmp(p->name, "OverflowAlert") == 0)
	  {
 	     /* check to see if an alert subclass already exists */
	     if(hasElement(cur,"CorrelationAlert") ||
                hasElement(cur,"OverflowAlert") ||
                hasElement(cur,"ToolAlert"))
	     {
	       idmef_error("idmefxml.c: DTD Violation - Parent Alert already contains a CorrelationAlert, OverflowAlert, or ToolAlert");
               xmlFree(p);
             }
             else
               xmlAddChild(cur, p);
          }
          else
            badNode(p,"Alert");
          break;
        default:
          badNode(p,"Alert");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);
}

/*==================================================================
 * Name: newToolAlert
 *
 * Declaration: xmlNodePtr newToolAlert(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   SUB-ELEMENTS
 *   xmlNodePtr name      : exactly one
 *   xmlNodePtr command   : zero or more
 *   xmlNodePtr alertident: one or more
 *
 * !Remember!: the last argument must be NULL.
 *===================================================================*/

xmlNodePtr newToolAlert(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;

  cur = xmlNewNode(NULL,"ToolAlert");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newToolAlert: xmlNewNode(NULL,\"ToolAlert\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     switch(*(p->name))
     {
        case 'n': /* name */
          if(strcmp(p->name, "name") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"ToolAlert");
          break;
        case 'c': /* command */
          if(strcmp(p->name, "command") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"ToolAlert");
          break;
        case 'a': /* alertident */
          if(strcmp(p->name, "alertident") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"ToolAlert");
          break;
        default:
          badNode(p,"ToolAlert");
     }
  }
  va_end(ap);

  return(cur);
}

/*==================================================================
 * Name: newCorrelationAlert
 *
 * Declaration: xmlNodePtr newCorrelationAlert(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   SUB-ELEMENTS
 *   xmlNodePtr name      : exactly one
 *   xmlNodePtr alertident: one or more
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created CorrelationAlert node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newCorrelationAlert(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;

  cur = xmlNewNode(NULL,"CorrelationAlert");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newCorrelationAlert: xmlNewNode(NULL,\"CorrelationAlert\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     switch(*(p->name))
     {
        case 'n': /* name */
          if(strcmp(p->name, "name") == 0)
       	    xmlAddChild(cur, p);
          else
            badNode(p,"CorrelationAlert");
          break;
        case 'a': /* alertident */
          if(strcmp(p->name, "alertident") == 0)
       	    xmlAddChild(cur, p);
          else
            badNode(p,"CorrelationAlert");
          break;
        default:
          badNode(p,"CorrelationAlert");
     }
  }
  va_end(ap);

  return(cur);
}

/*==================================================================
 * Name: newOverflowAlert
 *
 * Declaration: xmlNodePtr newOverflowAlert(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   SUB-ELEMENTS
 *   xmlNodePtr program: exactly one
 *   xmlNodePtr size   : zero or one
 *   xmlNodePtr buffer : zero or one
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created OverflowAlert node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newOverflowAlert(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;

  cur = xmlNewNode(NULL,"OverflowAlert");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newOverflowAlert: xmlNewNode(NULL,\"OverflowAlert\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     switch(*(p->name))
     {
        case 'p': /* program */
          if(strcmp(p->name, "program") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"OverflowAlert");
          break;
        case 's': /* size */
          if(strcmp(p->name, "size") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"OverflowAlert");
          break;
        case 'b': /* buffer */
          if(strcmp(p->name, "buffer") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"OverflowAlert");
          break;
        default:
          badNode(p,"OverflowAlert");
     }
  }
  va_end(ap);

  return(cur);
}

/*==================================================================
 * Name: newHeartbeat
 *
 * Declaration: xmlNodePtr newHeartbeat(xmlNodePtr, ...);
 *
 * Possible parameters:
 * 
 *   ATTRIBUTES
 *   xmlNodePtr ident: optional
 *
 *   SUB-ELEMENTS
 *   xmlNodePtr Analyzer        : exactly one
 *   xmlNodePtr CreateTime      : exactly one
 *   xmlNodePtr AnalyzerTime    : zero or one
 *   xmlNodePtr AdditionalData  : zero or more
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created Heartbeat node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newHeartbeat(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"Heartbeat");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newHeartbeat(): xmlNewNode(NULL,\"Heartbeat\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
  	case 'm': /* messageid */
          if(strcmp(p->name, "messageid") == 0)
	  {
 	     xmlSetProp(cur, "messageid", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"Heartbeat");
          break;
        case 'C': /* CreateTime */
          if(strcmp(p->name, "CreateTime") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"Heartbeat");
          break;
        case 'A':
          switch(*(p->name + 1))
	  {
	     case 'n':   /* Analyzer or AnalyzerTime */
               if((strcmp(p->name, "Analyzer") == 0) ||
		  (strcmp(p->name, "AnalyzerTime") == 0)) 
  	          xmlAddChild(cur, p);
               else
                  badNode(p,"Alert");
               break;
     	     case 'd':
               if(strcmp(p->name, "AdditionalData") == 0)
  	          xmlAddChild(cur, p);
               else
                  badNode(p,"Alert");
               break;
    	     default:
               badNode(p,"Alert");   
          }
          break;
        default:
          badNode(p,"Heartbeat");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);
}

/*********************************************************************
 *********************************************************************
 *****								 *****
 *****			The Core Classes			 *****
 *****								 *****
 *********************************************************************
 *********************************************************************/

/*==================================================================
 * Name: newAnalyzer
 *
 * Declaration: xmlNodePtr newAnalyzer(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   ATTRIBUTES
 *   xmlNodePtr analyzerid  : optional (but see spec)
 *   xmlNodePtr manufacturer: optional
 *   xmlNodePtr model       : optional
 *   xmlNodePtr version     : optional
 *   xmlNodePtr class       : optional
 *   xmlNodePtr ostype      : optional
 *   xmlNodePtr osversion   : optional
 *
 *
 *   SUB-ELEMENTS
 *   xmlNodePtr Node   : zero or one
 *   xmlNodePtr Process: zero or one
 *   xmlNodePtr Analyzer: zero or one
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created Analyzer node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newAnalyzer(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"Analyzer");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newAnalyzer: xmlNewNode(NULL,\"Analyzer\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
        case 'a': /* analyzerid */
          if(strcmp(p->name, "analyzerid") == 0)
	  {
 	     xmlSetProp(cur, "analyzerid", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"Analyzer");
          break;
        case 'c': /* class */
          if(strcmp(p->name, "class") == 0)
	  {
 	     xmlSetProp(cur, "class", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"Analyzer");
          break;
        case 'm':
          switch(*(p->name + 1))
	  {
 	     case 'a':   /* manufacturer */
               if((strcmp(p->name, "manufacturer") == 0)) 
    	          xmlSetProp(cur, "manufacturer", tmp_content);
               else
                  badNode(p,"Analyzer");
               break;
	     case 'o':   /* model */
               if(strcmp(p->name, "model") == 0)
    	          xmlSetProp(cur, "model", tmp_content);
               else
                  badNode(p,"Analyzer");
               break;
    	     default:
               badNode(p,"Analyzer");   
          }
          break;
        case 'n': /* name */
          if(strcmp(p->name, "name") == 0)
	  {
 	     xmlSetProp(cur, "name", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"Analyzer");
          break;
        case 'o':
          switch(*(p->name + 2))
	  {
 	     case 't':   /* ostype */
               if((strcmp(p->name, "ostype") == 0)) 
    	          xmlSetProp(cur, "ostype", tmp_content);
               else
                  badNode(p,"Analyzer");
               break;
	     case 'v':   /* osversion */
               if(strcmp(p->name, "osversion") == 0)
    	          xmlSetProp(cur, "osversion", tmp_content);
               else
                  badNode(p,"Analyzer");
               break;
    	     default:
               badNode(p,"Analyzer");   
          }
          break;
        case 'v': /* version */
          if(strcmp(p->name, "version") == 0)
	  {
 	     xmlSetProp(cur, "version", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"Analyzer");
          break;
        case 'N': /* Node */
	  if(strcmp(p->name, "Node") == 0)
	    xmlAddChild(cur, p);
          else
	    badNode(p,"Analyzer");
          break;
        case 'P': /* Process */
          if(strcmp(p->name, "Process") == 0)
       	    xmlAddChild(cur, p);
          else
            badNode(p,"Analyzer");
          break;
        case 'A': /* Analyzer */
          if(strcmp(p->name, "Analyzer") == 0)
       	    xmlAddChild(cur, p);
          else
            badNode(p,"Analyzer");
          break;
        default:
          badNode(p,"Analyzer");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);
}

/*==================================================================
 * Name: newClassification
 *
 * Declaration: xmlNodePtr newClassification(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   ATTRIBUTES
 *   xmlNodePtr ident: optional
 *   xmlNodePtr text:  required
 *
 *   SUB-ELEMENTS
 *   xmlNodePtr reference: zero or more
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created Classification node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newClassification(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"Classification");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newClassification: xmlNewNode(NULL,\"Classification\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
        case 'i': /* ident */
          if(strcmp(p->name, "ident") == 0)
	  {
 	     xmlSetProp(cur, "ident", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"Classification");
          break;
        case 't': /* text */
          if(strcmp(p->name, "text") == 0)
	  {
 	     xmlSetProp(cur, "text", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"Classification");
          break;
        case 'R': /* Reference */
          if(strcmp(p->name, "Reference") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"Classification");
          break;
        default:
          badNode(p,"Classification");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);
}

/*==================================================================
 * Name: newReference
 *
 * Declaration: xmlNodePtr newReference(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   ATTRIBUTES
 *   xmlNodePtr origin: required
 *
 *   SUB-ELEMENTS
 *   xmlNodePtr name: exactly one
 *   xmlNodePtr url : exactly one
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created Reference node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newReference(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"Reference");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newReference: xmlNewNode(NULL,\"Reference\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
        case 'o': /* origin */
          if(strcmp(p->name, "origin") == 0)
	  {
 	     xmlSetProp(cur, "origin", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"Reference");
          break;
        case 'm': /* meaning */
          if(strcmp(p->name, "meaning") == 0)
	  {
 	     xmlSetProp(cur, "meaning", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"Reference");
          break;
        case 'n': /* name */
          if(strcmp(p->name, "name") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"Reference");
          break;
        case 'u': /* url */
          if(strcmp(p->name, "url") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"Reference");
          break;
        default:
          badNode(p,"Reference");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);
}

/*==================================================================
 * Name: newSource
 *
 * Declaration: xmlNodePtr newSource(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   ATTRIBUTES
 *   xmlNodePtr ident  : optional
 *   xmlNodePtr spoofed: optional
 *
 *   SUB-ELEMENTS
 *   xmlNodePtr Node   : zero or one
 *   xmlNodePtr User   : zero or one
 *   xmlNodePtr Process: zero or one
 *   xmlNodePtr Service: zero or one
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created Source node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newSource(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"Source");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newSource: xmlNewNode(NULL,\"Source\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
        case 'i': /* ident */
	  if(strcmp(p->name, "ident") == 0)
	  {
	    xmlSetProp(cur, "ident", tmp_content);
	    xmlFreeNode(p);
	  }
	  else
	    badNode(p,"Source");
	  break;
        case 's': /* spoofed */
	  if(strcmp(p->name, "spoofed") == 0)
	  {
	    xmlSetProp(cur, "spoofed", tmp_content);
	    xmlFreeNode(p);
	  }
	  else
	    badNode(p,"Source");
	  break;
        case 'N': /* Node */
	  if(strcmp(p->name, "Node") == 0)
	    xmlAddChild(cur, p);
          else
	    badNode(p,"Source");
          break;
        case 'U': /* User */
	  if(strcmp(p->name, "User") == 0)
	    xmlAddChild(cur, p);
          else
	    badNode(p,"Source");
          break;
        case 'P': /* Process */
          if(strcmp(p->name, "Process") == 0)
       	    xmlAddChild(cur, p);
          else
            badNode(p,"Source");
          break;
        case 'S': /* Service */
          if(strcmp(p->name, "Service") == 0)
       	    xmlAddChild(cur, p);
          else
            badNode(p,"Source");
          break;
        default:
          badNode(p,"Source");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);
}

/*==================================================================
 * Name: newTarget
 *
 * Declaration: xmlNodePtr newTarget(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   ATTRIBUTES
 *   xmlNodePtr ident: optional
 *   xmlNodePtr decoy: optional
 *
 *   SUB-ELEMENTS
 *   xmlNodePtr Node    : zero or one
 *   xmlNodePtr User    : zero or one
 *   xmlNodePtr Process : zero or one
 *   xmlNodePtr Service : zero or one
 *   xmlNodePtr FileList: zero or one
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created Target node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newTarget(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"Target");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newTarget: xmlNewNode(NULL,\"Target\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
  	case 'i': /* ident */
          if(strcmp(p->name, "ident") == 0)
	  {
	     xmlSetProp(cur, "ident", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"Target");
          break;
	case 'd': /* decoy */
	  if(strcmp(p->name, "decoy") == 0)
	  {
	     xmlSetProp(cur, "decoy", tmp_content);
             xmlFreeNode(p);
          }
	  else
	    badNode(p,"Target");
	  break;
        case 'N': /* Node */
	  if(strcmp(p->name, "Node") == 0)
	    xmlAddChild(cur, p);
          else
	    badNode(p,"Target");
          break;
        case 'U': /* User */
	  if(strcmp(p->name, "User") == 0)
	    xmlAddChild(cur, p);
          else
	    badNode(p,"Target");
          break;
        case 'P': /* Process */
          if(strcmp(p->name, "Process") == 0)
       	    xmlAddChild(cur, p);
          else
            badNode(p,"Target");
          break;
        case 'S': /* Service */
          if(strcmp(p->name, "Service") == 0)
       	    xmlAddChild(cur, p);
          else
            badNode(p,"Target");
          break;
        case 'F': /* FileList */
          if(strcmp(p->name, "FileList") == 0)
       	    xmlAddChild(cur, p);
          else
            badNode(p,"Target");
          break;
        default:
          badNode(p,"Target");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);
}

/*==================================================================
 * Name: newAssessment
 *
 * Declaration: xmlNodePtr newAssessment(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   SUB-ELEMENTS
 *   xmlNodePtr Impact    : zero or one
 *   xmlNodePtr Action    : zero or more
 *   xmlNodePtr Confidence: zero or one
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created Assessment node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newAssessment(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"Assessment");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newAssessment: xmlNewNode(NULL,\"Assessment\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
        case 'I': /* Impact */
	  if(strcmp(p->name, "Impact") == 0)
	    xmlAddChild(cur, p);
          else
	    badNode(p,"Assessment");
          break;
        case 'A': /* Action */
	  if(strcmp(p->name, "Action") == 0)
	    xmlAddChild(cur, p);
          else
	    badNode(p,"Assessment");
          break;
        case 'C': /* Confidence */
          if(strcmp(p->name, "Confidence") == 0)
       	    xmlAddChild(cur, p);
          else
            badNode(p,"Assessment");
          break;
        default:
          badNode(p,"Assessment");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);
}

/*==================================================================
 * Name: newAdditionalData
 *
 * Declaration: xmlNodePtr newAdditionalData(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   ATTRIBUTES
 *   xmlNodePtr type   : required
 *   xmlNodePtr meaning: optional
 *
 *   VALUE
 *   xmlNodePtr value: exactly one (the additional data)
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created AdditionalData node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newAdditionalData(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"AdditionalData");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newAdditionalData: xmlNewNode(NULL,\"AdditionalData\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
        case 'm': /* meaning */
          if(strcmp(p->name, "meaning") == 0)
	  {
 	     xmlSetProp(cur, "meaning", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"AdditionalData");
          break;
        case 't': /* type */
          if(strcmp(p->name, "type") == 0)
	  {
 	     xmlSetProp(cur, "type", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"AdditionalData");
          break;
        case 'v': /* value */
          if(strcmp(p->name, "value") == 0)
	  {
  	     encodeAndSetContent(cur, tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"AdditionalData");
          break;
        case 'x': /* xml */
          if(strcmp(p->name, "xml") == 0)
	  {
            if (p->children)
            {
              xmlAddChildList(cur, p->children);
              p->children = NULL;
            }
            xmlFreeNode(p);
          }
          else
            badNode(p,"AdditionalData");
          break;
        default:
          badNode(p,"AdditionalData");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);

}

/*********************************************************************
 *********************************************************************
 *****								 *****
 *****			The Time Classes			 *****
 *****								 *****
 *********************************************************************
 *********************************************************************/

/*==================================================================
 * Name: newTime
 *
 * Declaration: xmlNodePtr newTime(const char *name, struct timeval *,
 *                                 const char *ntpstamp, const char *datetime)
 *
 * parameter 
 * 
 *   const char *name : The name of the containing XML element (e.g.,
 *                      "CreateTime")
 *   struct timeval * : If provided, the timeval will be used to create the
 *                      ntpstamp and DATETIME.  NULL must be passed in if
 *                      the newTime function is to create the ntpstamp
 *                      and DATETIME itself.
 *   const char *ntpstamp : Optional ntpstamp string to use (if NULL, will
 *                          be generated from the timeval.
 *   const char *datetime : Optional datetime string to use (if NULL, will
 *                          be generated from the timeval.
 *
 * Returns: an xmlNodePtr to the newly created Time node.
 *
 * Example: xmlNodePtr createTime =  newTime("CreateTime",NULL);
 *          xmlNodePtr createTime2 = newTime("CreateTime",&mytimeval);
 *                                                             
 *===================================================================*/

xmlNodePtr newTime(const char *name, const struct timeval *tv_arg,
                   const char *ntpstamp, const char *datetime)
{
  xmlNodePtr cur;
  struct timeval currtv;
  char *new_ntpstamp = NULL, *new_datetime = NULL;

  cur = xmlNewNode(NULL,name);
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newTime: xmlNewNode(NULL,\"%s\") failed",
            name);
    return NULL;
  }

  /* Create the ntpstamp and datetime strings.  If a timeval argument
     was provided, use it.  Otherwise, create a new one. */

  if(tv_arg != NULL)         /* timeval parameter provided */
  {
    currtv = *tv_arg;
  }
  else                       /* timeval was not provided, get current time */
  {
    gettimeofday(&currtv,0);
    /* force ntpstamp and datetime to be regenerated */
    ntpstamp = NULL;
    datetime = NULL;
  }
  
  /* if ntpstamp or datetime is not provided (or looks blank), regenerate */
  if (ntpstamp == NULL || strncmp(ntpstamp, "0x", 2) != 0)
    ntpstamp = new_ntpstamp = timevalToNtpTimestamp(&currtv);
  if (datetime == NULL || strchr(datetime, 'T') == NULL)
    datetime = new_datetime = timevalToDatetime(&currtv);
  
  /* Set the ntpstamp attribute, and DATETIME value */
  
  xmlSetProp(cur, "ntpstamp", ntpstamp);
  if (new_ntpstamp) xmlFree(new_ntpstamp);
  
  encodeAndSetContent(cur, datetime);
  if (new_datetime) xmlFree(new_datetime);

  return(cur);
}


/*==================================================================
 * Name: newCreateTime, newAnalyzerTime, newDetectTime
 *
 * Declaration: xmlNodePtr new*Time(struct timeval *, 
 *                                  const char *, const char *);
 *
 * parameter 
 * 
 *   struct timeval * : If provided, the timeval will be used to create the
 *                      ntpstamp and DATETIME.  NULL must be passed in if
 *                      the newCreateTime function is to create the ntpstamp
 *                      and DATETIME itself.
 *   const char *ntpstamp : Optional ntpstamp string to use (if NULL, will
 *                          be generated from the timeval.
 *   const char *datetime : Optional datetime string to use (if NULL, will
 *                          be generated from the timeval.
 *
 * Returns: an xmlNodePtr to the newly created CreateTime/DetectTime/
 *          AnalyzerTime node.
 *
 * Example: xmlNodePtr createTime =  newCreateTime(NULL);
 *          xmlNodePtr createTime2 = newCreateTime(&mytimeval); // use provided
 *                                                             
 *===================================================================*/

xmlNodePtr newCreateTime(const struct timeval *tv_arg, 
                         const char *ntpstamp, const char *datetime)
{
    return newTime("CreateTime", tv_arg, ntpstamp, datetime);
}

xmlNodePtr newAnalyzerTime(const struct timeval *tv_arg, 
                           const char *ntpstamp, const char *datetime)
{
    return newTime("AnalyzerTime", tv_arg, ntpstamp, datetime);
}

xmlNodePtr newDetectTime(const struct timeval *tv_arg, 
                         const char *ntpstamp, const char *datetime)
{
    return newTime("DetectTime", tv_arg, ntpstamp, datetime);
}

/*********************************************************************
 *********************************************************************
 *****								 *****
 *****			The Support Classes			 *****
 *****								 *****
 *********************************************************************
 *********************************************************************/

/*==================================================================
 * Name: newNode
 *
 * Declaration: xmlNodePtr newNode(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   ATTRIBUTES
 *   xmlNodePtr ident   : optional
 *   xmlNodePtr category: optional
 *
 *   SUB-ELEMENTS
 *   xmlNodePtr location: zero or one
 *   xmlNodePtr name    : zero or one
 *   xmlNodePtr Address : zero or more
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created Node node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newNode(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"Node");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newNode: xmlNewNode(NULL,\"Node\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
        case 'i': /* ident */
          if(strcmp(p->name, "ident") == 0)
	  {
 	     xmlSetProp(cur, "ident", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"Node");
          break;
        case 'c': /* category */
          if(strcmp(p->name, "category") == 0)
	  {
 	     xmlSetProp(cur, "category", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"Node");
          break;
        case 'n': /* name */
          if(strcmp(p->name, "name") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"Node");
          break;
        case 'l': /* location */
          if(strcmp(p->name, "location") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"Node");
          break;
        case 'A': /* Address */
          if(strcmp(p->name, "Address") == 0)
            xmlAddChild(cur,p);
          else
            badNode(p,"Node");
          break;
        default:
          badNode(p,"Node");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);
}

/*==================================================================
 * Name: newAddress
 *
 * Declaration: xmlNodePtr newAddress(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   ATTRIBUTES
 *   xmlNodePtr ident    : optional
 *   xmlNodePtr category : optional
 *   xmlNodePtr vlan-name: optional
 *   xmlNodePtr vlan-num : optional
 *
 *   SUB-ELEMENTS
 *   xmlNodePtr address: exactly one
 *   xmlNodePtr netmask: zero or one
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created Address node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newAddress(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"Address");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newAddress: xmlNewNode(NULL,\"Address\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
        case 'i': /* ident */
          if(strcmp(p->name, "ident") == 0)
	  {
 	     xmlSetProp(cur, "ident", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"Address");
          break;
        case 'c': /* category */
          if(strcmp(p->name, "category") == 0)
	  {
 	     xmlSetProp(cur, "category", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"Address");
          break;
        case 'v': /* vlan-name & vlan-num */
          switch(*(p->name + 6))
	  {
	      case 'a': /* vlan-name */
                 if(strcmp(p->name, "vlan-name") == 0)
	         {
 	            xmlSetProp(cur, "vlan-name", tmp_content);
                    xmlFreeNode(p);
                 }
                 else
                    badNode(p,"Address");
                 break;
	      case 'u': /* vlan-num */
                 if(strcmp(p->name, "vlan-num") == 0)
	         {
 	            xmlSetProp(cur, "vlan-num", tmp_content);
                    xmlFreeNode(p);
                 }
                 else
                    badNode(p,"Address");
                 break;
	      default:
	 	 badNode(p,"Address");
          }
          break;
        case 'a': /* address */
          if(strcmp(p->name, "address") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"Address");
          break;
        case 'n': /* netmask */
          if(strcmp(p->name, "netmask") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"Address");
          break;
        default:
          badNode(p,"Address");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);

}

/*==================================================================
 * Name: newUser
 *
 * Declaration: xmlNodePtr newUser(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   ATTRIBUTES
 *   xmlNodePtr ident   : optional
 *   xmlNodePtr category: optional
 *
 *   SUB-ELEMENTS
 *   xmlNodePtr UserId: one or more
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created User node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newUser(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"User");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newUser: xmlNewNode(NULL,\"User\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
        case 'i': /* ident */
          if(strcmp(p->name, "ident") == 0)
	  {
 	     xmlSetProp(cur, "ident", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"User");
          break;
        case 'c': /* category */
          if(strcmp(p->name, "category") == 0)
	  {
 	     xmlSetProp(cur, "category", tmp_content);
             xmlFreeNode(p);
          }          
          else
            badNode(p,"User");
          break;
        case 'U': /* UserId */
	  if(strcmp(p->name, "UserId") == 0)
	    xmlAddChild(cur, p);
          else
	    badNode(p,"User");
          break;
        default:
          badNode(p,"User");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);
}

/*==================================================================
 * Name: newUserId
 *
 * Declaration: xmlNodePtr newUserId(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   ATTRIBUTES
 *   xmlNodePtr ident: optional
 *   xmlNodePtr type : optional
 *
 *   SUB-ELEMENTS
 *   xmlNodePtr name  : zero or one
 *   xmlNodePtr number: zero or one
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created User node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newUserId(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"UserId");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newUserId: xmlNewNode(NULL,\"UserId\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
        case 'i': /* ident */
          if(strcmp(p->name, "ident") == 0)
	  {
 	     xmlSetProp(cur, "ident", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"UserId");
          break;
        case 't': /* type */
          if(strcmp(p->name, "type") == 0)
	  {
 	     xmlSetProp(cur, "type", tmp_content);
             xmlFreeNode(p);
          }          
          else
            badNode(p,"UserId");
          break;
        case 'n':
          switch(*(p->name + 1)) 
          {
             case 'a': /* name */
	       if(strcmp(p->name, "name") == 0)
	         xmlAddChild(cur, p);
               else
	         badNode(p,"UserId");
               break;
             case 'u': /* number */
	       if(strcmp(p->name, "number") == 0)
	         xmlAddChild(cur, p);
               else
	         badNode(p,"UserId");
               break;
             default:
               badNode(p,"UserId");
	  }
          break;
        default:
          badNode(p,"UserId");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);
}

/*==================================================================
 * Name: newProcess
 *
 * Declaration: xmlNodePtr newProcess(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   ATTRIBUTES
 *   xmlNodePtr ident: optional
 *
 *   SUB-ELEMENTS
 *   xmlNodePtr name: exactly one
 *   xmlNodePtr pid : zero or one
 *   xmlNodePtr path: zero or one
 *   xmlNodePtr arg : zero or more
 *   xmlNodePtr env : zero or more
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created Process node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newProcess(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"Process");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newProcess: xmlNewNode(NULL,\"Process\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
        case 'i': /* ident */
          if(strcmp(p->name, "ident") == 0)
	  {
 	     xmlSetProp(cur, "ident", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"Process");
          break;
        case 'n': /* name */
          if(strcmp(p->name, "name") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"Process");
          break;
        case 'p':
          switch(*(p->name + 1))
	  {
  	     case 'i': /* pid */
	       if(strcmp(p->name, "pid") == 0)
		 xmlAddChild(cur, p);
	       else
		 badNode(p,"Process");
	       break;
	     case 'a': /* path */
	       if(strcmp(p->name, "path") == 0)
		 xmlAddChild(cur, p);
	       else
		 badNode(p,"Process");
	       break;
             default:
               badNode(p,"Process");
	  }
          break;
        case 'a': /* arg */
          if(strcmp(p->name, "arg") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"Process");
          break;
        case 'e': /* env */
          if(strcmp(p->name, "env") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"Process");
          break;
        default:
          badNode(p,"Process");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);
}

/*==================================================================
 * Name: newService
 *
 * Declaration: xmlNodePtr newService(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   ATTRIBUTES
 *   xmlNodePtr ident      : optional
 *   xmlNodePtr ip_version : optional
 *   xmlNodePtr iana_protocol_number: optional
 *   xmlNodePtr iana_protocol_name:   optional
 *
 *   SUB-ELEMENTS
 *   xmlNodePtr name       : zero or one
 *   xmlNodePtr port       : zero or one
 *   xmlNodePtr portlist   : zero or one
 *   xmlNodePtr protocol   : zero or one
 *   xmlNodePtr SNMPService: zero or one
 *   xmlNodePtr WebService : zero or one
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created Service node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newService(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"Service");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newService: xmlNewNode(NULL,\"Service\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
        case 'i': /* ident, iana_protocol_name, iana_protocol_number, ip_version */
          if(strcmp(p->name, "ident") == 0
             || strcmp(p->name, "ip_version") == 0
             || strcmp(p->name, "iana_protocol_number") == 0
             || strcmp(p->name, "iana_protocol_name") == 0)
	  {
 	     xmlSetProp(cur, p->name, tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"Service");
          break;
        case 'n': /* name */
          if(strcmp(p->name, "name") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"Service");
          break;
        case 'p':
          switch(*(p->name + 1))
	  {
  	     case 'r': /* protocol */
	       if(strcmp(p->name, "protocol") == 0)
		 xmlAddChild(cur, p);
	       else
		 badNode(p,"Service");
	       break;
	     case 'o': /* portlist & port */
	       if((strcmp(p->name, "portlist") == 0) ||
                  (strcmp(p->name, "port") == 0))
		 xmlAddChild(cur, p);
	       else
		 badNode(p,"Service");
	       break;
             default:
               badNode(p,"Service");
	  }
          break;
        case 'S': /* SNMPService */
          if(strcmp(p->name, "SNMPService") == 0)
       	    xmlAddChild(cur, p);
          else
            badNode(p,"Service");
          break;
        case 'W': /* WebService */
          if(strcmp(p->name, "WebService") == 0)
       	    xmlAddChild(cur, p);
          else
            badNode(p,"Service");
          break;
        default:
          badNode(p,"Service");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);
}

/*==================================================================
 * Name: newWebService
 *
 * Declaration: xmlNodePtr newWebService(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   SUB-ELEMENTS
 *   xmlNodePtr url        : exactly one
 *   xmlNodePtr cgi        : zero or one
 *   xmlNodePtr http-method: zero or one
 *   xmlNodePtr arg        : zero or more
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created WebService node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newWebService(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"WebService");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newWebService: xmlNewNode(NULL,\"WebService\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
        case 'u': /* url */
          if(strcmp(p->name, "url") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"WebService");
          break;
        case 'c': /* cgi */
	  if(strcmp(p->name, "cgi") == 0)
	    xmlAddChild(cur, p);
          else
	    badNode(p,"WebService");
          break;
        case 'h': /* http-method */
	  if(strcmp(p->name, "http-method") == 0)
	    xmlAddChild(cur, p);
          else
	    badNode(p,"WebService");
          break;
        case 'a': /* arg */
          if(strcmp(p->name, "arg") == 0)
       	    xmlAddChild(cur, p);
          else
            badNode(p,"WebService");
          break;
        default:
          badNode(p,"WebService");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);
}

/*==================================================================
 * Name: newSNMPService
 *
 * Declaration: xmlNodePtr newSNMPService(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   SUB-ELEMENTS
 *   xmlNodePtr oid      : zero or one
 *   xmlNodePtr community: zero or one
 *   xmlNodePtr command  : zero or one
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly create SNMPService node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newSNMPService(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"SNMPService");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newSNMPService: xmlNewNode(NULL,\"SNMPService\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
        case 'o': /* oid */
          if(strcmp(p->name, "oid") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"SNMPService");
          break;
        case 'c':
          switch(*(p->name + 4))
	  {
  	     case 'u': /* community */
	       if(strcmp(p->name, "community") == 0)
		 xmlAddChild(cur, p);
	       else
		 badNode(p,"SNMPService");
	       break;
	     case 'a': /* command */
	       if(strcmp(p->name, "command") == 0)
		 xmlAddChild(cur, p);
	       else
		 badNode(p,"SNMPService");
	       break;
             default:
               badNode(p,"SNMPService");
	  }
          break;
        default:
          badNode(p,"SNMPService");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);
}

/*==================================================================
 * Name: newFileList
 *
 * Declaration: xmlNodePtr newFileList(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   SUB-ELEMENTS
 *   xmlNodePtr File: one or more
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly create FileList node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newFileList(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"FileList");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newFileList: xmlNewNode(NULL,\"FileList\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
        case 'F': /* File */
          if(strcmp(p->name, "File") == 0)
       	    xmlAddChild(cur, p);
          else
            badNode(p,"FileList");
          break;
        default:
          badNode(p,"FileList");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);
}

/*==================================================================
 * Name: newFile
 *
 * Declaration: xmlNodePtr newFile(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   ATTRIBUTES
 *   xmlNodePtr ident   : optional
 *   xmlNodePtr category: required
 *   xmlNodePtr fstype  : optional
 *
 *   SUB-ELEMENTS
 *   xmlNodePtr name       : exactly one
 *   xmlNodePtr path       : exactly one
 *   xmlNodePtr create-time: Zero or one
 *   xmlNodePtr modify-time: Zero or one
 *   xmlNodePtr access-time: Zero or one
 *   xmlNodePtr disk-size  : Zero or one
 *   xmlNodePtr FileAccess : Zero or more
 *   xmlNodePtr Linkage    : Zero or more
 *   xmlNodePtr Inode      : Zero or one
 *   xmlNodePtr Checksum   : Zero or more
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created File node.
 *
 * Example: similar to newAlert.
 *
 * NOTE: As the specification states, create-time, modify-time, and
 *       access-time are DATETIME formatted values.  These can be created
 *       using currentDatetime() or both newSimpleElement() and
 *       timevalToDatetime().  See the example1.c file for an example.
 *===================================================================*/

xmlNodePtr newFile(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"File");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newFile: xmlNewNode(NULL,\"File\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
        case 'i': /* ident */
          if(strcmp(p->name, "ident") == 0)
	  {
 	     xmlSetProp(cur, "ident", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"File");
          break;
        case 'c':
          switch(*(p->name + 1))
	  {
  	     case 'a': /* category */
	       if(strcmp(p->name, "category") == 0)
		 {
		   xmlSetProp(cur, "category", tmp_content);
		   xmlFreeNode(p);
		 }
	       else
		 badNode(p,"File");
	       break;
	     case 'r': /* create-time */
	       if(strcmp(p->name, "create-time") == 0)
		 xmlAddChild(cur, p);
	       else
		 badNode(p,"File");
	       break;
             default:
               badNode(p,"File");
	  }
          break;
        case 'f': /* fstype */
          if(strcmp(p->name, "fstype") == 0)
	  {
 	     xmlSetProp(cur, "fstype", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"File");
          break;
        case 'n': /* name */
          if(strcmp(p->name, "name") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"File");
          break;
        case 'p': /* path */
          if(strcmp(p->name, "path") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"File");
          break;
        case 'm': /* modify-time */
          if(strcmp(p->name, "modify-time") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"File");
          break;
        case 'a': /* access-time */
          if(strcmp(p->name, "access-time") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"File");
          break;
        case 'd': /* disk-size */
          if(strcmp(p->name, "disk-size") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"File");
          break;
        case 'C': /* Checksum */
          if(strcmp(p->name, "Checksum") == 0)
            xmlAddChild(cur,p);
          else
            badNode(p,"File");
          break;
        case 'F': /* FileAccess */
          if(strcmp(p->name, "FileAccess") == 0)
            xmlAddChild(cur,p);
          else
            badNode(p,"File");
          break;
        case 'L': /* Linkage */
          if(strcmp(p->name, "Linkage") == 0)
            xmlAddChild(cur,p);
          else
            badNode(p,"File");
          break;
        case 'I': /* Inode */
          if(strcmp(p->name, "Inode") == 0)
            xmlAddChild(cur,p);
          else
            badNode(p,"File");
          break;
        default:
          badNode(p,"File");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);
}

/*==================================================================
 * Name: newFileAccess
 *
 * Declaration: xmlNodePtr newFileAccess(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   SUB-ELEMENTS
 *   xmlNodePtr UserId    : Exactly one
 *   xmlNodePtr permission: one or more
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created FileAccess node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newFileAccess(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"FileAccess");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newFileAccess: xmlNewNode(NULL,\"FileAccess\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
        case 'U': /* UserID */
          if(strcmp(p->name, "UserId") == 0)
       	    xmlAddChild(cur, p);
          else
            badNode(p,"FileAccess");
          break;
        case 'p': /* permission */
          if(strcmp(p->name, "permission") == 0)
       	    xmlAddChild(cur, p);
          else
            badNode(p,"FileAccess");
          break;
        default:
          badNode(p,"FileAccess");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);
}

/*==================================================================
 * Name: newLinkage
 *
 * Declaration: xmlNodePtr newLinkage(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   ATTRIBUTES
 *   xmlNodePtr category: optional
 *
 *   SUB-ELEMENTS
 *   xmlNodePtr name: Exactly one
 *   xmlNodePtr path: Exactly one
 *   xmlNodePtr File: Exactly one
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created Linkage node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newLinkage(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"Linkage");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newLinkage: xmlNewNode(NULL,\"Linkage\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
        case 'c': /* category */
          if(strcmp(p->name, "category") == 0)
	  {
 	     xmlSetProp(cur, "category", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"File");
          break;
        case 'n': /* name */
          if(strcmp(p->name, "name") == 0)
       	    xmlAddChild(cur, p);
          else
            badNode(p,"Linkage");
          break;
        case 'p': /* path */
          if(strcmp(p->name, "path") == 0)
       	    xmlAddChild(cur, p);
          else
            badNode(p,"Linkage");
          break;
        case 'F': /* File */
          if(strcmp(p->name, "File") == 0)
       	    xmlAddChild(cur, p);
          else
            badNode(p,"Linkage");
          break;
        default:
          badNode(p,"Linkage");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);
}

/*==================================================================
 * Name: newInode
 *
 * Declaration: xmlNodePtr newInode(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   SUB-ELEMENTS
 *   xmlNodePtr change-time   : zero or one
 *   xmlNodePtr number        : zero or one
 *   xmlNodePtr major-device  : zero or one
 *   xmlNodePtr minor-device  : zero or one
 *   xmlNodePtr c-major-device: zero or one
 *   xmlNodePtr c-minor-device: zero or one
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created Inode node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newInode(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"Inode");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newInode: xmlNewNode(NULL,\"Inode\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
        case 'c':
          switch(*(p->name + 1))
	  {
  	     case 'h': /* change-time */
	       if(strcmp(p->name, "change-time") == 0)
		 xmlAddChild(cur, p);
 	       else
		 badNode(p,"Inode");		 
               break;
	     case '-': /* c-major-device or c-minor-device */
               switch(*(p->name + 3))
	       {
  	          case 'a': /* c-major-device */
	            if(strcmp(p->name, "c-major-device") == 0)
 	               xmlAddChild(cur, p);
	            else
		       badNode(p,"Inode");
	            break;
  	          case 'i': /* c-minor-device */
	            if(strcmp(p->name, "c-minor-device") == 0)
 	               xmlAddChild(cur, p);
	            else
		       badNode(p,"Inode");
	            break;
                  default:
                    badNode(p,"Inode");
               }
               break;
             default:
               badNode(p,"Inode"); 
          }
 	  break;
        case 'n': /* number */
          if(strcmp(p->name, "number") == 0)
       	    xmlAddChild(cur, p);
          else
            badNode(p,"Inode");
          break;
        case 'm':
          switch(*(p->name + 1))
	  {
  	     case 'a': /* major-device */
	       if(strcmp(p->name, "major-device") == 0)
		 xmlAddChild(cur, p);
	       else
		 badNode(p,"Inode");
	       break;
	     case 'i': /* minor-device */
	       if(strcmp(p->name, "minor-device") == 0)
		 xmlAddChild(cur, p);
	       else
		 badNode(p,"Inode");
	       break;
             default:
               badNode(p,"Inode");
	  }
          break;
        default:
          badNode(p,"Inode");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);
}

/*==================================================================
 * Name: newChecksum
 *
 * Declaration: xmlNodePtr newChecksum(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   ATTRIBUTES
 *   xmlNodePtr algorithm: required
 *
 *   SUB-ELEMENTS
 *   xmlNodePtr value: exactly one
 *   xmlNodePtr key  : zero or one
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created Checksum node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newChecksum(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"Checksum");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newChecksum: xmlNewNode(NULL,\"Checksum\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
        case 'a':
          if(strcmp(p->name, "algorithm") == 0)
	  {
 	     xmlSetProp(cur, "algorithm", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"Checksum");
          break;

        case 'v':
          if(strcmp(p->name, "value") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"Checksum");
          break;

        case 'k':
          if(strcmp(p->name, "key") == 0)
  	    xmlAddChild(cur, p);
          else
            badNode(p,"Checksum");
          break;

        default:
          badNode(p,"Checksum");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);
}

/*********************************************************************
 *********************************************************************
 *****								 *****
 *****			The Assessment Classes			 *****
 *****								 *****
 *********************************************************************
 *********************************************************************/

/*==================================================================
 * Name: newImpact
 *
 * Declaration: xmlNodePtr newImpact(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   ATTRIBUTES
 *   xmlNodePtr severity  : optional
 *   xmlNodePtr completion: optional
 *   xmlNodePtr type      : optional
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created Impact node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newImpact(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"Impact");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newImpact: xmlNewNode(NULL,\"Impact\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
  	case 's': /* severity */
          if(strcmp(p->name, "severity") == 0)
	  {
	     xmlSetProp(cur, "severity", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"Impact");
          break;
	case 'c': /* completion */
	  if(strcmp(p->name, "completion") == 0)
	  {
	     xmlSetProp(cur, "completion", tmp_content);
             xmlFreeNode(p);
          }
	  else
	    badNode(p,"Impact");
	  break;
  	case 't': /* type */
          if(strcmp(p->name, "type") == 0)
	  {
	     xmlSetProp(cur, "type", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"Impact");
          break;
        default:
          badNode(p,"Impact");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);
}

/*==================================================================
 * Name: newAction
 *
 * Declaration: xmlNodePtr newAction(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   ATTRIBUTES
 *   xmlNodePtr category: required
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created Action node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newAction(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"Action");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newAction: xmlNewNode(NULL,\"Action\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
	case 'c': /* category */
	  if(strcmp(p->name, "category") == 0)
	  {
	     xmlSetProp(cur, "category", tmp_content);
             xmlFreeNode(p);
          }
	  else
	    badNode(p,"Action");
	  break;
        case 'v': /* value */
          if(strcmp(p->name, "value") == 0)
	  {
  	     encodeAndSetContent(cur, tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"Action");
          break;
        default:
          badNode(p,"Action");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);
}

/*==================================================================
 * Name: newConfidence
 *
 * Declaration: xmlNodePtr newConfidence(xmlNodePtr, ...);
 *
 * Possible parameters: 
 * 
 *   ATTRIBUTES
 *   xmlNodePtr rating: required
 *
 * !Remember!: the last argument must be NULL.
 *
 * Returns: an xmlNodePtr to the newly created Confidence node.
 *
 * Example: similar to newAlert.
 *===================================================================*/

xmlNodePtr newConfidence(xmlNodePtr first, ...)
{
  xmlNodePtr cur, p;
  va_list ap;
  xmlChar *tmp_content = NULL;

  cur = xmlNewNode(NULL,"Confidence");
  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newConfidence: xmlNewNode(NULL,\"Confidence\") failed");
    return NULL;
  }

  if(first == NULL) /* do we have at least one parameter? */
    return cur;

  /* cycle through the arguments */
  va_start(ap, first);

  for(p = first; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name == NULL)
       return NULL;

     tmp_content = xmlNodeGetContent(p);

     switch(*(p->name))
     {
  	case 'r': /* rating */
          if(strcmp(p->name, "rating") == 0)
	  {
	     xmlSetProp(cur, "rating", tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"Confidence");
          break;
        case 'v': /* value */
          if(strcmp(p->name, "value") == 0)
	  {
  	     encodeAndSetContent(cur, tmp_content);
             xmlFreeNode(p);
          }
          else
            badNode(p,"Confidence");
          break;
        default:
          badNode(p,"Confidence");
     }
     if(tmp_content != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(cur);
}

/*********************************************************************
 *********************************************************************
 *****								 *****
 *****			Utility Functions			 *****
 *****								 *****
 *********************************************************************
 *********************************************************************/

/*==================================================================
 * Name: newSimpleElement
 *
 * Parameters 
 *  char *name : the parameter name
 *  char *value: the value of the parameter
 *===================================================================*/

xmlNodePtr newSimpleElement(const char *name, const char *value)
{
  xmlNodePtr cur;

  if((name == NULL) || (value == NULL))
    return NULL;

  cur = xmlNewNode(NULL,name);

  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newSimpleElement: xmlNewNode() failed");
    return NULL;
  }

  encodeAndSetContent(cur, value);

  return(cur); 
}

/*==================================================================
 * Name: newAttribute
 *
 * Parameters 
 *  char *name : the parameter name
 *  char *value: the value of the parameter
 *
 * Note: This is the same function as newSimpleElement.  It was added to
 *       avoid confusion in building xml documents by following the
 *       nomenclature illustrated in the idmef-xml spec.  You may use
 *       newSimpleElement for adding new xml attributes if you so desire.
 *===================================================================*/

xmlNodePtr newAttribute(const char *name, const char *value)
{
  xmlNodePtr cur;
  
  if((name == NULL) || (value == NULL))
    return NULL;

  cur = xmlNewNode(NULL,name);

  if(cur == NULL)
  {
    idmef_error("idmefxml.c: newAttribute: xmlNewNode() failed");
    return NULL;
  }

  encodeAndSetContent(cur, value);

  return(cur); 
}

/***********************************************************************
 *
 * These are functions that perform different operations on XML elements
 * that have been created with the above "new" functions.
 *
 ***********************************************************************/

/*===========================================================================
 * Name: addElement
 * Purpose: Add a child element to a parent.
 * Parameters:
 *           - parent : an xmlNodePtr to the parent
 *           - child  : an xmlNodePtr to the child
 *
 * Returns: A pointer to the child, or NULL if error
 *
 * Note: We're not sure what type of error checking should occur here.  There's
 *       not really a way to ensure that the child should exist under the
 *       parent without implementing part of the DTD.  My initial thought is
 *       to let the DTD validation catch any errors at run time.
 *==========================================================================*/

xmlNodePtr addElement(xmlNodePtr parent, xmlNodePtr child)
{
  return xmlAddChild(parent, child);
}

/*===========================================================================
 * Name: addElements
 * Purpose: Add a child elements to a parent.
 * Parameters:
 *           - parent : an xmlNodePtr to the parent
 *           - child  : an xmlNodePtr to a child
 *           - ...    : a variable size list of xmlNodePtrs to children
 *
 * Returns: the number of children added
 *
 * NOTE: The last parameter MUST be NULL.  Otherwise, the function will not
 *       know when to stop reading in the variable length parameter list, and
 *       bad things will happen.
 *==========================================================================*/

int addElements(xmlNodePtr parent, xmlNodePtr child, ...)
{
  xmlNodePtr p;
  va_list ap;
  int count = 0;

  if((parent == NULL) || (child == NULL)) /* do we have at least two parameters? */
    return 0;

  /* cycle through the arguments */
  va_start(ap, child);

  for(p = child; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     if(p->name != NULL)
     {
        xmlAddChild(parent, p);
        count++;
     }
  }
  va_end(ap);

  return(count);
}

/*===========================================================================
 * Name: setAttribute
 * Purpose: Set attributes to an element.
 * Parameters:
 *           - element : an xmlNodePtr to the element
 *           - attrib  : an xmlNodePtr to the attribute
 *
 * Returns: A pointer to the element, or NULL if error
 *==========================================================================*/

xmlNodePtr setAttribute(xmlNodePtr element, xmlNodePtr attrib)
{
  char *propName = NULL;
  xmlChar *tmp_content = NULL;
  propName = xmlStrdup(attrib->name);

  tmp_content = xmlNodeGetContent(attrib);

  if(xmlSetProp(element, propName, tmp_content))
  {
     xmlFreeNode(attrib);
     if(tmp_content != NULL)
        xmlFree(tmp_content);
     if(propName != NULL)
       xmlFree(propName);
     return element;
  }

  if(tmp_content != NULL)
     xmlFree(tmp_content);

  if(propName != NULL)
     xmlFree(propName);

  xmlFreeNode(attrib);
  return NULL;
}

/*===========================================================================
 * Name: setAttributes
 * Purpose: Set attributes to a element.
 * Parameters:
 *           - element : an xmlNodePtr to the element
 *           - attrib  : an xmlNodePtr to an attribute
 *           - ...     : a variable size list of xmlNodePtrs to attributes
 *
 * Returns: the number of attributes set
 *
 * NOTE: The last parameter MUST be NULL.  Otherwise, the function will not
 *       know when to stop reading in the variable length parameter list, and
 *       bad things will happen.
 *==========================================================================*/

int setAttributes(xmlNodePtr element, xmlNodePtr attrib, ...)
{
  xmlNodePtr p;
  va_list ap;
  char *propName = NULL;
  xmlChar *tmp_content = NULL;
  int count = 0;


  /* do we have at least two parameters? */
  if((element == NULL) || (attrib == NULL))
    return 0;

  /* cycle through the arguments */
  va_start(ap, attrib);

  for(p = attrib; p != NULL; p = va_arg(ap, xmlNodePtr))
  {
     tmp_content = xmlNodeGetContent(p);

     if(p->name != NULL)
     {
        propName = xmlStrdup(p->name);

        xmlSetProp(element, propName, tmp_content);
        count++;
     }
     xmlFreeNode(p);
 
     /* these values were copied in xmlSetProp, so free 'em */
     if(tmp_content != NULL)
        xmlFree(tmp_content);
     if(propName != NULL)
        xmlFree(tmp_content);
  }
  va_end(ap);

  return(count);
}

/*==========================================================================*
 * Name: getElement()
 * Purpose: Retrieve a pointer to the first child element directly under a
 *          parent element whose name matches the provided string.
 * Parameters:
 *           - parent : an xmlNodePtr to the parent
 *           - name   : a string representing the child's name
 *
 * Returns: A xmlNodePtr containing the element.
 *==========================================================================*/

xmlNodePtr getElement(xmlNodePtr parent, const char *name)
{
  xmlNodePtr p;

  /* cycle through the children */
  for(p = parent->children; p != NULL; p = p->next)
  {
     if(strcmp(p->name, name) == 0)
        return p;
  }  
  return NULL;
}

/*==========================================================================*
 * Name: hasElement()
 * Purpose: Determines whether a parent element has a specified child element
 *          directly below it.  This is to say it only searches for first
 *          generation children.
 *
 * Parameters:
 *           - parent : an xmlNodePtr to the parent
 *           - name   : a string representing the child's name
 *
 * Returns: 1 for yes, 0 for no
 *==========================================================================*/

int hasElement(xmlNodePtr parent, const char *name)
{
  xmlNodePtr p;

  /* cycle through the children */
  for(p = parent->children; p != NULL; p = p->next)
  {
     if(strcmp(p->name, name) == 0)
        return 1;
  }  
  return 0;
}

 /***********************************************************************
  *
  * These are functions that perform different operations on XML documents.
  *
  ***********************************************************************/

/*==========================================================================*
 * Name: idmefInit()
 *
 * Purpose: Initialize global variables, and those structures we can reuse
 *          for each IDMEF Message.
 *
 * Parameters:
 *           - config : pointer to an IDMEFlib_config structure that must
 *             remain valid throughout the client's use of the library
 *             (or until idmefInit() is called again with a different arg).
 *             If config is null, a default configuration will be used.
 *
 * Returns: 1 for success, and 0 otherwise
 *
 * NOTE: You MUST call this function before you start to create IDMEF messages
 *==========================================================================*/
int idmefInit(IDMEFlib_config *config)
{
  /* all zero */
  static IDMEFlib_config default_config;

  if (config == NULL) 
  { 
    memset(&default_config, 0, sizeof(default_config));
    config = &default_config; 
  }

  if (idmef_config == config)
  {
    /* idmefInit called repeatedly with the same argument.  nothing to do. */
    return 1;
  }

  /* set the global idmef_config */
  idmef_config = config;

  /* set defaults */
  if (config->logf == NULL)     config->logf =     idmef_log_default;
  if (config->mallocf == NULL)  config->mallocf =  idmef_malloc_default;
  if (config->reallocf == NULL) config->reallocf = idmef_realloc_default;
  if (config->freef == NULL)    config->freef =    idmef_free_default;

  /* Call some init functions.  These will be done on-demand by libxml, but
   * calling them once explicitly avoids reentrancy problems in multithreaded
   * code.
   */
  xmlInitMemory();
  xmlInitParser();

  /* Initialize/parse the dtd */

  {
    if (config->dtd_path == NULL)
    {
      config->dtd_path = IDMEF_DTD_PATH;

      if (config->dtd_external_id == NULL)
      {
        config->dtd_external_id = IDMEF_DTD_EXTERNAL_ID;
      }
    }

    /* parse dtd. */
      
#if 0 /* client may not have zeroed this field, so assume it's garbage. */
    if (config->dtd)
      xmlFreeDtd(config->dtd);
#endif

    config->dtd = xmlParseDTD(NULL,config->dtd_path);

    if(config->dtd == NULL)
    {
      idmef_error("idmefxml.c: idmefInit(): problem parsing the DTD (%s)",
                  config->dtd_path);
    }
    else
    {
      /* Might want have a config item for this rather than
       * using IDMEF-Message as the root unconditionally. */
      config->dtd->name = xmlStrdup((xmlChar*)IDMEF_DTD_NAME);
    }
  }

  return 1;
}

/*==========================================================================*
 * Name: createDoc()
 * Purpose: Creates a new xmlDoc, sets the root element, and links
 *          to the DTD Internal Subset.
 *
 * Parameters:
 *           - xml_version : The current version of XML (XML_DEFAULT_VERSION)
 *           - root : The root node (or NULL)
 *           - include_doctype : if nonzero, include a DOCTYPE declaration.
 *             if zero, omit this declaration (result will not be valid XML)
 *
 * Returns: an xmlDocPtr to the newly created doc, or NULL for error.
 *==========================================================================*/

xmlDocPtr createDoc(const char *xml_version, 
                    xmlNodePtr root,
                    int include_doctype)
{
  xmlDocPtr newDoc;
  xmlDtdPtr intSubset;
  
  /* Initialize the document and root element */

  newDoc = xmlNewDoc(xml_version);
  
  if(newDoc == NULL)
  {
    idmef_error("idmefxml.c: createDoc(): problem creating new xml doc");
    return 0;
  }

  /* initialize the Internal Subset */
                  
  if (include_doctype)
  {
    intSubset = xmlCreateIntSubset(newDoc,
                                   (xmlChar*)idmef_config->dtd->name,
                                   (xmlChar*)idmef_config->dtd_external_id,
                                   (xmlChar*)idmef_config->dtd_path);
  }

  /* Attach the root node */
  if (root)
  {
    xmlNodePtr oldRoot = xmlDocSetRootElement(newDoc,root); 

    if(oldRoot != NULL)
      xmlFreeNode(oldRoot);
  }

  return newDoc;
}

/*==========================================================================*
 * Name: addAuxDtd()
 * Purpose: Modifies the internal subset of the given document to include
 *          a reference to the given DTD (for describing some XML 
 *          AdditionalData).
 *
 * Parameters:
 *           - doc: the (IDMEF) XML document to modify
 *           - name: name of the entity to use to refer to this dtd
 *             (e.g., "x-vendorco")
 *           - dtd_path: path to the auxiliary DTD on this system
 *             (e.g., "/usr/local/share/vendorco.dtd")
 *
 * Returns: void
 *==========================================================================*/

void addAuxDtd(xmlDocPtr doc,
               const xmlChar *name,
               const xmlChar *aux_dtd_path)
{
  xmlDtdPtr dtd;

  /* define an entity reference for the auxiliary DTD */
  xmlAddDocEntity(doc, name, XML_EXTERNAL_PARAMETER_ENTITY,
                  NULL, aux_dtd_path, NULL);

  /* use this reference in the internal subset */
  dtd = xmlGetIntSubset(doc);
  if (dtd == NULL) {
    /* oops, no internal subset exists.  do nothing. */
    return;
  }
#if 0
  /* This isn't right -- it generates a &foo; reference rather than %foo; */
  xmlAddChild((xmlNodePtr) dtd, xmlNewReference(doc, name));
#else
  {
    int len = xmlStrlen(name) + 3;
    xmlChar *ref = idmef_malloc(len);
#if 0
    /* not available in libxml 2.4.2 */
    xmlStrPrintf(ref, len, "%%%s;", (char*)name); 
#else
    snprintf(ref, len, "%%%s;", (char *)name);
#endif
    /* Unfortunately, as of libxml 2.6.11, the text node created here
     * leaks when the document is freed, because in xmlFreeDtd() it is 
     * assumed that the only "extra" nodes not found in one of the tables
     * are XML_COMMENT_NODE and XML_PI_NODE.  I reported this apparent bug
     * and suggested a patch: 
     *    http://bugzilla.gnome.org/show_bug.cgi?id=148965
     * Don't know of any simple workaround, though I suppose before libidmef
     * does an xmlFreeDoc() it could first grovel through doc->intSubset
     * looking for XML_TEXT_NODE children to unlink and free.  This wouldn't
     * solve the problem in cases where a client calls xmlFreeDoc() directly.
     *
     * Update: Daniel Veillard reports he has applied my patch.  I assume
     * it will show up in libxml2 2.6.12.
     */
    xmlAddChild((xmlNodePtr) dtd, xmlNewText(ref));
    xmlFree(ref);
  }
#endif
}


/*==========================================================================*
 * Name: validateDoc(vctxt,doc)
 *
 * Purpose: Validates an IDMEF document against the IDMEF DTD.
 *
 * Parameters:
 *         - vctxt : An xmlValidCtxtPtr (if null, warnings/errors go to stderr)
 *         - doc :   The document to validate
 *
 * Returns: 1 for success, and 0 otherwise
 *==========================================================================*/
int validateDoc(xmlValidCtxtPtr vctxt, xmlDocPtr doc)
{
  int result;
  xmlValidCtxtPtr newVctxt = NULL;

  if(idmef_config->dtd == NULL)
  {
    idmef_error("validateDoc() : idmef DTD not loaded.  call idmefInit(NULL)");
    return 0;
  }

  if (vctxt == NULL)
  {
#if 0
    /* not present in libxml 2.4.2 */
    newVctxt = xmlNewValidCtxt();
#else
    newVctxt = idmef_malloc(sizeof(*newVctxt));
    memset(newVctxt, '\0', sizeof(*newVctxt));
#endif
    if(newVctxt == NULL)
    {
      idmef_error("idmefxml.c : validateDoc() : allocation failure!");
      return 0;
    }
    newVctxt->userData = (void *) idmef_config;
    newVctxt->error = (xmlValidityErrorFunc) idmef_error_cfg;
    newVctxt->warning = (xmlValidityWarningFunc) idmef_warn_cfg;
    vctxt = newVctxt;
  }
  result = xmlValidateDtd(vctxt,doc,idmef_config->dtd);
  if (newVctxt)
  {
#if 0
    xmlFreeValidCtxt(newVctxt);
#else
    idmef_free(newVctxt);
#endif
  }
  return result;
}

/*==========================================================================*
 * Name: printDocument()
 *
 * Purpose: Prints the given message to the FILE * provided
 *
 * CHANGES: changed from xmlElemDump(f,doc,doc->children), because
 *          we were not printing the XML declaration, making it invalid.
 *
 *==========================================================================*/
void printDocument(FILE *f, xmlDocPtr doc)
{
  xmlOutputBufferPtr buf;
  buf = IDMEFxmlOutputBufferCreate(f, NULL);
  IDMEFxmlDocContentDumpOutput(buf, doc, NULL, 1);
  xmlOutputBufferClose(buf);
}

/***********************************************************************
 *
 *    Config-dependent functions, primarily for internal libidmef use
 *
 ***********************************************************************/

static void *idmef_malloc_default(void *arg, size_t size)
{
  return malloc(size);
}

static void *idmef_realloc_default(void *arg, void *ptr, size_t size)
{
  return realloc(ptr, size);
}

static void idmef_free_default(void *arg, void *ptr)
{
  return free(ptr);
}

void *idmef_malloc(size_t size)
{
  void *p;
  p = (*idmef_config->mallocf)(idmef_config->alloc_arg, size);
  if (size && p == NULL) abort();
  return p;
}

void *idmef_realloc(void *ptr, size_t size)
{
  ptr = (*idmef_config->reallocf)(idmef_config->alloc_arg, ptr, size);
  if (size && ptr == NULL) abort();
  return ptr;
}

void idmef_free(void *ptr)
{
  (*idmef_config->freef)(idmef_config->alloc_arg, ptr);
}

/* log via fprintf, add newline */
static void idmef_log_default(void *arg, int level, const char *fmt, 
                              va_list ap)
{
  FILE *f = arg ? (FILE *)arg : stderr;
  vfprintf(f, fmt, ap);
  fprintf(f, "\n");
}

void idmef_logv_cfg(IDMEFlib_config *cfg, 
                    int level, const char *fmt, va_list ap)
{
  cfg->logf(cfg->log_arg, level, fmt, ap);
}

void idmef_debug_cfg(IDMEFlib_config *cfg, const char *fmt, ...)
{
  va_list argp;
  va_start(argp, fmt);
  idmef_logv_cfg(cfg, cfg->log_level_debug, fmt, argp);
  va_end(argp);
}

void idmef_warn_cfg(IDMEFlib_config *cfg, const char *fmt, ...)
{
  va_list argp;
  va_start(argp, fmt);
  idmef_logv_cfg(cfg, cfg->log_level_warn, fmt, argp);
  va_end(argp);
}

void idmef_error_cfg(IDMEFlib_config *cfg, const char *fmt, ...)
{
  va_list argp;
  va_start(argp, fmt);
  idmef_logv_cfg(cfg, cfg->log_level_error, fmt, argp);
  va_end(argp);
}

void idmef_logv(int level, const char *fmt, va_list ap)
{
  idmef_config->logf(idmef_config->log_arg, level, fmt, ap);
}

void idmef_debug(const char *fmt, ...)
{
  va_list argp;
  va_start(argp, fmt);
  idmef_logv(idmef_config->log_level_debug, fmt, argp);
  va_end(argp);
}

void idmef_warn(const char *fmt, ...)
{
  va_list argp;
  va_start(argp, fmt);
  idmef_logv(idmef_config->log_level_warn, fmt, argp);
  va_end(argp);
}

void idmef_error(const char *fmt, ...)
{
  va_list argp;
  va_start(argp, fmt);
  idmef_logv(idmef_config->log_level_error, fmt, argp);
  va_end(argp);
}


/***********************************************************************
 *
 *               Miscellaneous time format functions.
 *
 ***********************************************************************/

/*==========================================================================*
 * Name: currentNtpTimestamp()
 *
 * Purpose: Creates a NTP timestamp with the current time
 *
 * Returns: The current NTP timestamp as a char *
 *
 *==========================================================================*/

xmlChar *currentNtpTimestamp()
{
   struct timeval currtv;

   gettimeofday(&currtv,0);
   return timevalToNtpTimestamp(&currtv);
}

/*==========================================================================*
 * Name: currentDatetime
 *
 * Purpose: Formats the current datetime as specified by the IDMEF XML
 *          specification version 12 (3.2.6). YYYY-MM-DDThh:mm:ss.ssssssZ.
 *          Time is represented as UTC.
 *
 * Declaration: xmlChar *currentDatetime();
 *
 * Returns: The formatted date as an xmlChar *
 *
 * Example: 
 *          xmlChar *datetime = currentDatetime();
 *          ...
 *          xmlFree(datetime);
 *==========================================================================*/

xmlChar *currentDatetime()
{
   struct timeval curr_time;

   if (gettimeofday(&curr_time, NULL) != 0) {
      idmef_error( "currentDatetime(): gettimeofday failed");
      return NULL;
   }

   return timevalToDatetime(&curr_time);
}

/*==========================================================================*
 * Name: timevalToNtpTimestamp
 *
 * Purpose: Creates a NTP timestamp with the provided timeval struct
 *
 * Returns: The provided NTP timestamp as an xmlChar *
 *
 * Example:
 *          struct timeval t;
 *          char *ntp_timestamp_string;
 *
 *          gettimeofday(&t,0);
 *          ntp_timestamp_string = timevalToNtpTimestamp(&t);
 *==========================================================================*/

xmlChar *timevalToNtpTimestamp(const struct timeval *t)
{
   xmlChar *idmef_ntp_timestamp;
   unsigned long seconds, fraction;

   seconds = t->tv_sec + 2208988800UL;
   fraction = (4294967296.0 * (double)t->tv_usec) / 1e6 + 0.5; /* round */

   idmef_ntp_timestamp = (xmlChar *) idmef_malloc(sizeof(xmlChar) + MAX_NTP_TIMESTAMP_SIZE); /* 0xNNNNNNNN.0xNNNNNNNN */
   sprintf(idmef_ntp_timestamp,"0x%08lx.0x%08lx", seconds, fraction);

   return idmef_ntp_timestamp;
}

/*==========================================================================*
 * Name: timevalToDatetime *
 * Purpose: Formats the provided time as specified by the IDMEF XML
 *          specification version 12 (3.2.6). YYYY-MM-DDThh:mm:ss.ssssssZ.
 *          Time is represented as UTC.
 *
 * Returns: The formated time as an xmlChar *
 *
 * Example:
 *          time_t t;
 *          xmlChar *datetime_string;
 *
 *          t = time(NULL);
 *          datetime_string = timeToDatetime(&t);
 *          ...
 *          xmlFree(datetime_string);
 *
 * Note: This function generates time in UTC, partially because we technically
 *       save space and bandwith, but more so because strftime's representation
 *       of "time-zone as hour offset from GMT", excludes the ':', which is
 *       required in the IDMEF spec.
 *==========================================================================*/

xmlChar *timevalToDatetime(const struct timeval *t)
{
   xmlChar *date_str;
   struct tm *tm_utc;
   size_t pos;
   size_t baselen = sizeof("YYYY-MM-DDThh:mm:ss") - 1;
   size_t size = (baselen 
                  + 1           /* decimal point */
                  + 6           /* six digits after "." (microseconds) */
                  + 1           /* "Z" */
                  + 1);         /* NUL */

   date_str = (xmlChar *) idmef_malloc(size);

   tm_utc = gmtime((const time_t *)&t->tv_sec);
   
   pos = strftime(date_str, size, "%Y-%m-%dT%H:%M:%S", tm_utc);
 
   if (t->tv_usec >= 0 && t->tv_usec <= 999999) {
      /* leave off fractional part if usec==0.  spec says (draft12, 
       * Section 3.2.6, item 3) "the number of digits in the fraction
       * part does not imply anything about accuracy," so this is safe. */
      if (t->tv_usec > 0)
         pos += snprintf(date_str + pos, size - pos, ".%06ld", t->tv_usec);
   } else {
      /* invalid tv_usec: ignore rather than overrun and/or print bad value */
      idmef_error("timevalToDatetime: ignoring invalid tv_usec (%ld)",
              t->tv_usec);
   }

   strcpy(date_str + pos, "Z");

   return date_str;
}

/***********************************************************************
 *
 *                   Other utility functions
 *
 ***********************************************************************/

/*==========================================================================*
 * Name: getStoredAlertID()
 *
 * Purpose: Opens the specified file, and attempts to extract the stored
 *          alert id.
 *
 * Returns: the alert id as an unsigned long integer, 1 if the file didn't
 *          contain an alert id, or 0 for error.
 *==========================================================================*/
unsigned long getStoredAlertID(const char *f_name)
{
  FILE *f;
  char *idmef_alertid_string;
  unsigned long aid;

  /* Open the alert ID file and extract the stored alert ID if it exists*/
  f = fopen(f_name,"a+");
  if (!f) 
  {
     idmef_error("getStoredAlertID: IDMEF alert ID file open error (%s)",f_name);
     return 0;
  }

  /** Now seek back to the beginning... Nice little hack **/
  rewind(f);
    
  idmef_alertid_string = (char *) idmef_malloc(MAX_ALERTID_BUFFER_SIZE);

  if(fgets(idmef_alertid_string, MAX_ALERTID_BUFFER_SIZE + 1, f) == NULL)
  {
    /*     idmef_error("getStoredAlertID: Stored alert ID not found in %s, continuing with alert ID = 1", f_name); */
     aid = 1;
  }
  else
     aid = (unsigned long) atol(idmef_alertid_string);
  
  return aid;

  fclose(f); /* done for now */
}

/*==========================================================================*
 * Name: saveAlertID()
 *
 * Purpose: Opens the specified file, and attempts to extract the stored
 *          alert id.
 *
 * Returns: 1 for success or 0 for error.
 *==========================================================================*/
int saveAlertID(unsigned long aid, const char *f_name)
{
   char *temp;
   FILE *f;
 
   temp = (char *) idmef_malloc(MAX_ALERTID_BUFFER_SIZE);
   temp = ulongToString(aid);

   f = fopen(f_name,"w");
   if (!f) 
   {
      idmef_error("saveAlertID: IDMEF alert ID file open error (%s)",f_name);
      return 0;
   }

   if(fputs(ulongToString(aid), f) < 0)
   {
     idmef_error("saveAlertID: Error writting alert id (%lu) to %s", aid, f_name);
     return 0;
   }
   fputc('\n',f);
   fflush(f);
   fclose(f);

   return 1;
}

/*==========================================================================*
 * Name: badNode()
 * Purpose: Prints a message to stderr with the invalid node name, and the
 *          parent it was attempted to be linked to.
 *
 * Parameters:
 *           - theNode : the invalid node
 *           - parent  : the would-be parent node's name
 *==========================================================================*/
void badNode(xmlNodePtr theNode, const char *parent)
{
  /* idmef_error( "idmefxml.c: Invalid xmlNode for parent %s", parent);*/
   idmef_error("idmefxml.c: Invalid xmlNode \"%s\" for %s",
          theNode->name, parent);
   xmlFreeNode(theNode);
   return;
}

/*==========================================================================*
 * Name: intToString()
 * Purpose: Converts a signed integer value to its ASCII representation.
 *
 * Parameters:
 *           - int_val : the value to be converted
 *
 * Returns: The ASCII representation
 *==========================================================================*/
char * intToString(int int_val)
{
  int ret, tmp;
  char *string_val;

  if(int_val > 0)
    tmp = floor(log10(int_val)) + 2;
  else
     if(int_val < 0)
        tmp = floor(log10(-1 * int_val)) + 3;
     else
        tmp = 2;

  string_val = idmef_malloc(tmp);
  if(string_val == NULL)
     return NULL;
  ret = sprintf(string_val,"%d",int_val);

  if(ret > -1 && ret <= tmp)
     return string_val;
  
  return NULL;
}

/*==========================================================================*
 * Name: ulongToString()
 * Purpose: Converts an unsigned value to it's ASCII representation.
 * 
 * Parameters:
 *           - ulong_val : the value to be converted
 *
 * Returns: The ASCII representation
 *
 * Note: This function was custom made for converting ulong alertID's to
 *       strings.
 *==========================================================================*/
char * ulongToString(unsigned long ulong_val)
{
  int ret;
  int tmp;
  char *string_val;

  if(ulong_val == 0)
    tmp = 2;
  else
    tmp = floor(log10(ulong_val)) + 2;
 
  string_val = idmef_malloc(tmp);
  if(string_val == NULL)
     return NULL;
  ret = sprintf(string_val,"%lu",ulong_val);

  if(ret > -1 && ret <= tmp)
     return string_val;

  return NULL;
}

/*=========================================================================*
 * Name: IDMEFxmlOutputBufferCreate:
 * Purpose: Create a buffered  output for the progressive saving of a file
 *          If filename is "-' then we use stdout as the output.
 *          Automatic support for ZLIB/Compress compressed document is provided
 *          by default if found at compile-time.
 *
 * Parameters:
 *             @URI:  a C string containing the URI or filename
 *             @encoder:  the encoding converter or NULL
 *             @compression:  the compression ration (0 none, 9 max).
 *
 * Returns: the new output or NULL
 * Note: This function is another strain of the xmlOutputBufferCreate functions
 *       from libxml.  It's also happens to be used in an I/0 example from
 *       www.xmlsoft.org, and happens to fit our needs nicely.
 *=========================================================================*/
xmlOutputBufferPtr IDMEFxmlOutputBufferCreate(FILE *file, xmlCharEncodingHandlerPtr encoder) 
{
           xmlOutputBufferPtr ret;
           
           xmlRegisterDefaultOutputCallbacks();

           if (file == NULL) return(NULL);

           ret = xmlAllocOutputBuffer(encoder);
           if (ret != NULL) {
               ret->context = file;
               ret->writecallback = IDMEFxmlFileWrite;
               ret->closecallback = NULL;  /* No close callback */
           }
           return(ret); 
} 

/*==========================================================================*
 * Name: IDMEFxmlFileWrite
 * Purpose: Writes @len bytes from @buffer to the I/O channel
 * 
 * Parameters:
 *            @context:  the I/O context
 *            @buffer:  where to drop data
 *            @len:  number of bytes to write
 *
 * Returns: The number of bytes written
 *
 * Note: This function is an import of a static function called xmlFileWrite
 *       from libxml.
 *==========================================================================*/

int IDMEFxmlFileWrite (void * context, const char * buffer, int len) {
    return(fwrite(&buffer[0], 1,  len, (FILE *) context));
}

/*==========================================================================*
 * Name: libidmef_version
 * Purpose: Return the libidmef version string
 *==========================================================================*/

const char * libidmef_version () {
    return LIBIDMEF_VERSION;
}

/*=========================================================================*
 * Name: IDMEFxmlDocContentDumpOutput:
 * Purpose: Dumps an xml Document to an xmlOutputBufferPtr
 *
 * Parameters:
 *             @buf:  the XML buffer output
 *             @cur:  the document
 *             @encoding:  an optional encoding string
 *             @format:  should formatting spaces been added
 *
 * Note: This function is an import of a static function called
 *       xmlDocContentDumpOutput from libxml.
 *==========================================================================*/
void IDMEFxmlDocContentDumpOutput(xmlOutputBufferPtr buf, xmlDocPtr cur,
                             const char *encoding, int format) 
{
    xmlOutputBufferWriteString(buf, "<?xml version=");
    if (cur->version != NULL)
        xmlBufferWriteQuotedString(buf->buffer, cur->version);
    else
        xmlOutputBufferWriteString(buf, "\"1.0\"");
    if (encoding == NULL) {
        if (cur->encoding != NULL)
            encoding = (const char *) cur->encoding;
        else if (cur->charset != XML_CHAR_ENCODING_UTF8)
            encoding = xmlGetCharEncodingName((xmlCharEncoding) cur->charset);
    }
    if (encoding != NULL) {
        xmlOutputBufferWriteString(buf, " encoding=");
        xmlBufferWriteQuotedString(buf->buffer, (xmlChar *) encoding);
    }
    switch (cur->standalone) {
        case 0:
            xmlOutputBufferWriteString(buf, " standalone=\"no\"");
            break;
        case 1:
            xmlOutputBufferWriteString(buf, " standalone=\"yes\"");
            break;
    }
    xmlOutputBufferWriteString(buf, "?>\n");
    if (cur->children != NULL) {
        xmlNodePtr child = cur->children;

        while (child != NULL) {
            xmlNodeDumpOutput(buf, cur, child, 0, format, encoding);
            xmlOutputBufferWriteString(buf, "\n");
            child = child->next;
        }
    }
}

/* Make emacs handle 2-column indentation used (inconsistently) in this file:
 * Local Variables:
 * c-basic-offset:2
 * indent-tabs-mode:nil
 * tab-width:8
 * End: */
