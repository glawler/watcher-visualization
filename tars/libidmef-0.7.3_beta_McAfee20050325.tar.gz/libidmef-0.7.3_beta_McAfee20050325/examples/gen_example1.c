/*
gen_example1.c: prints out IDMEF XML message based on contents of IDMEFmessage
Author: Adam Migus, NAI Labs, (amigus@nai.com)

Copyright (c) 2001 Networks Associates Technology, Inc.
All rights reserved

This library is released under the GNU GPL and BSD software licenses.
You may choose to use one or the other, BUT NOT BOTH.  The GNU GPL
license is located in the file named COPYING.  The BSD license is located
in the file named COPYING.BSD.  Please contact us if there are any
questions.

$Id: gen_example1.c,v 1.8 2005/01/21 03:54:35 dkindred Exp $

*/

/*
*/

#include "config.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#if TIME_WITH_SYS_TIME
# include <sys/time.h>
# include <time.h>
#else
# if HAVE_SYS_TIME_H
#  include <sys/time.h>
# else
#  include <time.h>
# endif
#endif

#include <libidmef/idmefxml_global.h>
#include <libidmef/idmefxml_types.h>
#include <libidmef/idmefxml_parse.h>
#include <libidmef/idmefxml_gen.h>
#include <libidmef/idmefxml.h>

#include <libxml/tree.h>
#include <libxml/xmlmemory.h>
#include <libxml/parser.h>
#include <libxml/valid.h>
#include <libxml/entities.h>
#include <libxml/debugXML.h>
#include <libxml/xmlIO.h>
#include <libxml/xmlerror.h>

char *program = 0;

int usage(char *p) {
	fprintf(stdout, "usage: %s <IDMEF xml file>\n", p);
	return 1;
}

int
main(int argc, char **argv) {
	IDMEFmessage *message = 0; 
	xmlDocPtr doc;
    char *filename;

	char *p = 0;

	program = ((p = strrchr(argv[0], '/')) ? ++p : argv[0]);

	if(argc != 2) return usage(program);

    idmefInit( NULL );

    filename = argv[1];

    fprintf(stderr, "reading file %s\n", filename);

	if(!(doc = xmlReadFile(filename, 0, XML_PARSE_NOBLANKS))) {
		fprintf(stderr, "error: xmlReadFile() failed\n");
		return 1;
	}

	message = get_idmef_message_from_doc(doc, 1);	

    if (message == NULL) {
        fprintf(stderr, "failed loading IDMEF message from file %s\n",
                filename);
        exit(1);
    }

	p = generate_idmef_message(message, NULL, 1, 1);

	fprintf(stdout, "%s\n", p);

	exit(0);
}
