/**************************************************************************
 * This is a test program and example that uses libidmef to
 * construct an IDMEF XML message and print it to a file.
 *
 * The program was tested, and successfully ran with the following
 * commands in the directory that libidmef was built in:
 *
 * NOTE: Now you can indent your tree with the -i option.
 *
 * Linux
 * -----
 * # gcc `xml2-config --cflags`  -o example1 example1.c -lidmef -lm -lxml2
 * # ./example1 [-i] [-l <logfile name>]
 *
 * BSD
 * -----------------
 * NOTE: you may have to provide a path to libraries in /usr/local/lib using 
 *       -L/usr/local/lib, as well as paths to header files in 
 *        /usr/local/include -I/usr/local/include
 *
 * # gcc -o example1 example1.c -lidmef -lm -lxml2 -lz
 * # ./example1 [-i] [-l <logfile name>]
 *
 * E-mail me if problems occur (joey@silicondefense.com)
 ***************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <libidmef/idmefxml_global.h>
#include <libidmef/idmefxml.h>

#define ALERT_VERSION           "1"
#define ANALYZER_ID             "0000000000001"
#define ANALYZER_LOCATION       "Client 1 network"
#define DEFAULT_LOG_FILE_NAME   "message.log"
#define DEFAULT_HOSTNAME        "SENSOR1"
#define BUFFERSIZE              256

extern char *optarg;
extern int optind;

int main(int argc, char *argv[]) {

  int opt;
  char *idmef_log_file_name = NULL;
  FILE *idmef_log_file = NULL;
  char hostname[BUFFERSIZE];
  xmlNodePtr root;
  xmlDocPtr doc;

  /* get command line options */

  while((opt = getopt(argc, argv, "il:")) != -1)
  {
     switch(opt)
     {
        case 'i':
	   xmlKeepBlanksDefault(0);
           break;
        case 'l':
	   idmef_log_file_name = idmef_malloc(BUFFERSIZE);
	   strncpy(idmef_log_file_name, optarg, BUFFERSIZE);
           break;
     }
  }

  /* try to get the host name */

  if(getenv("HOSTNAME"))
  {
     strncpy(hostname, getenv("HOSTNAME"), BUFFERSIZE);
     hostname[255] = '\0';
  }
  else if(getenv("HOST"))  /* FreeBSD, maybe others */
  {
     strncpy(hostname, getenv("HOST"), BUFFERSIZE);
     hostname[255] = '\0';
  }
  else
  {
    strncpy(hostname,DEFAULT_HOSTNAME, BUFFERSIZE);
    hostname[255] = '\0';    
  }

  /* open the log file */

  if(idmef_log_file_name != NULL) 
     idmef_log_file = fopen(idmef_log_file_name,"w");
  else
     idmef_log_file = fopen(DEFAULT_LOG_FILE_NAME,"w");

  /* Initialize the global variables */ 

  idmefInit(NULL);
  
  /* Construct the IDMEF Message */

  root = newIDMEF_Message(
    newAttribute("version","1.0"),
    newAlert(
        newAttribute("ident","999"),
        newAnalyzer(
           newAttribute("analyzerid",ANALYZER_ID),
           newNode(
              newAttribute("category","dns"),
              newSimpleElement("location",ANALYZER_LOCATION),
              newSimpleElement("name",hostname),
              NULL
           ),
           NULL
        ),
	newCreateTime(NULL, NULL, NULL),
        newSource(
           newAttribute("spoofed","unknown"),
           newNode(
              newAddress(
                newAttribute("category","ipv4-addr"),
                newSimpleElement("address","222.222.222.222"),
                NULL
              ),
              NULL
           ),
           newService(
              newAttribute("ident","s1-01"),
              newSimpleElement("port","2423"),
              NULL
           ),
           NULL
        ),
        newTarget(
           newAttribute("decoy","unknown"),
           newNode(
              newAttribute("category","dns"),
              newSimpleElement("location","Client 1 network"),
              newAddress(
                 newAttribute("category","ipv4-addr"),
                 newSimpleElement("address","111.111.111.111"),
                 NULL
              ),
              NULL
           ),
           newService(
              newAttribute("ident","t1-01"),
              newSimpleElement("port","80"),
              NULL
           ),
           newFileList(
	      newFile(
	          newAttribute("category","current"),
	          newAttribute("fstype","fat32"),
       	          newSimpleElement("name","example.asp"),
		  newSimpleElement("path","C:\\Web\\Scripts\\example.asp"),
		  newSimpleElement("access-time",currentDatetime()),
		  NULL
	      ),
              NULL
	   ),
           NULL
        ),
        newClassification(
	   newAttribute("origin","vendor-specific"),
           newSimpleElement("name","WEB IIS - View Source via Translate Header"),
	   newSimpleElement("url","http://www.securityfocus.com/bid/1578"),
           NULL
        ),
        NULL
     ),
     NULL
  );

  /* Create the document structure, passing in the current version
     of XML (1.0), the root IDMEF-Message node, and a flag indicating
     that a DOCTYPE declaration should be included.  */

  doc = createDoc(XML_DEFAULT_VERSION, root, 1);

  /* validate against the IDMEF DTD */

  validateDoc(NULL, doc);

  /* Print the current message to the log file */

  printDocument(idmef_log_file, doc);

  /* Cleanup */

  fclose(idmef_log_file);
  xmlFreeDoc(doc);

  return 0;
}


