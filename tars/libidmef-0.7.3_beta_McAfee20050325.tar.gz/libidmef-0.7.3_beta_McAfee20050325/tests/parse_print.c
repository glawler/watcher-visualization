#include "config.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

#if TIME_WITH_SYS_TIME
# include <sys/time.h>
# include <time.h>
#else
# if HAVE_SYS_TIME_H
#  include <sys/time.h>
# else
#  include <time.h>
# endif
#endif

#include <libidmef/idmefxml_global.h>
#include <libidmef/idmefxml_types.h>
#include <libidmef/idmefxml_parse.h>
#include <libidmef/idmefxml_gen.h>
#include <libidmef/idmefxml.h>

static void 
usage(const char *prog)
{
    fprintf(stderr, "usage: $0 [--dtd <path>] [--auxdtd <path>]\n");
    exit(1);
}

int 
main(int argc, char *argv[])
{
    int validate = 0;
	IDMEFmessage *message = 0; 

    const char *dtd = NULL;
    const char *aux_dtd = NULL;
    int arg;

    for (arg = 1; arg < argc; arg++)
    {
        if (strcmp(argv[arg], "--dtd") == 0) {
            if (++arg >= argc)
                usage(argv[0]);
            dtd = argv[arg];
        } else if (strcmp(argv[arg], "--auxdtd") == 0) {
            if (++arg >= argc)
                usage(argv[0]);
            aux_dtd = argv[arg];
        } else {
            usage(argv[0]);
        }
    }

    {
        /* don't use idmef_malloc here since we haven't run idmefInit(). */
        IDMEFlib_config *config = malloc(sizeof(*config));
        memset(config, 0, sizeof(*config));
        config->dtd_path = dtd;
        idmefInit(config);
    }

#if 0 /* xmlReadFd not available in 2.4.2 */
    {
        xmlDocPtr doc;

        if (!(doc = xmlReadFd(fileno(stdin), NULL, NULL, XML_PARSE_NOBLANKS))){
            idmef_error("error: xmlReadFd() failed");
            return 1;
        }

        message = get_idmef_message_from_doc(doc, validate);	
        if (message == NULL) {
            idmef_error("get_idmef_message() failed");
            return 1;
        }
        xmlFreeDoc(doc);
    }
#else
    {
        char *buf = NULL;
        size_t len = 0, cap = 0;
        while (!feof(stdin)) {
            size_t l;
            if (cap - len < 4096) {
                cap = (cap > 0 ? cap * 2 : 4096);
                buf = idmef_realloc(buf, cap);
                if (buf == 0) {
                    idmef_error("memory allocation failure");
                    return 1;
                }
            }
            l = fread(buf, 1, cap - len, stdin);
            if (ferror(stdin)) {
                idmef_error("error reading document: %s", strerror(errno));
                exit(1);
            }
            len += l;
        }
        /* idmef_debug("parsing \"%.*s\"\n", len, buf); */
        message = get_idmef_message(buf, len, validate);
        if (message == NULL) {
            idmef_error("get_idmef_message() failed");
            return 1;
        }
    }
#endif

    {
        xmlDocPtr newdoc = build_idmef_message_doc(message, 1, 0);
        xmlChar *buf;
        int bufsize = 0;

        if (aux_dtd) 
            addAuxDtd(newdoc, "x-auxdtd", aux_dtd);

        xmlDocDumpFormatMemory(newdoc, &buf, &bufsize, 1);
        printf("%.*s", bufsize, buf);

        {
            /* reparse doc (required if we added an aux_dtd) and validate */
            xmlDocPtr reparsedDoc = xmlParseDoc(buf);

            if (!validateDoc(NULL, reparsedDoc)) {
                idmef_error(
                        "%s: validation of generated document failed\n",
                        argv[0]);
                exit(1);
            }
            xmlFreeDoc(reparsedDoc);
        }        

        xmlFree(buf);
        xmlFreeDoc(newdoc);
    }
    free_message(message);

	exit(0);
    
}
