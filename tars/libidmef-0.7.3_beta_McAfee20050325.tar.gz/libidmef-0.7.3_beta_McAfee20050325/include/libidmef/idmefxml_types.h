/*
idmefxml_types.h: header file for libidmef data types
Author: Adam Migus, NAI Labs, (amigus@nai.com)

Copyright (c) 2001 Networks Associates Technology, Inc.
All rights reserved

This library is released under the GNU GPL and BSD software licenses.
You may choose to use one or the other, BUT NOT BOTH.  The GNU GPL
license is located in the file named COPYING.  The BSD license is located
in the file named COPYING.BSD.  Please contact us if there are any
questions.

$Id: idmefxml_types.h,v 1.6 2004/12/14 13:29:41 dkindred Exp $
*/

#ifndef _IDMEFXML_TYPES_H
#define _IDMEFXML_TYPES_H 1

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/*
 *  Enumeration definitions.
 */

typedef enum _IDMEFspoofed {
			IDMEF_SPOOFED_UNKNOWN  = 0,
			IDMEF_SPOOFED_YES      = 1,
			IDMEF_SPOOFED_NO       = 2
} IDMEFspoofed;

typedef enum _IDMEFdecoy {
                        IDMEF_DECOY_UNKNOWN    = 0,
		        IDMEF_DECOY_YES        = 1,
		        IDMEF_DECOY_NO         = 2
} IDMEFdecoy;

typedef enum _IDMEFaddress_category {
                        IDMEF_ADDRESS_CATEGORY_UNKNOWN = 0,
			IDMEF_ATM              = 1,
			IDMEF_E_MAIL           = 2,
			IDMEF_LOTUS_NOTES      = 3,
			IDMEF_MAC              = 4,
			IDMEF_SNA              = 5,
			IDMEF_VM               = 6,
			IDMEF_IPV4_ADDR        = 7,
			IDMEF_IPV4_ADDR_HEX    = 8,
			IDMEF_IPV4_NET         = 9,
                        IDMEF_IPV4_NET_MASK    = 10,
			IDMEF_IPV6_ADDR        = 11,
			IDMEF_IPV6_ADDR_HEX    = 12,
			IDMEF_IPV6_NET         = 13,
			IDMEF_IPV6_NET_MASK    = 14
} IDMEFaddress_category;

typedef enum _IDMEForigin {
                        IDMEF_UNKNOWN_ORIGIN   = 0,
			IDMEF_VENDOR_SPECIFIC  = 1,
			IDMEF_USER_SPECIFIC    = 2,
			IDMEF_BUGTRAQID        = 3,
			IDMEF_CVE              = 4,
			IDMEF_OSVDB            = 5
} IDMEForigin;

typedef enum _IDMEFnode_category {
                        IDMEF_NODE_CATEGORY_UNKNOWN = 0,
			IDMEF_ADS              = 1,
			IDMEF_AFS              = 2,
			IDMEF_CODA             = 3,
			IDMEF_DFS              = 4,
			IDMEF_DNS              = 5,
			IDMEF_HOSTS            = 6,
			IDMEF_KERBEROS         = 7,
			IDMEF_NDS              = 8,
			IDMEF_NIS              = 9,
			IDMEF_NISPLUS          = 10,
			IDMEF_NT               = 11,
			IDMEF_WFW              = 12
} IDMEFnode_category;

typedef enum _IDMEFaction_category {
			IDMEF_BLOCK_INSTALLED       = 0,
			IDMEF_NOTIFICATION_SENT     = 1,
			IDMEF_TAKEN_OFFLINE         = 2,
			IDMEF_ACTION_CATEGORY_OTHER = 3	/* nonzero default! */
} IDMEFaction_category;

typedef enum _IDMEFuser_category {
                        IDMEF_USER_CATEGORY_UNKNOWN = 0,
			IDMEF_APPLICATION      = 1,
			IDMEF_OS_DEVICE        = 2
} IDMEFuser_category;

typedef enum _IDMEFadditionaldata_type {
			IDMEF_BOOLEAN          = 0,
			IDMEF_BYTE             = 1,
			IDMEF_CHARACTER        = 2,
			IDMEF_DATETIME         = 3,
			IDMEF_INTEGER          = 4,
                        IDMEF_NTPSTAMP         = 5,
                        IDMEF_PORTLIST         = 6,
			IDMEF_REAL             = 7,
			IDMEF_STRING           = 8, /* nonzero default! */
			IDMEF_XML              = 9
} IDMEFadditionaldata_type;

typedef enum _IDMEFconfidence_rating {
			IDMEF_CONFIDENCE_RATING_LOW     = 0,
			IDMEF_CONFIDENCE_RATING_MEDIUM  = 1,
			IDMEF_CONFIDENCE_RATING_HIGH    = 2,
                        IDMEF_CONFIDENCE_RATING_NUMERIC = 3 /* nonzero default!*/
} IDMEFconfidence_rating;

typedef enum _IDMEFUserId_type {
                        IDMEF_CURRENT_USER     = 0,
			IDMEF_ORIGINAL_USER    = 1, /* nonzero default! */
			IDMEF_TARGET_USER      = 2,
			IDMEF_USER_PRIVS       = 3,
			IDMEF_CURRENT_GROUP    = 4,
			IDMEF_GROUP_PRIVS      = 5,
			IDMEF_OTHER_PRIVS      = 6
} IDMEFUserId_type;

typedef enum _IDMEFimpact_severity {
			/* unfortunately, no "unknown" and no default */
			IDMEF_IMPACT_SEVERITY_INFO       = 0,
			IDMEF_IMPACT_SEVERITY_LOW        = 1,
			IDMEF_IMPACT_SEVERITY_MEDIUM     = 2,
			IDMEF_IMPACT_SEVERITY_HIGH       = 3,

			/* NONSTANDARD -- hope that a future draft will
			 * define this as 0 */
			IDMEF_IMPACT_SEVERITY_UNKNOWN    = -1
} IDMEFimpact_severity;

typedef enum _IDMEFimpact_completion {
			/* unfortunately, no "unknown" and no default */
			IDMEF_FAILED           = 0,
			IDMEF_SUCCEEDED        = 1,

			/* NONSTANDARD -- hope that a future draft will
			 * define this as 0 */
			IDMEF_IMPACT_COMPLETION_UNKNOWN    = -1
} IDMEFimpact_completion;

typedef enum _IDMEFimpact_type {
			/* unfortunately, no "unknown" */
			IDMEF_ADMIN = 0,
			IDMEF_DOS   = 1,
			IDMEF_IMPACT_TYPE_FILE  = 2,
			IDMEF_RECON = 3,
                        IDMEF_USER  = 4,
                        IDMEF_IMPACT_TYPE_OTHER = 5 /* nonzero default! */
} IDMEFimpact_type;


typedef enum _IDMEFfile_category {
			/* no "unknown" and no default */
			IDMEF_CURRENT          = 0,
			IDMEF_ORIGINAL         = 1
} IDMEFfile_category;

typedef enum _IDMEFlinkage_category {
			/* no default */
			IDMEF_HARD_LINK        = 0,
			IDMEF_MOUNT_POINT      = 1,
			IDMEF_REPARSE_POINT    = 2,
			IDMEF_SHORTCUT         = 3,
			IDMEF_STREAM           = 4,
			IDMEF_SYMBOLIC_LINK    = 5
} IDMEFlinkage_category;

typedef enum _IDMEFchecksum_algorithm {
			/* no default */
			IDMEF_MD4              = 0,
			IDMEF_MD5              = 1,
			IDMEF_SHA1             = 2,
			IDMEF_SHA2_256         = 3,
			IDMEF_SHA2_384         = 4,
			IDMEF_SHA2_512         = 5,
			IDMEF_CRC_32           = 6,
			IDMEF_HAVAL            = 7,
			IDMEF_TIGER            = 8,
			IDMEF_GOST             = 9
} IDMEFchecksum_algorithm;

/*
 *  Struct definitions
 */

typedef struct _IDMEFaddress {
	char *ident;
	IDMEFaddress_category category;
	char *vlan_name;	
	int  *vlan_num;
	char *address;		/* required */
	char *netmask;
} IDMEFaddress;

typedef struct _IDMEFtime {
	char *ntpstamp;		/* required but will be generated from tv */
	char *string;           /* maybe required; will be generated from tv */
	struct timeval tv;	/* required */
} IDMEFtime;

typedef struct _IDMEFuserid {
	char *ident;
	IDMEFUserId_type type;
	char *name;		/* name, number, or both must be provided */
	int *number;		/* name, number, or both must be provided */
} IDMEFuserid;
	
typedef struct _IDMEFuser {
	char *ident;
	IDMEFuser_category category;
	size_t nuserids;
	size_t userids_capacity;
	IDMEFuserid **userids;	/* at least one is required */
} IDMEFuser;

typedef struct _IDMEFSNMPservice {
	char *oid;
	char *community;
	char *command;
} IDMEFSNMPservice;

typedef struct _IDMEFwebservice {
	char *url;		/* required */
	char *cgi;
	char *http_method;
	size_t narg;
	size_t arg_capacity;
	char **arg;
} IDMEFwebservice;

typedef struct _IDMEFservice {
	char *ident;
	int  *ip_version;
	int  *iana_protocol_number;
	char *iana_protocol_name;
	char *name;             /* name, port, or portlist must be provided */
	int  *port; /* host order. name, port, or portlist must be provided */
	char *portlist;         /* name, port, or portlist must be provided */
	char *protocol;
	IDMEFwebservice *webservice;
	IDMEFSNMPservice *snmpservice;
} IDMEFservice;

typedef struct _IDMEFprocess {
	char *ident;
	char *name;		/* required */
	int *pid;
	char *path;
	size_t narg;
	size_t arg_capacity;
	char **arg;
	size_t nenv;
	size_t env_capacity;
	char **env;
} IDMEFprocess;

typedef struct _IDMEFnode {
	char *ident;
	IDMEFnode_category category;
	char *location;
	char *name;             /* required unless addresses are provided */
	size_t naddresses;
	size_t addresses_capacity;
	IDMEFaddress **addresses; /* required unless name is provided */
} IDMEFnode;

typedef struct _IDMEFfileaccess {
	IDMEFuserid *userid;    /* required */
	size_t npermissions;    
	size_t permissions_capacity;
	char **permissions;     /* at least one required */
} IDMEFfileaccess;

typedef struct _IDMEFlinkage {
	IDMEFlinkage_category category;
	char *name;             /* required */
	char *path;             /* required */
	struct _IDMEFfile *file; /* required */
} IDMEFlinkage;

typedef struct _IDMEFinode {
	char *change_time;
	int *number;            /* required if {major,minor}_device appear  */
	int *major_device;      /* required if number or minor_device appear */
	int *minor_device;      /* required if number or major_device appear */
	int *c_major_device;    /* required if c_minor_device appears */
	int *c_minor_device;    /* required if c_major_device appears */
} IDMEFinode;

typedef struct _IDMEFchecksum {
	IDMEFchecksum_algorithm algorithm;
	char *value;
	char *key;
} IDMEFchecksum;

typedef struct _IDMEFfile {
	char *ident;
	IDMEFfile_category category; /* required */
	char *fstype;
	char *name;             /* required */
	char *path;             /* required */
	char *create_time;
	char *modify_time;
	char *access_time;
	int *data_size;
	int *disk_size;
	size_t nfileaccesses;
	size_t fileaccesses_capacity;
	IDMEFfileaccess **fileaccesses;
	size_t nlinkages;
	size_t linkages_capacity;
	IDMEFlinkage **linkages;
	IDMEFinode *inode;
	size_t nchecksums;
	size_t checksums_capacity;
	IDMEFchecksum **checksums;
} IDMEFfile;

typedef struct _IDMEFfilelist {
	size_t nfiles;
	size_t files_capacity;
	IDMEFfile **files;      /* at least one required */
} IDMEFfilelist;

typedef struct _IDMEFsource {
	char *ident;
	IDMEFspoofed spoofed;
	char *interface;
	IDMEFnode *node;
	IDMEFuser *user;
	IDMEFprocess *process;
	IDMEFservice *service;
} IDMEFsource;

typedef struct _IDMEFtarget {
	char *ident;
	IDMEFdecoy decoy;
	char *interface;
	IDMEFnode *node;
	IDMEFuser *user;
	IDMEFprocess *process;
	IDMEFservice *service;
	IDMEFfilelist *filelist;
} IDMEFtarget;
	
typedef struct _IDMEFreference {
	IDMEForigin origin;     /* required */
	char *meaning;
	char *name;             /* required */
	char *url;              /* required */
} IDMEFreference;

typedef struct _IDMEFclassification {
	char *ident;
	char *text;             /* required */
	size_t nreferences;
	size_t references_capacity;
	IDMEFreference **references;
} IDMEFclassification;

typedef struct _IDMEFimpact {
	IDMEFimpact_severity severity;
	IDMEFimpact_completion completion;
	IDMEFimpact_type type;
	char *data;
} IDMEFimpact;

typedef struct _IDMEFaction {
	IDMEFaction_category category;
	char *data;
} IDMEFaction;

typedef struct _IDMEFconfidence {
	IDMEFconfidence_rating rating;
	char *data;
} IDMEFconfidence;
	
typedef struct _IDMEFassessment {
	IDMEFimpact *impact;
	size_t nactions;
	size_t actions_capacity;
	IDMEFaction **actions;
	IDMEFconfidence *confidence;
} IDMEFassessment;

typedef struct _IDMEFadditionaldata {
	IDMEFadditionaldata_type type;
	char *meaning;
	union {
		/* choose based on type */
		/* XXX all these char * should be xmlChar * */

		/* 1 or 0 */
		int           data_boolean;
		/* avoid using type="byte".  can't represent arbitrary byte
		 * values due to xml restrictions on character references. */
		char *        data_byte;
		char *        data_character;
		char *        data_datetime;
		int           data_integer;
		char *        data_ntpstamp;
		/* Using char * for data_real to avoid loss of precision.
		 * Caller can use get_real() to parse. */
		char *        data_real;
		char *        data_portlist;
		char *        data_string;
		xmlNodePtr    data_xml;
	} data;
} IDMEFadditionaldata;

typedef struct _IDMEFanalyzer {
	char *analyzerid;       /* required if any 'ident' attribs are used */
	char *name;
	char *manufacturer;
	char *model;
	char *version;
	char *cls;
	char *ostype;
	char *osversion;
	IDMEFnode *node;
	IDMEFprocess *process;
	struct _IDMEFanalyzer *analyzer;
} IDMEFanalyzer;

typedef struct _IDMEFalertident {
	char *data;
	char *analyzerid;
} IDMEFalertident;

typedef struct _IDMEFtoolalert {
	char *name;             /* required */
	char *command;
	size_t nalertidents;
	size_t alertidents_capacity;
	IDMEFalertident **alertidents; /* at least one required */
} IDMEFtoolalert;

typedef struct _IDMEFoverflowalert {
	char *program;          /* required */
	int *size;
	char *buffer;
} IDMEFoverflowalert;

typedef struct _IDMEFcorrelationalert {
	char *name;             /* required */
	size_t nalertidents;
	size_t alertidents_capacity;
	IDMEFalertident **alertidents; /* at least one required */
} IDMEFcorrelationalert;

typedef struct _IDMEFalert {
	char *messageid;
	IDMEFanalyzer *analyzer;    /* required */
	IDMEFtime *createtime;	    /* required */
	IDMEFtime *detecttime;
	IDMEFtime *analyzertime;
	size_t nsources;
	size_t sources_capacity;
	IDMEFsource **sources;
	size_t ntargets;
	size_t targets_capacity;
	IDMEFtarget **targets;
	IDMEFclassification *classification;
	IDMEFassessment *assessment;
	IDMEFcorrelationalert *correlationalert;
	IDMEFtoolalert *toolalert;
	IDMEFoverflowalert *overflowalert;
	size_t nadditionaldatas;
	size_t additionaldatas_capacity;
	IDMEFadditionaldata **additionaldatas;
} IDMEFalert;

typedef struct _IDMEFheartbeat {
	char *messageid;
	IDMEFanalyzer *analyzer; /* required */
	IDMEFtime *createtime;   /* required */
	IDMEFtime *analyzertime;
	size_t nadditionaldatas;
	size_t additionaldatas_capacity;
	IDMEFadditionaldata **additionaldatas;
} IDMEFheartbeat;

typedef struct _IDMEFmessage {
	char *version;          /* required -- use IDMEF_MESSAGE_VERSION */
	size_t nalerts;
	size_t alerts_capacity;
	IDMEFalert **alerts;
	size_t nheartbeats;
	size_t heartbeats_capacity;
	IDMEFheartbeat **heartbeats;
} IDMEFmessage;

#ifdef __cplusplus
}
#endif /* __cplusplus */


/* Make emacs handle 8-column indentation used in this file:
 * Local Variables:
 * c-basic-offset:8
 * indent-tabs-mode:t
 * tab-width:8
 * End: */

#endif /* _IDMEFXML_TYPES_H */
