/*
idmefxml_parse.h: header file for libidmef parsing functions
Author: Adam Migus, NAI Labs, (amigus@nai.com)

Copyright (c) 2001 Networks Associates Technology, Inc.
All rights reserved

This library is released under the GNU GPL and BSD software licenses.
You may choose to use one or the other, BUT NOT BOTH.  The GNU GPL
license is located in the file named COPYING.  The BSD license is located
in the file named COPYING.BSD.  Please contact us if there are any
questions.

$Id: idmefxml_parse.h,v 1.4 2004/08/19 03:04:45 dkindred Exp $
*/

#ifndef _IDMEFXML_PARSE_H
#define _IDMEFXML_PARSE_H 1

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/*
 * Return the internal representation of an IDMEFmessage from a file or
 * a buffer respectively.
 */
IDMEFmessage * get_idmef_message_from_doc(xmlDocPtr doc, int validate);
IDMEFmessage * get_idmef_message_from_file(const char *filename, int validate);
IDMEFmessage * get_idmef_message(const char *buffer, int size, int validate);

/*
 * Return the internal representation of IDMEFmessage components as strings
 * or as their internal representation, respectively.
 */
const char * node_category_as_string(IDMEFnode_category category);
IDMEFnode_category get_node_category(const char *p);

const char * address_category_as_string(IDMEFaddress_category category);
IDMEFaddress_category get_address_category(const char *p);

IDMEFspoofed get_spoofed(const char *p);
const char * spoofed_as_string(IDMEFspoofed spoofed);

IDMEFdecoy get_decoy(const char *p);
const char * decoy_as_string(IDMEFdecoy decoy);

IDMEFuser_category get_user_category(const char *p);
const char * user_category_as_string(IDMEFuser_category category);

IDMEFUserId_type get_userid_type(const char *p);
const char * userid_type_as_string(IDMEFUserId_type type);

IDMEForigin get_reference_origin(const char *p);
const char * reference_origin_as_string(IDMEForigin origin);

IDMEFadditionaldata_type get_additionaldata_type(const char *p);
const char * additionaldata_type_as_string(IDMEFadditionaldata_type type);

IDMEFimpact_severity get_impact_severity(const char *p);
const char * impact_severity_as_string(IDMEFimpact_severity severity);

IDMEFimpact_completion get_impact_completion(const char *p);
const char * impact_completion_as_string(IDMEFimpact_completion completion);

IDMEFimpact_type get_impact_type(const char *p);
const char * impact_type_as_string(IDMEFimpact_type type);

IDMEFaction_category get_action_category(const char *p);
const char * action_category_as_string(IDMEFaction_category category);

IDMEFconfidence_rating get_confidence_rating(const char *p);
const char * confidence_rating_as_string(IDMEFconfidence_rating rating);

IDMEFfile_category get_file_category(const char *p);
const char * file_category_as_string(IDMEFfile_category category);

IDMEFlinkage_category get_linkage_category(const char *p);
const char * linkage_category_as_string(IDMEFlinkage_category category);

IDMEFchecksum_algorithm get_checksum_algorithm(const char *p);
const char * checksum_algorithm_as_string(IDMEFchecksum_algorithm algorithm);

int get_boolean(const char *p);
const char *boolean_as_string(int boolean_value);

long get_integer(const char *p);
/* caller must free returned value! */
char *integer_as_string(long integer_value);

double get_real(const char *p);
/* caller must free returned value! */
char *real_as_string(double real_value, int precision);


/*
 * Structure initialization routines.
 */
void init_userid(IDMEFuserid *userid);
void init_user(IDMEFuser *user);
void init_time(IDMEFtime *time);
void init_address(IDMEFaddress *address);
void init_process(IDMEFprocess *process);
void init_additionaldata(IDMEFadditionaldata *additionaldata);
void init_classification(IDMEFclassification *classification);
void init_reference(IDMEFreference *reference);
void init_impact(IDMEFimpact *impact);
void init_action(IDMEFaction *action);
void init_confidence(IDMEFconfidence *confidence);
void init_assessment(IDMEFassessment *assessment);
void init_node(IDMEFnode *node);
void init_webservice(IDMEFwebservice *webservice);
void init_snmpservice(IDMEFSNMPservice *snmpservice);
void init_service(IDMEFservice *service);
void init_linkage(IDMEFlinkage *linkage);
void init_inode(IDMEFinode *inode);
void init_checksum(IDMEFchecksum *checksum);
void init_fileaccess(IDMEFfileaccess *fileaccess);
void init_file(IDMEFfile *file);
void init_filelist(IDMEFfilelist *filelist);
void init_target(IDMEFtarget *target);
void init_source(IDMEFsource *source);
void init_analyzer(IDMEFanalyzer *analyzer);
void init_alertident(IDMEFalertident *alertident);
void init_overflowalert(IDMEFoverflowalert *overflowalert);
void init_toolalert(IDMEFtoolalert *toolalert);
void init_correlationalert(IDMEFcorrelationalert *correlationalert);
void init_heartbeat(IDMEFheartbeat *heartbeat);
void init_alert(IDMEFalert *alert);
void init_message(IDMEFmessage *message);

/*
 * Allocation & initialization routines.
 */
IDMEFuserid *           new_userid(void);
IDMEFuser *             new_user(void);
IDMEFtime *             new_time(void);
IDMEFaddress *          new_address(void);
IDMEFprocess *          new_process(void);
IDMEFadditionaldata *   new_additionaldata(void);
IDMEFclassification *   new_classification(void);
IDMEFreference *        new_reference(void);
IDMEFimpact *           new_impact(void);
IDMEFaction *           new_action(void);
IDMEFconfidence *       new_confidence(void);
IDMEFassessment *       new_assessment(void);
IDMEFnode *             new_node(void);
IDMEFwebservice *       new_webservice(void);
IDMEFSNMPservice *      new_snmpservice(void);
IDMEFservice *          new_service(void);
IDMEFlinkage *          new_linkage(void);
IDMEFinode *            new_inode(void);
IDMEFchecksum *         new_checksum(void);
IDMEFfileaccess *       new_fileaccess(void);
IDMEFfile *             new_file(void);
IDMEFfilelist *         new_filelist(void);
IDMEFtarget *           new_target(void);
IDMEFsource *           new_source(void);
IDMEFanalyzer *         new_analyzer(void);
IDMEFalertident *       new_alertident(void);
IDMEFoverflowalert *    new_overflowalert(void);
IDMEFtoolalert *        new_toolalert(void);
IDMEFcorrelationalert * new_correlationalert(void);
IDMEFheartbeat *        new_heartbeat(void);
IDMEFalert *            new_alert(void);
IDMEFmessage *          new_message(void);

/*
 * Routines for adding items to the various lists in IDMEFmessage and friends.
 */
void add_user_userid(IDMEFuser *user, IDMEFuserid *userid);
void add_webservice_arg(IDMEFwebservice *webservice, char *arg);
void add_process_arg(IDMEFprocess *process, char *arg);
void add_process_env(IDMEFprocess *process, char *env);
void add_classification_reference(IDMEFclassification *c, IDMEFreference *r);
void add_node_address(IDMEFnode *node, IDMEFaddress *address);
void add_fileaccess_permission(IDMEFfileaccess *fileaccess, char *permission);
void add_file_fileaccess(IDMEFfile *file, IDMEFfileaccess *fileaccess);
void add_file_linkage(IDMEFfile *file, IDMEFlinkage *linkage);
void add_file_checksum(IDMEFfile *file, IDMEFchecksum *checksum);
void add_filelist_file(IDMEFfilelist *filelist, IDMEFfile *file);
void add_assessment_action(IDMEFassessment *assessment, IDMEFaction *action);
void add_toolalert_alertident(IDMEFtoolalert *ta, IDMEFalertident *alertident);
void add_correlationalert_alertident(IDMEFcorrelationalert *ca,
				     IDMEFalertident *alertident);
void add_alert_source(IDMEFalert *alert, IDMEFsource *source);
void add_alert_target(IDMEFalert *alert, IDMEFtarget *target);
void add_alert_additionaldata(IDMEFalert *alert, IDMEFadditionaldata *d);
void add_heartbeat_additionaldata(IDMEFheartbeat *hb, IDMEFadditionaldata *d);
void add_message_alert(IDMEFmessage *message, IDMEFalert *alert);
void add_message_heartbeat(IDMEFmessage *message, IDMEFheartbeat *heartbeat);


/*
 * Parsing routines.
 */
int parse_userid(const xmlNode * cur, IDMEFuserid *userid);
int parse_user(const xmlNode * cur, IDMEFuser *user);
int parse_time(const xmlNode * cur, IDMEFtime *time);
int parse_address(const xmlNode * cur, IDMEFaddress *address);
int parse_process(const xmlNode * cur, IDMEFprocess *process);
int parse_additionaldata(const xmlNode * cur, IDMEFadditionaldata *additionaldata);
int parse_classification(const xmlNode * cur, IDMEFclassification *classification);
int parse_reference(const xmlNode * cur, IDMEFreference *reference);
int parse_impact(const xmlNode * cur, IDMEFimpact *impact);
int parse_action(const xmlNode * cur, IDMEFaction *action);
int parse_confidence(const xmlNode * cur, IDMEFconfidence *confidence);
int parse_assessment(const xmlNode * cur, IDMEFassessment *assessment);
int parse_node(const xmlNode * cur, IDMEFnode *node);
int parse_webservice(const xmlNode * cur, IDMEFwebservice *webservice);
int parse_snmpservice(const xmlNode * cur, IDMEFSNMPservice *snmpservice);
int parse_service(const xmlNode * cur, IDMEFservice *service);
int parse_linkage(const xmlNode * cur, IDMEFlinkage *linkage);
int parse_inode(const xmlNode * cur, IDMEFinode *inode);
int parse_checksum(const xmlNode * cur, IDMEFchecksum *checksum);
int parse_fileaccess(const xmlNode * cur, IDMEFfileaccess *fileaccess);
int parse_file(const xmlNode * cur, IDMEFfile *file);
int parse_filelist(const xmlNode * cur, IDMEFfilelist *filelist);
int parse_target(const xmlNode * cur, IDMEFtarget *target);
int parse_source(const xmlNode * cur, IDMEFsource *source);
int parse_analyzer(const xmlNode * cur, IDMEFanalyzer *analyzer);
int parse_alertident(const xmlNode * cur, IDMEFalertident *alertident);
int parse_overflowalert(const xmlNode * cur, IDMEFoverflowalert *overflowalert);
int parse_toolalert(const xmlNode * cur, IDMEFtoolalert *toolalert);
int parse_correlationalert(const xmlNode * cur,
			IDMEFcorrelationalert *correlationalert);
int parse_heartbeat(const xmlNode * cur, IDMEFheartbeat *heartbeat);
int parse_alert(const xmlNode * cur, IDMEFalert *alert);
int parse_message(const xmlNode * cur, IDMEFmessage *message);

/*
 * Deallocation routines.
 */
void free_webservice(IDMEFwebservice *webservice);
void free_snmpservice(IDMEFSNMPservice *snmpservice);
void free_service(IDMEFservice *service);
void free_userid(IDMEFuserid *userid);
void free_user(IDMEFuser *user);
void free_time(IDMEFtime *time);
void free_address(IDMEFaddress *address);
void free_node(IDMEFnode *node);
void free_process(IDMEFprocess *process);
void free_fileaccess(IDMEFfileaccess *fileaccess);
void free_linkage(IDMEFlinkage *linkage);
void free_inode(IDMEFinode *inode);
void free_checksum(IDMEFchecksum *checksum);
void free_file(IDMEFfile *file);
void free_filelist(IDMEFfilelist *filelist);
void free_source(IDMEFsource *source);
void free_target(IDMEFtarget *target);
void free_analyzer(IDMEFanalyzer *analyzer);
void free_alertident(IDMEFalertident *alertident);
void free_correlationalert(IDMEFcorrelationalert *correlationalert);
void free_toolalert(IDMEFtoolalert *toolalert);
void free_overflowalert(IDMEFoverflowalert *overflowalert);
void free_additionaldata(IDMEFadditionaldata *additionaldata);
void free_classification(IDMEFclassification *classification);
void free_reference(IDMEFreference *reference);
void free_impact(IDMEFimpact *impact);
void free_action(IDMEFaction *action);
void free_confidence(IDMEFconfidence *confidence);
void free_assessment(IDMEFassessment *assessment);
void free_alert(IDMEFalert *alert);
void free_heartbeat(IDMEFheartbeat *heartbeat);
void free_message(IDMEFmessage *message);

#ifdef __cplusplus
}
#endif /* __cplusplus */

/* Make emacs handle 8-column indentation used in this file:
 * Local Variables:
 * c-basic-offset:8
 * indent-tabs-mode:t
 * tab-width:8
 * End: */

#endif /* _IDMEFXML_PARSE_H */
