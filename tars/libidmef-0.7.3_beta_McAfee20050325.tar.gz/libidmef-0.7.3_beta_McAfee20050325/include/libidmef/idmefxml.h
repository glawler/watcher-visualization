/************************************************************************
 * libidmef: A library to create IDMEF messages in XML format.
 * Author: Joe McAlerney, Silicon Defense, (joey@SiliconDefense.com)
 *
 * Copyright (c) 2000,2001 by Silicon Defense (http://www.silicondefense.com/)
 * 
 * This library is released under the GNU GPL and BSD software licenses.
 * You may choose to use one or the other, BUT NOT BOTH.  The GNU GPL
 * license is located in the file named COPYING.  The BSD license is located
 * in the file named COPYING.BSD.  Please contact us if there are any
 * questions.
 **************************************************************************/

/***************************************************************
* This is an implementation of the IDMEF XML DTD described in
* draft-ietf-idwg-idmef-xml-05.txt
****************************************************************/

#ifndef IDMEF_XML_H
#define IDMEF_XML_H 1

#include <stdarg.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#ifdef WIN32
typedef unsigned long ulong; /* windows uses ULONG, but not ulong */
#endif

#ifdef FREEBSD 
typedef unsigned long ulong; /* windows uses ULONG, but not ulong */
#endif


#define MAX_ALERTID_BUFFER_SIZE 11   /* ulong (2^32 + 1) */
#define TZ_SIZE                 6    /* +hh:mm */
#define MAX_NTP_TIMESTAMP_SIZE  21   /* 0xNNNNNNNN.0xNNNNNNNN */

#if !defined(__GNUC__) && !defined(__attribute__)
#define __attribute__(x)
#endif

/*=================================================*
 *               Datatype definitions              *
 *=================================================*/

typedef struct _IDMEFlib_config {
	/* path to IDMEF DTD.  If NULL, IDMEF_DTD_PATH is used. */
	const char *dtd_path;
	/* IDMEF DTD external ID. (If dtd_path is NULL, this defaults
	 * to IDMEF_DTD_EXTERNAL_ID.  Otherwise NULL means use SYSTEM
	 * doctype.) */
	const char *dtd_external_id;

	/* Ptr to function for logging debug, warning, error messages.
	 * If NULL, fprintf to stderr (or FILE* in log_arg) will be used.
	 */
	void (*logf)(void *arg, int level, const char *fmt, va_list ap);

	/* fixed argument to be passed to the log function */
	void *log_arg;

	/* standard log levels */
	int log_level_debug;
	int log_level_warn;
	int log_level_error;

	/* Memory allocation functions (default to malloc/realloc/free).
	 * If an allocation function returns NULL, libidmef will call abort(),
	 * so these functions should implement their own recovery mechanisms
	 * if desired (e.g., longjmp to error handler).
	 */
	void *(*mallocf)(void *arg, size_t size);
	void *(*reallocf)(void *arg, void *ptr, size_t size);
	void (*freef)(void *arg, void *ptr);
	
	/* fixed argument to be passed to allocation functions */
	void *alloc_arg;


	/* for libidmef internal use only -- clients should not touch these */
	xmlDtdPtr dtd;

} IDMEFlib_config;


/*=================================================*
 *               Function Prototypes               *
 *=================================================*/

struct timeval;

/*=============================================================================
   New Element functions  

   Sub-elements/attributes that are not required, or additonal instances
   of the required ones, will be appended at the end of the parameter string -
   denoted by "..."
 ============================================================================*/

xmlNodePtr newIDMEF_Message(xmlNodePtr, ...);
xmlNodePtr newAlert(xmlNodePtr, ...);
xmlNodePtr newToolAlert(xmlNodePtr, ...);
xmlNodePtr newCorrelationAlert(xmlNodePtr, ...);
xmlNodePtr newOverflowAlert(xmlNodePtr, ...);
xmlNodePtr newHeartbeat(xmlNodePtr, ...);

xmlNodePtr newAnalyzer(xmlNodePtr, ...);
xmlNodePtr newAssessment(xmlNodePtr, ...);
xmlNodePtr newClassification(xmlNodePtr, ...);
xmlNodePtr newReference(xmlNodePtr, ...);
xmlNodePtr newSource(xmlNodePtr, ...);
xmlNodePtr newTarget(xmlNodePtr, ...);
xmlNodePtr newAdditionalData(xmlNodePtr, ...);

xmlNodePtr newTime(const char *, const struct timeval *, 
		   const char *, const char *);
xmlNodePtr newCreateTime(const struct timeval *, const char *, const char *);
xmlNodePtr newAnalyzerTime(const struct timeval *, const char *, const char *);
xmlNodePtr newDetectTime(const struct timeval *, const char *, const char *);

xmlNodePtr newImpact(xmlNodePtr, ...);
xmlNodePtr newAction(xmlNodePtr, ...);
xmlNodePtr newConfidence(xmlNodePtr, ...);

xmlNodePtr newNode(xmlNodePtr, ...);
xmlNodePtr newAddress(xmlNodePtr, ...);
xmlNodePtr newUser(xmlNodePtr, ...);
xmlNodePtr newUserId(xmlNodePtr, ...);
xmlNodePtr newProcess(xmlNodePtr, ...);
xmlNodePtr newService(xmlNodePtr, ...);
xmlNodePtr newWebService(xmlNodePtr, ...);
xmlNodePtr newFileList(xmlNodePtr, ...);
xmlNodePtr newFile(xmlNodePtr, ...);
xmlNodePtr newFileAccess(xmlNodePtr, ...);
xmlNodePtr newLinkage(xmlNodePtr, ...);
xmlNodePtr newInode(xmlNodePtr, ...);
xmlNodePtr newChecksum(xmlNodePtr, ...);
xmlNodePtr newSNMPService(xmlNodePtr, ...);


xmlNodePtr newSimpleElement(const char *, const char *);
xmlNodePtr newAttribute(const char *, const char *);

/*-----------------------------------------------------------------------*
 * These are functions that perform different operations on XML elements
 * that have been created with the above "new" functions.
 *-----------------------------------------------------------------------*/

xmlNodePtr addElement(xmlNodePtr, xmlNodePtr);
int addElements(xmlNodePtr, xmlNodePtr, ...);
xmlNodePtr setAttribute(xmlNodePtr, xmlNodePtr);
int setAttributes(xmlNodePtr, xmlNodePtr, ...);
xmlNodePtr getElement(xmlNodePtr, const char *);
int hasElement(xmlNodePtr, const char *);

/*-------------------------------------------------------------------------*
 * These are functions that perform different operations on XML documents.
 *-------------------------------------------------------------------------*/

int idmefInit(IDMEFlib_config *config);
xmlDocPtr createDoc(const char *xml_version, 
                    xmlNodePtr root,
                    int include_doctype);
void addAuxDtd(xmlDocPtr doc,
               const xmlChar *name,
               const xmlChar *aux_dtd_path);
int validateDoc(xmlValidCtxtPtr vctxt, xmlDocPtr doc);
void printDocument(FILE *, xmlDocPtr doc);

/*-----------------------------------------------------------------
 * Config-dependent functions, primarily for internal libidmef use
 *-----------------------------------------------------------------*/
/* these use the global idmef_config */
void *idmef_malloc(size_t size);
void *idmef_realloc(void *ptr, size_t size);
void idmef_free(void *ptr);
void idmef_logv(int level, const char *fmt, va_list ap);
void idmef_debug(const char *fmt, ...)
	__attribute__((__format__ (printf, 1, 2)));
void idmef_warn (const char *fmt, ...)
	__attribute__((__format__ (printf, 1, 2)));
void idmef_error(const char *fmt, ...)
	__attribute__((__format__ (printf, 1, 2)));

/* these take an IDMEFlib_config* argument explicitly */
void idmef_logv_cfg(IDMEFlib_config *cfg, 
		    int level, const char *fmt, va_list ap);
void idmef_debug_cfg(IDMEFlib_config *cfg, const char *fmt, ...)
	__attribute__((__format__ (printf, 2, 3)));
void idmef_warn_cfg(IDMEFlib_config *cfg, const char *fmt, ...)
	__attribute__((__format__ (printf, 2, 3)));
void idmef_error_cfg(IDMEFlib_config *cfg, const char *fmt, ...)
	__attribute__((__format__ (printf, 2, 3)));

/*---------------------------------------
 * Miscellaneous time format functions.
 *---------------------------------------*/

xmlChar *currentNtpTimestamp(void);
xmlChar *currentDatetime(void);
xmlChar *timevalToNtpTimestamp(const struct timeval *);
xmlChar *timevalToDatetime(const struct timeval *);
int testTime(void);


/*--------------------------------
 * Other utility functions
 *-------------------------------*/

unsigned long getStoredAlertID(const char *);
int saveAlertID(unsigned long, const char *);
void badNode(xmlNodePtr, const char *);
char * intToString(int);
char * ulongToString(unsigned long);
xmlDocPtr xmlAddIntSubset(xmlDocPtr, xmlDtdPtr);
xmlDtdPtr xmlRemoveIntSubset(xmlDocPtr);
char * ntpstampToString(void *);
xmlOutputBufferPtr IDMEFxmlOutputBufferCreate(FILE *, xmlCharEncodingHandlerPtr);
void IDMEFxmlDocContentDumpOutput(xmlOutputBufferPtr, xmlDocPtr, 
                                  const char *, int);
int IDMEFxmlFileWrite (void *, const char *, int);
/* use LIBIDMEF_VERSION (from idmefxml_global.h) to determine the
 * version of libidmef headers an app was *compiled* against; use
 * libidmef_version() to determine the libidmef version you are linked with. */
const char *libidmef_version(void);

#ifdef __cplusplus
}
#endif /* __cplusplus */

/* Make emacs handle 8-column indentation used in this file:
 * Local Variables:
 * c-basic-offset:8
 * indent-tabs-mode:t
 * tab-width:8
 * End: */

#endif /* IDMEF_XML_H */
