/*
idmefxml_gen.c: libidmef message generation functions
Author: Adam Migus NAI Labs (amigus@nai.com)

Copyright (c) 2001 Networks Associates Technology, Inc.
All rights reserved

This library is released under the GNU GPL and BSD software licenses.
You may choose to use one or the other, BUT NOT BOTH.  The GNU GPL
license is located in the file named COPYING.  The BSD license is located
in the file named COPYING.BSD.  Please contact us if there are any
questions.

This code creates messages that adhere to the specification put forth by
the IETF IDWG in the standards document draft-ietf-idwg-idmef-xml-12.txt.

$Id: idmefxml_gen.c,v 1.23 2005/01/21 03:54:35 dkindred Exp $
*/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include <stdio.h>
#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#endif
#ifdef HAVE_STRING_H
#include <string.h>
#endif
#ifdef HAVE_STRINGS_H
#include <strings.h>
#endif
#ifdef HAVE_NETDB_H
#include <netdb.h>
#endif
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#if TIME_WITH_SYS_TIME
# include <sys/time.h>
# include <time.h>
#else
# if HAVE_SYS_TIME_H
#  include <sys/time.h>
# else
#  include <time.h>
# endif
#endif

#include <libxml/tree.h>
#include <libxml/xmlmemory.h>
#include <libxml/parser.h>
#include <libxml/valid.h>
#include <libxml/entities.h>
#include <libxml/debugXML.h>
#include <libxml/xmlIO.h>
#include <libxml/xmlerror.h>

#include <libidmef/idmefxml_global.h>
#include <libidmef/idmefxml_types.h>
#include <libidmef/idmefxml_parse.h>
#include <libidmef/idmefxml_gen.h>
#include <libidmef/idmefxml.h>

#ifdef IDMEF_DEBUG
#define DEBUG 1
#else
#define DEBUG 0
#endif /* IDMEF_DEBUG */

/*
** Name: build_XXX where XXX is an element type defined in the
** IDMEF message exchange format specification.  Types are in
** lowercase in all cases.
**
** Purpose: The build_XXX function builds an XML representation
** of the structure of type XXX.
** 
** Arguments: In all cases the only argument is the C structure
** of type XXX.
**
** Returns: An XML Node pointer where the root node is type IDMEF
** type XXX.
**
** Notes:
**
*/

xmlNodePtr 
build_time(const char *name, const IDMEFtime *t) {
	return newTime(name, &t->tv, t->ntpstamp, t->string);
}

xmlNodePtr
build_address(const IDMEFaddress *address) {
	xmlNodePtr cur = newAddress(NULL);

	if(address->ident)
		setAttribute(cur, newAttribute("ident", address->ident));
	
	if(address->category != IDMEF_ADDRESS_CATEGORY_UNKNOWN)
		setAttribute(cur, newAttribute("category",
		address_category_as_string(address->category)));

	if(address->vlan_name)
		setAttribute(cur, newAttribute("vlan-name",
			address->vlan_name));

	if(address->vlan_num) {
		char buf[BUFSIZ];
		memset(buf, '\0', sizeof(buf));
		sprintf(buf, "%d", *address->vlan_num);
		setAttribute(cur,
		newAttribute("vlan-num", buf));
	}

	if(address->address)
		addElement(cur,
		newSimpleElement("address", address->address));

	if(address->netmask)
		addElement(cur,
		newSimpleElement("netmask", address->netmask));

	return cur;
}

xmlNodePtr
build_userid(const IDMEFuserid *userid) {
	xmlNodePtr cur = newUserId(NULL);

	if(userid->ident)
		setAttribute(cur, newAttribute("ident", userid->ident));

	if(userid->type != IDMEF_ORIGINAL_USER)
		setAttribute(cur, newAttribute("type",
		userid_type_as_string(userid->type)));

	if(userid->name)
		addElement(cur,
		newSimpleElement("name", userid->name));

	if(userid->number) {
		char buf[BUFSIZ];
		memset(buf, '\0', sizeof(buf));
		sprintf(buf, "%d", *userid->number);
		addElement(cur,
		newSimpleElement("number", buf));
	}

	return cur;
}

xmlNodePtr
build_user(const IDMEFuser *user) {
	xmlNodePtr cur = newUser(NULL);
	int i = 0;

	if(user->ident)
		setAttribute(cur, newAttribute("ident", user->ident));

	if(user->category != IDMEF_USER_CATEGORY_UNKNOWN)
		setAttribute(cur, newAttribute("category",
		user_category_as_string(user->category)));

	for(i = 0; i < user->nuserids; i++) {
		addElement(cur, build_userid(user->userids[i]));
	}

	return cur;
}

xmlNodePtr
build_SNMPservice(const IDMEFSNMPservice *SNMPservice) {
	xmlNodePtr cur = newSNMPService(NULL);

	if(SNMPservice->oid)
		addElement(cur,
		newSimpleElement("oid", SNMPservice->oid));

	if(SNMPservice->community)
		addElement(cur,
		newSimpleElement("community", SNMPservice->community));

	if(SNMPservice->command)
		addElement(cur,
		newSimpleElement("command", SNMPservice->command));

	return cur;
}

xmlNodePtr
build_webservice(const IDMEFwebservice *webservice) {
	xmlNodePtr cur = newWebService(NULL);
	int i = 0;

	if(webservice->url)
		addElement(cur,
		newSimpleElement("url", webservice->url));

	if(webservice->cgi)
		addElement(cur,
		newSimpleElement("cgi", webservice->cgi));

	if(webservice->http_method)
		addElement(cur,
		newSimpleElement("http-method", webservice->http_method));

	for(i = 0; i < webservice->narg; i++) {
		addElement(cur,
		newSimpleElement("arg", webservice->arg[i]));
	}

	return cur;
}

xmlNodePtr
build_service(const IDMEFservice *service) {
	xmlNodePtr cur = newService(NULL);

	if(service->ident)
		setAttribute(cur, newAttribute("ident", service->ident));

	if(service->ip_version) {
		char buf[BUFSIZ];
		sprintf(buf, "%d", *service->ip_version);
		setAttribute(cur, newAttribute("ip_version", buf));
	}

	if(service->iana_protocol_number) {
		char buf[BUFSIZ];
		sprintf(buf, "%d", *service->iana_protocol_number);
		setAttribute(cur, newAttribute("iana_protocol_number", buf));
	}

	if(service->iana_protocol_name)
		setAttribute(cur, newAttribute("iana_protocol_name",
					       service->iana_protocol_name));

	if(service->name)
		addElement(cur,
		newSimpleElement("name", service->name));


	if(service->port) {
		char buf[BUFSIZ];
		memset(buf, '\0', sizeof(buf));
		sprintf(buf, "%d", *service->port);
		addElement(cur,
		newSimpleElement("port", buf));
	}

	if(service->portlist)
		addElement(cur,
		newSimpleElement("portlist", service->portlist));

	if(service->protocol)
		addElement(cur,
		newSimpleElement("protocol", service->protocol));

	if(service->webservice)
		addElement(cur,
		build_webservice(service->webservice));

	if(service->snmpservice)
		addElement(cur,
		build_SNMPservice(service->snmpservice));

	return cur;
}

xmlNodePtr
build_process(const IDMEFprocess *process) {
	xmlNodePtr cur = newProcess(NULL);
	int i;

	if(process->ident)
		setAttribute(cur, newAttribute("ident", process->ident));

	if(process->name)
		addElement(cur, 	
		newSimpleElement("name", process->name));

	if(process->pid) {
		char buf[BUFSIZ];
		memset(buf, '\0', sizeof(buf));
		sprintf(buf, "%d", *process->pid);
		addElement(cur,
		newSimpleElement("pid", buf));
	}

	if(process->path)
		addElement(cur, 	
		newSimpleElement("path", process->path));

	for(i = 0; i < process->narg; i++) {
		addElement(cur,
		newSimpleElement("arg", process->arg[i]));
	}

	for(i = 0; i < process->nenv; i++) {
		addElement(cur,
		newSimpleElement("env", process->env[i]));
	}

	return cur;
}

xmlNodePtr
build_node(const IDMEFnode *node) {
	xmlNodePtr cur = newNode(NULL);
	int i;

	if(node->ident)
		setAttribute(cur, newAttribute("ident", node->ident));

	if(node->category != IDMEF_NODE_CATEGORY_UNKNOWN)
		setAttribute(cur, newAttribute("category",
		node_category_as_string(node->category)));

	if(node->location)
		addElement(cur,
		newSimpleElement("location", node->location));

	if(node->name)
		addElement(cur,
		newSimpleElement("name", node->name));

	for(i = 0; i < node->naddresses; i++) {
		addElement(cur, build_address(node->addresses[i]));
	}

	return cur;
}

xmlNodePtr
build_source(const IDMEFsource *source) {
	xmlNodePtr cur = newSource(NULL);

	if(source->ident)
		setAttribute(cur, newAttribute("ident", source->ident));
	
	if(source->spoofed != IDMEF_SPOOFED_UNKNOWN)
		setAttribute(cur, newAttribute("spoofed",
		spoofed_as_string(source->spoofed)));

	if(source->interface)
		setAttribute(cur, newAttribute("interface",
			source->interface));
	
	if(source->node)
		addElement(cur, build_node(source->node));
		
	if(source->user)
		addElement(cur, build_user(source->user));

	if(source->process)
		addElement(cur, build_process(source->process));

	if(source->service)
		addElement(cur, build_service(source->service));

	return cur;
}

xmlNodePtr
build_fileaccess(const IDMEFfileaccess *fileaccess) {
	xmlNodePtr cur = newFileAccess(NULL);
	int i;

	if(fileaccess->userid)
		addElement(cur, build_userid(fileaccess->userid));

	for(i = 0; i < fileaccess->npermissions; i++) {
		addElement(cur, newSimpleElement("permission",
		fileaccess->permissions[i]));
	}

	return cur;
}

xmlNodePtr
build_linkage(const IDMEFlinkage *linkage) {
	xmlNodePtr cur = newLinkage(NULL);

	/* category is required */
	setAttribute(cur, 
		     newAttribute("category",
				  linkage_category_as_string(linkage->category)));

	if(linkage->name)
		addElement(cur, newSimpleElement("name", linkage->name));

	if(linkage->path)
		addElement(cur, newSimpleElement("path", linkage->path));

	if(linkage->file)
		addElement(cur, build_file(linkage->file));

	return cur;
}

xmlNodePtr
build_inode(const IDMEFinode *inode) {
	xmlNodePtr cur = newInode(NULL);

	/*if(inode->change_time)
	 *	addElement(cur, newInodeChangeTime(&inode->change_time->tv));
	 */
	if(inode->change_time)
		addElement(cur, newSimpleElement("change-time", 
						 inode->change_time));

	if(inode->number) {
		char buf[BUFSIZ];
		memset(buf, '\0', sizeof(buf));
		sprintf(buf, "%d", *inode->number);
		addElement(cur, newSimpleElement("number", buf));
	}

	if(inode->major_device) {
		char buf[BUFSIZ];
		memset(buf, '\0', sizeof(buf));
		sprintf(buf, "%d", *inode->major_device);
		addElement(cur, newSimpleElement("major-device", buf));
	}

	if(inode->minor_device) {
		char buf[BUFSIZ];
		memset(buf, '\0', sizeof(buf));
		sprintf(buf, "%d", *inode->minor_device);
		addElement(cur, newSimpleElement("minor-device", buf));
	}

	if(inode->c_major_device) {
		char buf[BUFSIZ];
		memset(buf, '\0', sizeof(buf));
		sprintf(buf, "%d", *inode->c_major_device);
		addElement(cur, newSimpleElement("c-major-device", buf));
	}

	if(inode->c_minor_device) {
		char buf[BUFSIZ];
		memset(buf, '\0', sizeof(buf));
		sprintf(buf, "%d", *inode->c_minor_device);
		addElement(cur, newSimpleElement("c-minor-device", buf));
	}

	return cur;
}

xmlNodePtr
build_checksum(const IDMEFchecksum *checksum) {
	xmlNodePtr cur = newChecksum(NULL);

	/* algorithm is required */
	setAttribute(cur, newAttribute("algorithm",
		checksum_algorithm_as_string(checksum->algorithm)));

	if(checksum->value)
		setAttribute(cur, newAttribute("value", checksum->value));

	if(checksum->key)
		setAttribute(cur, newAttribute("key", checksum->value));

	return cur;
}

xmlNodePtr
build_file(const IDMEFfile *file) {
	xmlNodePtr cur = newFile(NULL);
	int i;

	if(file->ident)
		setAttribute(cur, newAttribute("ident", file->ident));

	/* category is required */
	setAttribute(cur, 
		     newAttribute("category",
				  file_category_as_string(file->category)));

	if(file->fstype)
		setAttribute(cur, newAttribute("fstype", file->fstype));

	if(file->name)
		addElement(cur, newSimpleElement("name", file->name));

	if(file->path)
		addElement(cur, newSimpleElement("path", file->path));

#if 0
	//if(file->create_time)
	//	addElement(cur, newFileCreateTime(&file->create_time->tv));

	//if(file->modify_time)
	//	addElement(cur, newFileModifyTime(&file->modify_time->tv));

	//if(file->access_time)
	//	addElement(cur, newFileAccessTime(&file->access_time->tv));
#endif
	if (file->create_time)
		addElement(cur, newSimpleElement("create-time", 
						 file->create_time));
	if (file->modify_time)
		addElement(cur, newSimpleElement("modify-time", 
						 file->modify_time));
	if (file->access_time)
		addElement(cur, newSimpleElement("access-time", 
						 file->access_time));

	if(file->data_size) {
		char buf[BUFSIZ];
		memset(buf, '\0', sizeof(buf));
		sprintf(buf, "%d", *file->data_size);
		addElement(cur, newSimpleElement("data-size", buf));
	}

	if(file->disk_size) {
		char buf[BUFSIZ];
		memset(buf, '\0', sizeof(buf));
		sprintf(buf, "%d", *file->disk_size);
		addElement(cur, newSimpleElement("disk-size", buf));
	}

	for(i = 0; i < file->nfileaccesses; i++) {
		addElement(cur, build_fileaccess(file->fileaccesses[i]));
	}

	for(i = 0; i < file->nlinkages; i++) {
		addElement(cur, build_linkage(file->linkages[i]));
	}

	for(i = 0; i < file->nchecksums; i++) {
		addElement(cur, build_checksum(file->checksums[i]));
	}

	return cur;
}

xmlNodePtr
build_filelist(const IDMEFfilelist *filelist) {
	xmlNodePtr cur = newFileList(NULL);
	int i;

	for(i = 0; i < filelist->nfiles; i++) {
		addElement(cur, build_file(filelist->files[i]));
	}

	return cur;
}

xmlNodePtr
build_target(const IDMEFtarget *target) {
	xmlNodePtr cur = newTarget(NULL);

	if(target->ident)
		setAttribute(cur, newAttribute("ident", target->ident));
	
	if(target->decoy != IDMEF_DECOY_UNKNOWN)
		setAttribute(cur, newAttribute("decoy",
		decoy_as_string(target->decoy)));

	if(target->interface)
		setAttribute(cur, newAttribute("interface",
			target->interface));
	
	if(target->node)
		addElement(cur, build_node(target->node));
		
	if(target->user)
		addElement(cur, build_user(target->user));

	if(target->process)
		addElement(cur, build_process(target->process));

	if(target->service)
		addElement(cur, build_service(target->service));

	if(target->filelist)
		addElement(cur, build_filelist(target->filelist));

	return cur;
}

xmlNodePtr
build_classification(const IDMEFclassification *classification) {
	int i;
	xmlNodePtr cur = newClassification(NULL);

	if(classification->ident)
		setAttribute(cur, newAttribute("ident",
					       classification->ident));

	if(classification->text)
		setAttribute(cur, newAttribute("text",
					       classification->text));

	for(i = 0; i < classification->nreferences; i++) {
		addElement(cur, 
			   build_reference(classification->references[i]));
	}
		
	return cur;
}

xmlNodePtr
build_reference(const IDMEFreference *reference) {
	xmlNodePtr cur = newReference(NULL);

	if(reference->origin != IDMEF_UNKNOWN_ORIGIN)
		setAttribute(cur, newAttribute("origin",
		reference_origin_as_string(reference->origin)));

	if(reference->meaning)
		setAttribute(cur, newAttribute("meaning", 
					       reference->meaning));

	if(reference->name)
		addElement(cur, newSimpleElement("name",
		reference->name));

	if(reference->url)
		addElement(cur, newSimpleElement("url",
		reference->url));
		
	return cur;

}

xmlNodePtr
build_analyzer(const IDMEFanalyzer *analyzer) {
	xmlNodePtr cur = newAnalyzer(NULL);

	if(analyzer->analyzerid)
		setAttribute(cur, newAttribute("analyzerid",
					       analyzer->analyzerid));

	if(analyzer->name)
		setAttribute(cur, newAttribute("name",
					       analyzer->name));

	if(analyzer->manufacturer)
		setAttribute(cur, newAttribute("manufacturer",
					       analyzer->manufacturer));

	if(analyzer->model)
		setAttribute(cur, newAttribute("model",
					       analyzer->model));

	if(analyzer->version)
		setAttribute(cur, newAttribute("version",
					       analyzer->version));

	if(analyzer->cls)
		setAttribute(cur, newAttribute("class",
					       analyzer->cls));

	if(analyzer->ostype)
		setAttribute(cur, newAttribute("ostype",
					       analyzer->ostype));

	if(analyzer->osversion)
		setAttribute(cur, newAttribute("osversion",
					       analyzer->osversion));

	if(analyzer->node)
		addElement(cur, build_node(analyzer->node));

	if(analyzer->process)
		addElement(cur, build_process(analyzer->process));

	if(analyzer->analyzer)
		addElement(cur, build_analyzer(analyzer->analyzer));

	return cur;
}

xmlNodePtr
build_impact(const IDMEFimpact *impact) {
	xmlNodePtr cur = 
		newImpact(newSimpleElement("value", impact->data), NULL);

	if(impact->severity != IDMEF_IMPACT_SEVERITY_UNKNOWN)
		setAttribute(cur, newAttribute("severity",
		impact_severity_as_string(impact->severity)));

	if(impact->completion != IDMEF_IMPACT_COMPLETION_UNKNOWN)
		setAttribute(cur, newAttribute("completion",
		impact_completion_as_string(impact->completion)));

	if(impact->type != IDMEF_IMPACT_TYPE_OTHER)
		setAttribute(cur, newAttribute("type",
		impact_type_as_string(impact->type)));

	return cur;
}

xmlNodePtr
build_action(const IDMEFaction *action) {
	xmlNodePtr cur = 
		newAction(newSimpleElement("value", action->data), NULL);

	if(action->category != IDMEF_ACTION_CATEGORY_OTHER)
		setAttribute(cur, newAttribute("category",
		action_category_as_string(action->category)));

	return cur;
}

xmlNodePtr
build_confidence(const IDMEFconfidence *confidence) {
	xmlNodePtr cur = 
		newConfidence(newSimpleElement("value", confidence->data), 
			      NULL);

	if(confidence->rating != IDMEF_CONFIDENCE_RATING_NUMERIC)
		setAttribute(cur, newAttribute("rating",
		confidence_rating_as_string(confidence->rating)));

	return cur;
}

xmlNodePtr
build_assessment(const IDMEFassessment *assessment) {
	xmlNodePtr cur = newAssessment(NULL);
	int i;

	if(assessment->impact)
		addElement(cur, build_impact(assessment->impact));

	for(i = 0; i < assessment->nactions; i++) {
		addElement(cur, build_action(assessment->actions[i]));
	}

	if(assessment->confidence)
		addElement(cur, build_confidence(assessment->confidence));	

	return cur;
}

xmlNodePtr
build_toolalert(const IDMEFtoolalert *toolalert) {
	xmlNodePtr cur = newToolAlert(NULL);
	int i = 0;

	if(toolalert->name)
		addElement(cur, newSimpleElement("name",
		toolalert->name));

	if(toolalert->command)
		addElement(cur, newSimpleElement("command",
		toolalert->command));

	for(i = 0; i < toolalert->nalertidents; i++) {
		xmlNodePtr child = 
			addElement(cur, newSimpleElement("alertident",
		toolalert->alertidents[i]->data));
		if(toolalert->alertidents[i]->analyzerid)
			setAttribute(child, newAttribute("analyzerid",
			toolalert->alertidents[i]->analyzerid));
	}

	return cur;
}

xmlNodePtr
build_overflowalert(const IDMEFoverflowalert *overflowalert) {
	xmlNodePtr cur = newOverflowAlert(NULL);

	if(overflowalert->program)
		addElement(cur, newSimpleElement("program",
		overflowalert->program));

	if(overflowalert->size) {
		char buf[BUFSIZ];
		memset(buf, '\0', sizeof(buf));
		sprintf(buf, "%d", *overflowalert->size);
		addElement(cur, newSimpleElement("size", buf));
	}

	if(overflowalert->buffer)
		addElement(cur, newSimpleElement("buffer",
		overflowalert->buffer));

	return cur;
}

xmlNodePtr
build_correlationalert(const IDMEFcorrelationalert *correlationalert) {
	xmlNodePtr cur = newCorrelationAlert(NULL);
	int i = 0;

	if(correlationalert->name)
		addElement(cur, newSimpleElement("name",
		correlationalert->name));

	for(i = 0; i < correlationalert->nalertidents; i++) {
		xmlNodePtr child = 
			addElement(cur, newSimpleElement("alertident",
		correlationalert->alertidents[i]->data));
		if(correlationalert->alertidents[i]->analyzerid)
			setAttribute(child, newAttribute("analyzerid",
			correlationalert->alertidents[i]->analyzerid));
	}

	return cur;
}

xmlNodePtr
build_additionaldata(const IDMEFadditionaldata *additionaldata) {
	xmlNodePtr cur = 0, value = 0;

	char *freedata = NULL;
	const char *data = NULL;
	xmlNodePtr xmldata = NULL;

	switch(additionaldata->type) {
	case IDMEF_BOOLEAN:
		data = boolean_as_string(additionaldata->data.data_boolean);
		break;
	case IDMEF_BYTE:
		/* avoid this type.  can't represent arbitrary
		 * byte values due to xml restriction on character references.
		 */
		data = additionaldata->data.data_byte;
		break;
	case IDMEF_CHARACTER:
		/* could confirm this is a single (UTF-8) char */
		data = additionaldata->data.data_character;
		break;
	case IDMEF_DATETIME:
		/* could confirm this meets format reqmts */
		data = additionaldata->data.data_datetime;
		break;
	case IDMEF_INTEGER:
		freedata = integer_as_string(additionaldata->data.data_integer);
		break;
	case IDMEF_NTPSTAMP:
		/* could confirm this meets format reqmts */
		data = additionaldata->data.data_ntpstamp;
		break;
	case IDMEF_PORTLIST:
		/* could confirm this meets format reqmts */
		data = additionaldata->data.data_portlist;
		break;
	case IDMEF_REAL:
		/* could confirm this meets format reqmts */
		data = additionaldata->data.data_real;
		break;
	case IDMEF_STRING:
		data = additionaldata->data.data_string;
		break;
	case IDMEF_XML:
		xmldata = additionaldata->data.data_xml;
		break;
	}

	if (data) {
		value = newSimpleElement("value", data);
	} else if (freedata) {
		value = newSimpleElement("value", freedata);
	} else if (xmldata) {
		value = xmlNewNode(NULL,"xml");
		if (value == NULL) {
			idmef_error("build_additionaldata(): xmlNewNode failed");
			goto fail;
		}
		addElement(value, xmlCopyNode(xmldata, 1));
	} else {
		idmef_error("build_additionaldata(): data was null");
		goto fail;
	}
	cur = newAdditionalData(value, NULL);

	if(additionaldata->type != IDMEF_STRING) 
		setAttribute(cur, newAttribute("type",
		       additionaldata_type_as_string(additionaldata->type)));

	if(additionaldata->meaning)
		setAttribute(cur, newAttribute("meaning",
		additionaldata->meaning));

 fail:
	if(freedata) {
		idmef_free(freedata);
	}
	return cur;
}

xmlNodePtr
build_alert(const IDMEFalert *alert) {
	xmlNodePtr cur = newAlert(NULL);
	int i = 0;

	if(alert->messageid)
		setAttribute(cur, newAttribute("messageid", alert->messageid));

	if(alert->analyzer) {
		addElement(cur, build_analyzer(alert->analyzer));
	}

	if(alert->createtime) {
		addElement(cur, build_time("CreateTime", alert->createtime));
	}

	if(alert->detecttime) {
		addElement(cur, build_time("DetectTime", alert->detecttime));
	}

	if(alert->analyzertime) {
		addElement(cur, build_time("AnalyzerTime",
					   alert->analyzertime));
	}

	for(i = 0; i < alert->nsources; i++) {
		addElement(cur, build_source(alert->sources[i]));
	}

	for(i = 0; i < alert->ntargets; i++) {
		addElement(cur, build_target(alert->targets[i]));
	}

	if(alert->classification)
		addElement(cur, build_classification(alert->classification));

	if(alert->assessment)
		addElement(cur, build_assessment(alert->assessment));

	if(alert->toolalert)
		addElement(cur,
			build_toolalert(alert->toolalert));

	if(alert->overflowalert)
		addElement(cur,
			build_overflowalert(alert->overflowalert));

	if(alert->correlationalert)
		addElement(cur,
			build_correlationalert(alert->correlationalert));

	for(i = 0; i < alert->nadditionaldatas; i++) {
		addElement(cur, build_additionaldata(
		alert->additionaldatas[i]));
	}

	return cur;
}

xmlNodePtr
build_heartbeat(const IDMEFheartbeat *heartbeat) {
	xmlNodePtr cur = newHeartbeat(NULL);
	int i = 0;

	if(heartbeat->messageid)
		setAttribute(cur, 
			     newAttribute("messageid", heartbeat->messageid));

	if(heartbeat->analyzer) {
		addElement(cur, build_analyzer(heartbeat->analyzer));
	}

	if(heartbeat->createtime) {
		addElement(cur, build_time("CreateTime", 
					   heartbeat->createtime));
	}

	if(heartbeat->analyzertime) {
		addElement(cur, build_time("AnalyzerTime", 
					   heartbeat->analyzertime));
	}

	for(i = 0; i < heartbeat->nadditionaldatas; i++) {
		addElement(cur, build_additionaldata(
		heartbeat->additionaldatas[i]));
	}

	return cur;
}

xmlNodePtr
build_idmef_message(const IDMEFmessage *message) {
	xmlNodePtr cur = newIDMEF_Message(NULL);
	int i;

	if(message->version)
		setAttribute(cur, newAttribute("version", message->version));

	for(i = 0; i < message->nalerts; i++) {
		addElement(cur, build_alert(message->alerts[i]));
	}

	for(i = 0; i < message->nheartbeats; i++) {
		addElement(cur, build_heartbeat(message->heartbeats[i]));
	}

	return cur;
}

/*
** Name: build_idmef_message_doc
**
** Purpose: To generate an XML representation of the IDMEF message
** represented by the C structure passed as it's argument.
** 
** Arguments: 
**     message - The C structure containing the IDMEF message infomation
**     include_doctype - flag indicating whether to include the DOCTYPE 
**         to make valid XML.  recommended value is 1 unless you are 
**         using XML AdditionalData items for which you don't yet have a DTD.
**     validate - flag indicating whether to validate the document against
**         the IDMEF DTD
**
** Returns: An xmlDocPtr containing the full XML document.
**          Caller is responsible for freeing it with xmlFreeDoc().
**
*/

xmlDocPtr
build_idmef_message_doc(const IDMEFmessage *message, 
			int include_doctype, int validate) {

	xmlDocPtr doc;
	xmlNodePtr root;

	root = build_idmef_message(message);
	doc = createDoc(XML_DEFAULT_VERSION, root, include_doctype);

	if (validate)
		validateDoc(NULL, doc);

	return doc;
}

/*
** Name: generate_idmef_message
**
** Purpose: To generate an XML representation of the IDMEF message
** represented by the C structure passed as it's argument.
** 
** Arguments: 
**     message - The C structure containing the IDMEF message infomation
**     length_out - optional pointer to store message length through
**     include_doctype - flag indicating whether to include the DOCTYPE 
**         to make valid XML.  recommended value is 1 unless you are 
**         using XML AdditionalData items for which you don't yet have a DTD.
**     validate - flag indicating whether to validate the document against
**         the IDMEF DTD
**
** Returns: A nul-terminated character array containing the XML message.
**          Caller is responsible for freeing it with xmlFree().
**
** Notes: The message length (excluding terminating nul) is stored in
**        *length_out if length_out is not NULL.
**
*/

xmlChar *
generate_idmef_message(const IDMEFmessage *message, int *length_out,
		       int include_doctype, int validate) {

	xmlDocPtr doc = 
		build_idmef_message_doc(message, include_doctype, validate);
	xmlChar *text = 0;
	int text_length = 0;

	xmlDocDumpMemory(doc, &text, &text_length);

	xmlFreeDoc(doc);

	if (length_out)
		*length_out = text_length;

	return text;
}

/* Make emacs handle 8-column indentation used in this file:
 * Local Variables:
 * c-basic-offset:8
 * indent-tabs-mode:t
 * tab-width:8
 * End: */
