/*
idmefxml_parse.c: libidmef parsing functions
Author: Adam Migus NAI Labs (amigus@nai.com)

Copyright (c) 2001 Networks Associates Technology, Inc.
All rights reserved

This library is released under the GNU GPL and BSD software licenses.
You may choose to use one or the other, BUT NOT BOTH.  The GNU GPL
license is located in the file named COPYING.  The BSD license is located
in the file named COPYING.BSD.  Please contact us if there are any
questions.

*/

/*
This code assumes that message elements are in order as dictated by the
specification put forth by the IETF IDWG in the standards document
draft-ietf-idwg-idmef-xml-12.txt.

$Id: idmefxml_parse.c,v 1.30 2005/01/21 03:54:35 dkindred Exp $
*/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include <stdio.h>
#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#endif
#ifdef HAVE_STRING_H
#include <string.h>
#endif
#ifdef HAVE_STRINGS_H
#include <strings.h>
#endif
#ifdef HAVE_NETDB_H
#include <netdb.h>
#endif
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#if TIME_WITH_SYS_TIME
# include <sys/time.h>
# include <time.h>
#else
# if HAVE_SYS_TIME_H
#  include <sys/time.h>
# else
#  include <time.h>
# endif
#endif
#include <math.h>
#include <ctype.h>

#include <libxml/xmlmemory.h>
#include <libxml/parser.h>

#include <libidmef/idmefxml_global.h>
#include <libidmef/idmefxml.h>
#include <libidmef/idmefxml_types.h>
#include <libidmef/idmefxml_parse.h>
#include <locale.h>

#ifdef IDMEF_DEBUG
#define DEBUG 1
#else
#define DEBUG 0
#endif /* IDMEF_DEBUG */

const char * get_attribute(const xmlNode * cur, const char *name);
char *       get_attribute_dup(const xmlNode * cur, const char *name);
const char * get_value(const xmlNode * cur);
char *       get_value_dup(const xmlNode * cur);
char **      get_values(const xmlNode * cur, const char *name, int *count);

static int *new_int(int value) {
	int *p = idmef_malloc(sizeof(*p));
	*p = value;
	return p;
}

/*
** Name: count_elements
**
** Purpose: Count the number of elements of a given name
**
** Arguments: The xmlNodePtr pointing to the elements you
** want to count.  The name of the element(s) you wish
** to count.
**
** Returns: The number of elements with the given name.
**
** Notes:
**
*/

int
count_elements(const xmlNode * cur, const char *name) {
	int n = 0;

	while(cur) {
		if(!strcasecmp(cur->name, name)) n++;
		cur = cur->next;
	}
	
	return n;
}

/*
** Name: get_attribute
**
** Purpose: Retrieves the named attribute from the attributes of
** the given xmlNodePtr.
**
** Arguments: The xmlNodePtr for which you want the attribute from.
** The string containing the name of the attribute you seek.
**
** Returns: A pointer to the string representing the attribute
** on success.  A null pointer on failure.
**
** Notes:
**
*/

const char *
get_attribute(const xmlNode * cur, const char *name) {
	xmlAttrPtr attr;

	attr = cur->properties;

	while(attr && xmlStrcmp(name, attr->name)) attr = attr->next;

	if(!(attr)) return 0;

	if(!(attr->children)) return 0;

	if(!(attr->children->content)) return 0;

	return attr->children->content;
}

/*
** Name: get_attribute_dup
**
** Purpose: Retrieves a newly-allocated copy of the named attribute
** from the attributes of the given xmlNodePtr.
**
** Arguments: The xmlNodePtr for which you want the attribute from.
** The string containing the name of the attribute you seek.
**
** Returns: A pointer to the string representing the attribute
** on success.  A null pointer on failure.  Caller is responsible
** for freeing.
**
** Notes:
**
*/

char *
get_attribute_dup(const xmlNode * cur, const char *name) {
	const char *s = get_attribute(cur, name);
	return s ? strdup(s) : NULL;
}

/*
** Name: get_value
**
** Purpose: Retrieves the value of the given xmlNodePtr.
**
** Arguments: The xmlNodePtr for which you want the value from.
**
** Returns: A pointer to the string representing the value
** on success.  A null pointer on failure.
**
** Notes:
**
*/

const char *
get_value(const xmlNode * cur) {
	if(!(cur)) return 0;

	if(!(cur->children)) return 0;

	if(!(cur->children->content)) return 0;

	return cur->children->content;
}

/*
** Name: get_value_dup
**
** Purpose: Retrieves a newly allocated copy of the content of the given
** xmlNodePtr.
**
** Arguments: The xmlNodePtr whose content you want.
**
** Returns: A pointer to the (newly allocated) string representing the value
** on success.  A null pointer on failure.  Caller is responsible for freeing.
**
** Notes:
**
*/

char *
get_value_dup(const xmlNode * cur) {
	const char *s = get_value(cur);
	return s ? strdup(s) : NULL;
}

/*
** Name: get_values
**
** Purpose: Retrieves the list of values of the given name starting
** at the xmlNodePtr given.
**
** Arguments: The xmlNodePtr pointing to the start of the xmlNodePtr's
** for which you want the values from.  The name of the values you
** want.  A pointer to the integer that will be set to the number
** of values returned.
**
** Returns: A pointer to an ALLOCATED array of string pointers, one
** for each value found on success.  A null pointer on failure.
**
** Notes:
**
** 1. It is the caller's responsibilty to free this allocated array and each
** of its elements.
**
*/

char **
get_values(const xmlNode * cur, const char *name, int *count) {
	char **values;
	int i = 0, n = 0;

	if(!(cur)) return 0;

	n = count_elements(cur, name);

	if(!n) return 0;

	values = (char **)idmef_malloc(n * sizeof(char *));
	memset(values, '\0', n * sizeof(char *));

	for(i = 0; i < n && cur; i++) {
		if(!strcasecmp(cur->name, name))
			values[i] = strdup(cur->children->content);
		cur = cur->next;
	}

	*count = n;

	return values;
}

/*
** The following section contains functions for translating between
** text and the inumerated types found in the header file.  I have
** written one comment block for all the functions.
*/

/*
** Name: Various
**
** Purpose: To convert between the enumerated types and their text
** equivalents.
**
** Arguments: Either a string for which the enumerated type is desired
** or an enumerated type for which the corresponding string is desired.
**
** Returns: Functions that take a string argument return the
** corresponding enumerated type or -1 on failure.  Functions that take
** an enumerated type return the corresponding string or null on failure.
**
** Notes:
**
*/

const char *
node_category_as_string(IDMEFnode_category category) {
	switch(category) {
	case IDMEF_NODE_CATEGORY_UNKNOWN:
		return "unknown";
	case IDMEF_ADS:
		return "ads";
	case IDMEF_AFS:
		return "afs";
	case IDMEF_CODA:
		return "coda";
	case IDMEF_DFS:
		return "dfs";
	case IDMEF_DNS:
		return "dns";
        case IDMEF_HOSTS:
		return "hosts";
	case IDMEF_KERBEROS:
		return "kerberos";
	case IDMEF_NDS:
		return "nds";
	case IDMEF_NIS:
		return "nis";
	case IDMEF_NISPLUS:
		return "nisplus";
	case IDMEF_NT:
		return "nt";
	case IDMEF_WFW:
		return "wfw";
	}

	return 0;
}

IDMEFnode_category
get_node_category(const char *p) {
	if(!p) {
		/* default if not provided */
		return IDMEF_NODE_CATEGORY_UNKNOWN;
	}

	if(!strcmp(p, "unknown")) {
		return IDMEF_NODE_CATEGORY_UNKNOWN;
	}
	else
	if(!strcmp(p, "ads")) {
		return IDMEF_ADS;
	}
	else
	if(!strcmp(p, "afs")) {
		return IDMEF_AFS;
	}
	else
	if(!strcmp(p, "coda")) {
		return IDMEF_CODA;
	}
	else
	if(!strcmp(p, "dfs")) {
		return IDMEF_DFS;
	}
	else
	if(!strcmp(p, "dns")) {
		return IDMEF_DNS;
	}
	else
	if(!strcmp(p, "hosts")) {
		return IDMEF_HOSTS;
	}
	else
	if(!strcmp(p, "kerberos")) {
		return IDMEF_KERBEROS;
	}
	else
	if(!strcmp(p, "nds")) {
		return IDMEF_NDS;
	}
	else
	if(!strcmp(p, "nis")) {
		return IDMEF_NIS;
	}
	else
	if(!strcmp(p, "nisplus")) {
		return IDMEF_NISPLUS;
	}
	else
	if(!strcmp(p, "nt")) {
		return IDMEF_NT;
	}
	else
	if(!strcmp(p, "wfw")) {
		return IDMEF_WFW;
	}

	/* could complain here about unrecognized node category */
	return IDMEF_NODE_CATEGORY_UNKNOWN;
}

const char *
address_category_as_string(IDMEFaddress_category category) {
	switch(category) {
	case IDMEF_ADDRESS_CATEGORY_UNKNOWN:
		return "unknown";
	case IDMEF_ATM:
		return "atm";
	case IDMEF_E_MAIL:
		return "e-mail";
	case IDMEF_LOTUS_NOTES:
		return "lotus-notes";
	case IDMEF_MAC:
		return "mac";
	case IDMEF_SNA:
		return "sna";
	case IDMEF_VM:
		return "vm";
	case IDMEF_IPV4_ADDR:
		return "ipv4-addr";
	case IDMEF_IPV4_ADDR_HEX:
		return "ipv4-addr-hex";
	case IDMEF_IPV4_NET:
		return "ipv4-net";
	case IDMEF_IPV4_NET_MASK:
		return "ipv4-net-mask";
	case IDMEF_IPV6_ADDR:
		return "ipv6-addr";
	case IDMEF_IPV6_ADDR_HEX:
		return "ipv6-addr-hex";
	case IDMEF_IPV6_NET:
		return "ipv6-net";
	case IDMEF_IPV6_NET_MASK:
		return "ipv6-net-mask";
	}

	return 0;
}

IDMEFaddress_category
get_address_category(const char *p) {
	if(!p) {
		/* default if value not provided */
		return IDMEF_ADDRESS_CATEGORY_UNKNOWN;
	}
	if(!strcmp(p, "unknown")) {
		return IDMEF_ADDRESS_CATEGORY_UNKNOWN;
	}
	else
	if(!strcmp(p, "atm")) {
		return IDMEF_ATM;
	}
	else
	if(!strcmp(p, "e-mail")) {
		return IDMEF_E_MAIL;
	}
	else
	if(!strcmp(p, "lotus-notes")) {
		return IDMEF_LOTUS_NOTES;
	}
	else
	if(!strcmp(p, "mac")) {
		return IDMEF_MAC;
	}
	else
	if(!strcmp(p, "sna")) {
		return IDMEF_SNA;
	}
	else
	if(!strcmp(p, "vm")) {
		return IDMEF_VM;
	}
	else
	if(!strcmp(p, "ipv4-addr")) {
		return IDMEF_IPV4_ADDR;
	}
	else
	if(!strcmp(p, "ipv4-addr-hex")) {
		return IDMEF_IPV4_ADDR_HEX;
	}
	else
	if(!strcmp(p, "ipv4-net")) {
		return IDMEF_IPV4_NET;
	}
	else
	if(!strcmp(p, "ipv4-net-mask")) {
		return IDMEF_IPV4_NET_MASK;
	}
	else
	if(!strcmp(p, "ipv6-addr")) {
		return IDMEF_IPV6_ADDR;
	}
	else
	if(!strcmp(p, "ipv6-addr-hex")) {
		return IDMEF_IPV6_ADDR_HEX;
	}
	else
	if(!strcmp(p, "ipv6-net")) {
		return IDMEF_IPV6_NET;
	}
	else
	if(!strcmp(p, "ipv6-net-mask")) {
		return IDMEF_IPV6_NET_MASK;
	}

	/* could complain here about unrecognized address category */
	return IDMEF_ADDRESS_CATEGORY_UNKNOWN;
}

IDMEFspoofed
get_spoofed(const char *p) {
	if(!p) {
		/* default if value not provided */
		return IDMEF_SPOOFED_UNKNOWN;
	}
	if(!strcmp(p, "yes")) {
		return IDMEF_SPOOFED_YES;
	}
	else
	if(!strcmp(p, "no")) {
		return IDMEF_SPOOFED_NO;
	}
	else
	if(!strcmp(p, "unknown")) {
		return IDMEF_SPOOFED_UNKNOWN;
	}
	/* could complain here about unrecognized "spoofed" value */
	return IDMEF_SPOOFED_UNKNOWN;
}

const char *
spoofed_as_string(IDMEFspoofed spoofed) {
	switch(spoofed) {
	case IDMEF_SPOOFED_YES:
		return "yes";
	case IDMEF_SPOOFED_NO:
		return "no";
	case IDMEF_SPOOFED_UNKNOWN:
		return "unknown";
	}

	return 0;
}

IDMEFdecoy
get_decoy(const char *p) {
	if(!p) {
		/* default if value not provided */
		return IDMEF_DECOY_UNKNOWN;
	}
	if(!strcmp(p, "yes")) {
		return IDMEF_DECOY_YES;
	}
	else
	if(!strcmp(p, "no")) {
		return IDMEF_DECOY_NO;
	}
	else
	if(!strcmp(p, "unknown")) {
		return IDMEF_DECOY_UNKNOWN;
	}
	/* could complain here about unrecognized "decoy" value */
	return IDMEF_DECOY_UNKNOWN;
}

const char *
decoy_as_string(IDMEFdecoy decoy) {
	switch(decoy) {
	case IDMEF_DECOY_YES:
		return "yes";
	case IDMEF_DECOY_NO:
		return "no";
	case IDMEF_DECOY_UNKNOWN:
		return "unknown";
	}

	return 0;
}

IDMEFuser_category
get_user_category(const char *p) {
	if(!p) {
		/* default if no value provided */
		return IDMEF_USER_CATEGORY_UNKNOWN;
	}
	if(!strcmp(p, "unknown")) {
		return IDMEF_USER_CATEGORY_UNKNOWN;
	}
	else
	if(!strcmp(p, "application")) {
		return IDMEF_APPLICATION;
	}
	else
	if(!strcmp(p, "os-device")) {
		return IDMEF_OS_DEVICE;
	}
	/* could complain here about unrecognized user category */
	return IDMEF_USER_CATEGORY_UNKNOWN;
}

const char *
user_category_as_string(IDMEFuser_category category) {
	switch(category) {
	case IDMEF_USER_CATEGORY_UNKNOWN:
		return "unknown";
	case IDMEF_APPLICATION:
		return "application";
	case IDMEF_OS_DEVICE:
		return "os-device";
	}

	return 0;
}

IDMEFUserId_type
get_userid_type(const char *p) {
	if(!p) {
		/* default if no value provided */
		return IDMEF_ORIGINAL_USER;
	}
	if(!strcmp(p, "current-user")) {
		return IDMEF_CURRENT_USER;
	}
	else
	if(!strcmp(p, "original-user")) {
		return IDMEF_ORIGINAL_USER;
	}
	else
	if(!strcmp(p, "target-user")) {
		return IDMEF_TARGET_USER;
	}
	else
	if(!strcmp(p, "user-privs")) {
		return IDMEF_USER_PRIVS;
	}
	else
	if(!strcmp(p, "current-group")) {
		return IDMEF_CURRENT_GROUP;
	}
	else
	if(!strcmp(p, "group-privs")) {
		return IDMEF_GROUP_PRIVS;
	}
	else
	if(!strcmp(p, "other-privs")) {
		return IDMEF_OTHER_PRIVS;
	}

	/* could complain here about unrecognized userid type */
	return IDMEF_ORIGINAL_USER;
}

const char *
userid_type_as_string(IDMEFUserId_type type) {
	switch(type) {
	case IDMEF_CURRENT_USER:
		return "current-user";
	case IDMEF_ORIGINAL_USER:
		return "original-user";
	case IDMEF_TARGET_USER:
		return "target-user";
	case IDMEF_USER_PRIVS:
		return "user-privs";
	case IDMEF_CURRENT_GROUP:
		return "current-group";
	case IDMEF_GROUP_PRIVS:
		return "group-privs";
	case IDMEF_OTHER_PRIVS:
		return "other-privs";
	}

	return 0;
}

IDMEForigin
get_reference_origin(const char *p) {
	if(!p) {
		/* default if no value provided (though this attr is req'd) */
		return IDMEF_UNKNOWN_ORIGIN;
	}
	if(!strcmp(p, "unknown")) {
		return IDMEF_UNKNOWN_ORIGIN;
	}
	else
	if(!strcmp(p, "vendor-specific")) {
		return IDMEF_VENDOR_SPECIFIC;
	}
	else
	if(!strcmp(p, "user-specific")) {
		return IDMEF_USER_SPECIFIC;
	}
	else
	if(!strcmp(p, "bugtraqid")) {
		return IDMEF_BUGTRAQID;
	}
	else
	if(!strcmp(p, "cve")) {
		return IDMEF_CVE;
	}
	else
	if(!strcmp(p, "osvdb")) {
		return IDMEF_OSVDB;
	}
	/* could complain here about unrecognized reference origin */
	return IDMEF_UNKNOWN_ORIGIN;
}

const char *reference_origin_as_string(IDMEForigin origin) {
	switch(origin) {
	case IDMEF_UNKNOWN_ORIGIN:
		return "unknown";
	case IDMEF_VENDOR_SPECIFIC:
		return "vendor-specific";
	case IDMEF_USER_SPECIFIC:
		return "user-specific";
	case IDMEF_BUGTRAQID:
		return "bugtraqid";
	case IDMEF_CVE:
		return "cve";
	case IDMEF_OSVDB:
		return "osvdb";
	}

	return 0;
}

IDMEFadditionaldata_type
get_additionaldata_type(const char *p) {
	if(!p) {
		/* default if no value provided (though this attr is req'd) */
		return IDMEF_STRING;
	}
	if(!strcmp(p, "boolean")) {
		return IDMEF_BOOLEAN;
	}
	else
	if(!strcmp(p, "byte")) {
		return IDMEF_BYTE;
	}
	else
	if(!strcmp(p, "character")) {
		return IDMEF_CHARACTER;
	}
	else
	if(!strcmp(p, "date-time")) {
		return IDMEF_DATETIME;
	}
	else
	if(!strcmp(p, "integer")) {
		return IDMEF_INTEGER;
	}
	else
	if(!strcmp(p, "ntpstamp")) {
		return IDMEF_NTPSTAMP;
	}
	else
	if(!strcmp(p, "portlist")) {
		return IDMEF_PORTLIST;
	}
	else
	if(!strcmp(p, "real")) {
		return IDMEF_REAL;
	}
	else
	if(!strcmp(p, "string")) {
		return IDMEF_STRING;
	}
	else
	if(!strcmp(p, "xml")) {
		return IDMEF_XML;
	}

	/* could complain here about unrecognized additionaldata type */
	return IDMEF_STRING;
}

const char *
additionaldata_type_as_string(IDMEFadditionaldata_type type) {
	switch(type) {
	case IDMEF_BOOLEAN:
		return "boolean";
	case IDMEF_BYTE:
		return "byte";
	case IDMEF_CHARACTER:
		return "character";
	case IDMEF_DATETIME:
		return "date-time";
	case IDMEF_INTEGER:
		return "integer";
	case IDMEF_NTPSTAMP:
		return "ntpstamp";
	case IDMEF_PORTLIST:
		return "portlist";
	case IDMEF_REAL:
		return "real";
	case IDMEF_STRING:
		return "string";
	case IDMEF_XML:
		return "xml";
	}

	return 0;
}

IDMEFimpact_severity
get_impact_severity(const char *p) {
	if (!p) {
		return IDMEF_IMPACT_SEVERITY_UNKNOWN;
	}

	if(!strcmp(p, "info")) {
		return IDMEF_IMPACT_SEVERITY_INFO;
	}
	else
	if(!strcmp(p, "low")) {
		return IDMEF_IMPACT_SEVERITY_LOW;
	}
	else
	if(!strcmp(p, "medium")) {
		return IDMEF_IMPACT_SEVERITY_MEDIUM;
	}
	else
	if(!strcmp(p, "high")) {
		return IDMEF_IMPACT_SEVERITY_HIGH;
	}

	/* could complain here about unrecognized severity */
	return IDMEF_IMPACT_SEVERITY_UNKNOWN;
}

const char *
impact_severity_as_string(IDMEFimpact_severity severity) {
	switch(severity) {
	case IDMEF_IMPACT_SEVERITY_INFO:
		return "info";
	case IDMEF_IMPACT_SEVERITY_LOW:
		return "low";
	case IDMEF_IMPACT_SEVERITY_MEDIUM:
		return "medium";
	case IDMEF_IMPACT_SEVERITY_HIGH:
		return "high";
	case IDMEF_IMPACT_SEVERITY_UNKNOWN:
		/* nonstandard -- don't use in messages */
		return 0;
	}

	return 0;
}

IDMEFimpact_completion
get_impact_completion(const char *p) {
	if (!p) {
		return IDMEF_IMPACT_COMPLETION_UNKNOWN;
	}
	if(!strcmp(p, "failed")) {
		return IDMEF_FAILED;
	}
	else
	if(!strcmp(p, "succeeded")) {
		return IDMEF_SUCCEEDED;
	}

	/* could complain here about unrecognized completion value */
	return IDMEF_IMPACT_COMPLETION_UNKNOWN;
}

const char *
impact_completion_as_string(IDMEFimpact_completion completion) {
	switch(completion) {
	case IDMEF_FAILED:
		return "failed";
	case IDMEF_SUCCEEDED:
		return "succeeded";
	case IDMEF_IMPACT_COMPLETION_UNKNOWN:
		/* nonstandard -- don't use in messages */
		return 0;
	}

	return 0;
}

IDMEFimpact_type
get_impact_type(const char *p) {
	if(!p) {
		/* default if no value provided */
		return IDMEF_IMPACT_TYPE_OTHER;
	}
	if(!strcmp(p, "admin")) {
		return IDMEF_ADMIN;
	}
	else
	if(!strcmp(p, "dos")) {
		return IDMEF_DOS;
	}
	else
	if(!strcmp(p, "file")) {
		return IDMEF_IMPACT_TYPE_FILE;
	}
	else
	if(!strcmp(p, "recon")) {
		return IDMEF_RECON;
	}
	else
	if(!strcmp(p, "user")) {
		return IDMEF_USER;
	}
	else
	if(!strcmp(p, "other")) {
		return IDMEF_IMPACT_TYPE_OTHER;
	}

	/* could complain about unrecognized impact type here */
	return IDMEF_IMPACT_TYPE_OTHER;
}

const char *
impact_type_as_string(IDMEFimpact_type type) {
	switch(type) {
	case IDMEF_ADMIN:
		return "admin";
	case IDMEF_DOS:
		return "dos";
	case IDMEF_IMPACT_TYPE_FILE:
		return "file";
	case IDMEF_RECON:
		return "recon";
	case IDMEF_USER:
		return "user";
	case IDMEF_IMPACT_TYPE_OTHER:
		return "other";
	}

	return 0;
}

IDMEFaction_category
get_action_category(const char *p) {
	if(!p) {
		/* default if no value provided */
		return IDMEF_ACTION_CATEGORY_OTHER;
	}
	if(!strcmp(p, "other")) {
		return IDMEF_ACTION_CATEGORY_OTHER;
	}
	else
	if(!strcmp(p, "block-installed")) {
		return IDMEF_BLOCK_INSTALLED;
	}
	else
	if(!strcmp(p, "notification-sent")) {
		return IDMEF_NOTIFICATION_SENT;
	}
	else
	if(!strcmp(p, "taken-offline")) {
		return IDMEF_TAKEN_OFFLINE;
	}
	/* could complain here about unrecognized action category */
	return IDMEF_ACTION_CATEGORY_OTHER;
}

const char *
action_category_as_string(IDMEFaction_category category) {
	switch(category) {
	case IDMEF_ACTION_CATEGORY_OTHER:
		return "other";
	case IDMEF_BLOCK_INSTALLED:
		return "block-installed";
	case IDMEF_NOTIFICATION_SENT:
		return "notification-sent";
	case IDMEF_TAKEN_OFFLINE:
		return "taken-offline";
	}

	return 0;
}

IDMEFconfidence_rating
get_confidence_rating(const char *p) {
	if(!p) {
		/* default if no value provided */
		return IDMEF_CONFIDENCE_RATING_NUMERIC;
	}
	if(!strcmp(p, "low")) {
		return IDMEF_CONFIDENCE_RATING_LOW;
	}
	else
	if(!strcmp(p, "medium")) {
		return IDMEF_CONFIDENCE_RATING_MEDIUM;
	}
	else
	if(!strcmp(p, "high")) {
		return IDMEF_CONFIDENCE_RATING_HIGH;
	}
	else
	if(!strcmp(p, "numeric")) {
		return IDMEF_CONFIDENCE_RATING_NUMERIC;
	}

	/* could complain here about unrecognized action category */
	return IDMEF_CONFIDENCE_RATING_NUMERIC;
}

const char *
confidence_rating_as_string(IDMEFconfidence_rating rating) {
	switch(rating) {
	case IDMEF_CONFIDENCE_RATING_NUMERIC:
		return "numeric";
	case IDMEF_CONFIDENCE_RATING_LOW:
		return "low";
	case IDMEF_CONFIDENCE_RATING_MEDIUM:
		return "medium";
	case IDMEF_CONFIDENCE_RATING_HIGH:
		return "high";
	}

	return 0;
}

IDMEFfile_category
get_file_category(const char *p) {
	if(!p) {
		/* could complain here -- this attr is required */
		return -1;
	}
	if(!strcmp(p, "current")) {
		return IDMEF_CURRENT;
	}
	else
	if(!strcmp(p, "original")) {
		return IDMEF_ORIGINAL;
	}
	/* could complain here about unrecognized file category */
	return -1;
}

const char *
file_category_as_string(IDMEFfile_category category) {
	switch(category) {
	case IDMEF_CURRENT:
		return "current";
	case IDMEF_ORIGINAL:
		return "original";
	}

	return 0;
}

IDMEFlinkage_category
get_linkage_category(const char *p) {
	if(!p) {
		/* could complain here -- this attr is required */
		return -1;
	}
	if(!strcmp(p, "hard-link")) {
		return IDMEF_HARD_LINK;
	}
	else
	if(!strcmp(p, "mount-point")) {
		return IDMEF_MOUNT_POINT;
	}
	else
	if(!strcmp(p, "reparse-point")) {
		return IDMEF_REPARSE_POINT;
	}
	else
	if(!strcmp(p, "shortcut")) {
		return IDMEF_SHORTCUT;
	}
	else
	if(!strcmp(p, "stream")) {
		return IDMEF_STREAM;
	}
	else
	if(!strcmp(p, "symbolic-link")) {
		return IDMEF_SYMBOLIC_LINK;
	}
	/* could complain here about unrecognized linkage category  */
	return -1;
}

const char *
linkage_category_as_string(IDMEFlinkage_category category) {
	switch(category) {
	case IDMEF_HARD_LINK:
		return "hard-link";
	case IDMEF_MOUNT_POINT:
		return "mount-point";
	case IDMEF_REPARSE_POINT:
		return "reparse-point";
	case IDMEF_SHORTCUT:
		return "shortcut";
	case IDMEF_STREAM:
		return "stream";
	case IDMEF_SYMBOLIC_LINK:
		return "symbolic-link";
	}

	return 0;
}

IDMEFchecksum_algorithm
get_checksum_algorithm(const char *p) {
	if(!p) {
		/* could complain here -- this attr is required */
		return -1;
	}
	if(!strcmp(p, "MD4")) {
		return IDMEF_MD4;
	}
	else
	if(!strcmp(p, "MD5")) {
		return IDMEF_MD5;
	}
	else
	if(!strcmp(p, "SHA1")) {
		return IDMEF_SHA1;
	}
	else
	if(!strcmp(p, "SHA2-256")) {
		return IDMEF_SHA2_256;
	}
	else
	if(!strcmp(p, "SHA2-384")) {
		return IDMEF_SHA2_384;
	}
	else
	if(!strcmp(p, "SHA2-512")) {
		return IDMEF_SHA2_512;
	}
	else
	if(!strcmp(p, "CRC-32")) {
		return IDMEF_CRC_32;
	}
	else
	if(!strcmp(p, "Haval")) {
		return IDMEF_HAVAL;
	}
	else
	if(!strcmp(p, "Tiger")) {
		return IDMEF_TIGER;
	}
	else
	if(!strcmp(p, "Gost")) {
		return IDMEF_GOST;
	}
	/* could complain here about unrecognized checksum algorithm  */
	return -1;
}

const char *
checksum_algorithm_as_string(IDMEFchecksum_algorithm algorithm) {
	switch(algorithm) {
	case IDMEF_MD4:
		return "MD4";
	case IDMEF_MD5:
		return "MD5";
	case IDMEF_SHA1:
		return "SHA1";
	case IDMEF_SHA2_256:
		return "SHA2-256";
	case IDMEF_SHA2_384:
		return "SHA2-384";
	case IDMEF_SHA2_512:
		return "SHA2-512";
	case IDMEF_CRC_32:
		return "CRC-32";
	case IDMEF_HAVAL:
		return "Haval";
	case IDMEF_TIGER:
		return "Tiger";
	case IDMEF_GOST:
		return "Gost";
	}

	return 0;
}

int
get_boolean(const char *p) {
	if(!p) {
		/* could complain here */
		return 0;
	}
	if(!strcmp(p, "true")) {
		return 1;
	}
	else
	if(!strcmp(p, "false")) {
		return 0;
	}
	/* could complain here about unrecognized boolean value */
	return 0;
}

const char *
boolean_as_string(int boolean_value) {
	return boolean_value ? "true" : "false";
}

long
get_integer(const char *p) {
	char *endptr = 0;
	long int_value;
	if(!p) {
		/* could complain here */
		return 0;
	}
	int_value = strtol(p, &endptr, 0);
	if (endptr && *endptr == '\0') {
		return int_value;
	} else {
		idmef_error("get_integer(): invalid integer value \"%s\"",
			    p);
		return 0;
	}
}

/* caller must free returned value! */
char *
integer_as_string(long integer_value) {
	int maxlen = 16;
	char *buf = idmef_malloc(maxlen);
	if (buf) {
		snprintf(buf, maxlen, "%ld", integer_value);
	}
	return buf;
}

double 
get_real(const char *p) {
	double nan_value;

#ifdef NAN
	nan_value = NAN;
#else
	nan_value = 0.0/0.0;
#endif

	if(!p) {
		/* could complain here */
		return nan_value;
	}
	/* IDMEF requires that we support both . and , as decimal point */
	{
		char decimal_point = '.';
		char *dp;

		struct lconv *loc = localeconv();
		if (loc && loc->decimal_point)
			decimal_point = *loc->decimal_point;

		if ((dp = strchr(p, '.')) != NULL) {
			*dp = decimal_point;
		}
		if ((dp = strchr(p, ',')) != NULL) {
			*dp = decimal_point;
		}
	}

	{
		char *endptr = 0;
		double real_value = strtod(p, &endptr);
		if (endptr && *endptr == '\0') {
			return real_value;
		} else {
			idmef_error("get_real(): invalid real value \"%s\"",
				    p);
			return nan_value;
		}
	}
}

/* caller must free returned value! */
char *
real_as_string(double real_value, int precision) {
	int maxlen = 16;
	char *buf;

	if (isnan(real_value)) {
		idmef_error( "real_as_string(): invalid value (NaN)");
		return 0;
	} else if (isinf(real_value)) {
		idmef_error( "real_as_string(): invalid value (infinite)");
		return 0;
	}

	buf = idmef_malloc(maxlen);
	if (buf) {
		snprintf(buf, maxlen, "%.*g", precision, real_value);
	}
	return buf;
}

/*
** The following functions initialize IDMEF message structures.
** It would be nice if all the init_* just looked like memset(p, 0, sizeof(*p))
** but the standard (as of draft11) mandates some nonzero default enum values.
*/

/*
** Name: init_XYZ where XYZ is an element type defined in the
** IDMEF message exchange format specification.  Types are in
** lowercase in all cases.
**
** Purpose: The init_XYZ initializes the C structure for XYZ with
** default values.
**
** Arguments: pointer to the XYZ structure to be initialized. 
**
** Returns: void
*/

void
init_userid(IDMEFuserid *p) {
	memset(p, '\0', sizeof(*p));
	p->type = IDMEF_ORIGINAL_USER;
}

void
init_user(IDMEFuser *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_time(IDMEFtime *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_address(IDMEFaddress *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_process(IDMEFprocess *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_additionaldata(IDMEFadditionaldata *p) {
	memset(p, '\0', sizeof(*p));
	p->type = IDMEF_STRING;
}

void
init_classification(IDMEFclassification *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_reference(IDMEFreference *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_impact(IDMEFimpact *p) {
	memset(p, '\0', sizeof(*p));
	p->severity = IDMEF_IMPACT_SEVERITY_UNKNOWN;
	p->completion = IDMEF_IMPACT_COMPLETION_UNKNOWN;
	p->type = IDMEF_IMPACT_TYPE_OTHER;
}

void
init_action(IDMEFaction *p) {
	memset(p, '\0', sizeof(*p));
	p->category = IDMEF_ACTION_CATEGORY_OTHER;
}

void
init_confidence(IDMEFconfidence *p) {
	memset(p, '\0', sizeof(*p));
	p->rating = IDMEF_CONFIDENCE_RATING_NUMERIC;
}

void
init_assessment(IDMEFassessment *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_node(IDMEFnode *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_webservice(IDMEFwebservice *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_snmpservice(IDMEFSNMPservice *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_service(IDMEFservice *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_linkage(IDMEFlinkage *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_inode(IDMEFinode *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_checksum(IDMEFchecksum *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_fileaccess(IDMEFfileaccess *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_file(IDMEFfile *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_filelist(IDMEFfilelist *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_target(IDMEFtarget *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_source(IDMEFsource *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_analyzer(IDMEFanalyzer *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_alertident(IDMEFalertident *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_overflowalert(IDMEFoverflowalert *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_toolalert(IDMEFtoolalert *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_correlationalert(IDMEFcorrelationalert *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_heartbeat(IDMEFheartbeat *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_alert(IDMEFalert *p) {
	memset(p, '\0', sizeof(*p));
}

void
init_message(IDMEFmessage *p)
{
	memset(p, '\0', sizeof(*p));
}

/*
** The following functions allocate (and initialize) IDMEF message structures.
** They abort() on malloc failures so we get a useful core dump.
*/

/*
** Name: new_XYZ where XYZ is an element type defined in the
** IDMEF message exchange format specification.  Types are in
** lowercase in all cases.
**
** Purpose: The new_XYZ function allocates the C structure for
** XYZ and initializes it (using init_XYZ()) with default values.
**
** Arguments: none
**
** Returns: A pointer to the newly allocated structure, which the
** caller is responsible for freeing with free_XYZ().
*/

IDMEFuserid * 
new_userid() {
	IDMEFuserid *p = idmef_malloc(sizeof(*p));
	init_userid(p);
	return p;
}

IDMEFuser * 
new_user() {
	IDMEFuser *p = idmef_malloc(sizeof(*p));
	init_user(p);
	return p;
}

IDMEFtime * 
new_time() {
	IDMEFtime *p = idmef_malloc(sizeof(*p));
	init_time(p);
	return p;
}

IDMEFaddress * 
new_address() {
	IDMEFaddress *p = idmef_malloc(sizeof(*p));
	init_address(p);
	return p;
}

IDMEFprocess * 
new_process() {
	IDMEFprocess *p = idmef_malloc(sizeof(*p));
	init_process(p);
	return p;
}

IDMEFadditionaldata * 
new_additionaldata() {
	IDMEFadditionaldata *p = idmef_malloc(sizeof(*p));
	init_additionaldata(p);
	return p;
}

IDMEFclassification * 
new_classification() {
	IDMEFclassification *p = idmef_malloc(sizeof(*p));
	init_classification(p);
	return p;
}

IDMEFreference * 
new_reference() {
	IDMEFreference *p = idmef_malloc(sizeof(*p));
	init_reference(p);
	return p;
}

IDMEFimpact * 
new_impact() {
	IDMEFimpact *p = idmef_malloc(sizeof(*p));
	init_impact(p);
	return p;
}

IDMEFaction * 
new_action() {
	IDMEFaction *p = idmef_malloc(sizeof(*p));
	init_action(p);
	return p;
}

IDMEFconfidence * 
new_confidence() {
	IDMEFconfidence *p = idmef_malloc(sizeof(*p));
	init_confidence(p);
	return p;
}

IDMEFassessment * 
new_assessment() {
	IDMEFassessment *p = idmef_malloc(sizeof(*p));
	init_assessment(p);
	return p;
}

IDMEFnode * 
new_node() {
	IDMEFnode *p = idmef_malloc(sizeof(*p));
	init_node(p);
	return p;
}

IDMEFwebservice * 
new_webservice() {
	IDMEFwebservice *p = idmef_malloc(sizeof(*p));
	init_webservice(p);
	return p;
}

IDMEFSNMPservice * 
new_snmpservice() {
	IDMEFSNMPservice *p = idmef_malloc(sizeof(*p));
	init_snmpservice(p);
	return p;
}

IDMEFservice * 
new_service() {
	IDMEFservice *p = idmef_malloc(sizeof(*p));
	init_service(p);
	return p;
}

IDMEFlinkage * 
new_linkage() {
	IDMEFlinkage *p = idmef_malloc(sizeof(*p));
	init_linkage(p);
	return p;
}

IDMEFinode * 
new_inode() {
	IDMEFinode *p = idmef_malloc(sizeof(*p));
	init_inode(p);
	return p;
}

IDMEFchecksum * 
new_checksum() {
	IDMEFchecksum *p = idmef_malloc(sizeof(*p));
	init_checksum(p);
	return p;
}

IDMEFfileaccess * 
new_fileaccess() {
	IDMEFfileaccess *p = idmef_malloc(sizeof(*p));
	init_fileaccess(p);
	return p;
}

IDMEFfile * 
new_file() {
	IDMEFfile *p = idmef_malloc(sizeof(*p));
	init_file(p);
	return p;
}

IDMEFfilelist * 
new_filelist() {
	IDMEFfilelist *p = idmef_malloc(sizeof(*p));
	init_filelist(p);
	return p;
}

IDMEFtarget * 
new_target() {
	IDMEFtarget *p = idmef_malloc(sizeof(*p));
	init_target(p);
	return p;
}

IDMEFsource * 
new_source() {
	IDMEFsource *p = idmef_malloc(sizeof(*p));
	init_source(p);
	return p;
}

IDMEFanalyzer * 
new_analyzer() {
	IDMEFanalyzer *p = idmef_malloc(sizeof(*p));
	init_analyzer(p);
	return p;
}

IDMEFalertident * 
new_alertident() {
	IDMEFalertident *p = idmef_malloc(sizeof(*p));
	init_alertident(p);
	return p;
}

IDMEFoverflowalert * 
new_overflowalert() {
	IDMEFoverflowalert *p = idmef_malloc(sizeof(*p));
	init_overflowalert(p);
	return p;
}

IDMEFtoolalert * 
new_toolalert() {
	IDMEFtoolalert *p = idmef_malloc(sizeof(*p));
	init_toolalert(p);
	return p;
}

IDMEFcorrelationalert * 
new_correlationalert() {
	IDMEFcorrelationalert *p = idmef_malloc(sizeof(*p));
	init_correlationalert(p);
	return p;
}

IDMEFheartbeat * 
new_heartbeat() {
	IDMEFheartbeat *p = idmef_malloc(sizeof(*p));
	init_heartbeat(p);
	return p;
}

IDMEFalert * 
new_alert() {
	IDMEFalert *p = idmef_malloc(sizeof(*p));
	init_alert(p);
	return p;
}

IDMEFmessage * 
new_message() {
	IDMEFmessage *p = idmef_malloc(sizeof(*p));
	init_message(p);
	return p;
}

/*
** Functions for handling the pointer lists in IDMEFmessage and friends
*/

/* grow or shrink list to specified capacity */
static void
resize_list(void **list, size_t *capacity, size_t elem_size, 
	    size_t new_capacity) {

	*list = idmef_realloc(*list, new_capacity * elem_size);

	if (new_capacity > *capacity) {
		memset(*list + *capacity * elem_size, '\0',
		       (new_capacity - *capacity) * elem_size);
	}
	*capacity = new_capacity;
}

static void
add_elem(void **list, size_t *len, size_t *capacity, size_t elem_size, 
	 void *elem) {

	if (*capacity < 1)
		resize_list(list, capacity, sizeof(*list), *capacity + 1);
	if (*capacity < *len + 1)
		resize_list(list, capacity, sizeof(*list), *capacity * 2);
	memcpy(*list + *len * elem_size, elem, elem_size);
	(*len)++;
}

void
add_user_userid(IDMEFuser *user, IDMEFuserid *userid) {
	add_elem((void **)&user->userids, &user->nuserids, 
		 &user->userids_capacity,
		 sizeof(user->userids[0]),
		 &userid);
}

void
add_webservice_arg(IDMEFwebservice *webservice, char *arg) {
	add_elem((void**)&webservice->arg, &webservice->narg, 
		 &webservice->arg_capacity,
		 sizeof(webservice->arg[0]),
		 &arg);
}

void
add_process_arg(IDMEFprocess *process, char *arg) {
	add_elem((void**)&process->arg, &process->narg, 
		 &process->arg_capacity,
		 sizeof(process->arg[0]),
		 &arg);
}

void
add_process_env(IDMEFprocess *process, char *env) {
	add_elem((void**)&process->env, &process->nenv, 
		 &process->env_capacity,
		 sizeof(process->env[0]),
		 &env);
}

void
add_classification_reference(IDMEFclassification *c, IDMEFreference *r) {
	add_elem((void**)&c->references, &c->nreferences,
		 &c->references_capacity,
		 sizeof(c->references[0]),
		 &r);
}

void
add_node_address(IDMEFnode *node, IDMEFaddress *address) {
	add_elem((void**)&node->addresses, &node->naddresses, 
		 &node->addresses_capacity,
		 sizeof(node->addresses[0]),
		 &address);
}

void
add_fileaccess_permission(IDMEFfileaccess *fileaccess, char *permission) {
	add_elem((void**)&fileaccess->permissions, &fileaccess->npermissions, 
		 &fileaccess->permissions_capacity,
		 sizeof(fileaccess->permissions[0]),
		 &permission);
}

void
add_file_fileaccess(IDMEFfile *file, IDMEFfileaccess *fileaccess) {
	add_elem((void**)&file->fileaccesses, &file->nfileaccesses, 
		 &file->fileaccesses_capacity,
		 sizeof(file->fileaccesses[0]),
		 &fileaccess);
}

void
add_file_linkage(IDMEFfile *file, IDMEFlinkage *linkage) {
	add_elem((void**)&file->linkages, &file->nlinkages, 
		 &file->linkages_capacity,
		 sizeof(file->linkages[0]),
		 &linkage);
}

void
add_file_checksum(IDMEFfile *file, IDMEFchecksum *checksum) {
	add_elem((void**)&file->checksums, &file->nchecksums, 
		 &file->checksums_capacity,
		 sizeof(file->checksums[0]),
		 &checksum);
}

void
add_filelist_file(IDMEFfilelist *filelist, IDMEFfile *file) {
	add_elem((void**)&filelist->files, &filelist->nfiles, 
		 &filelist->files_capacity,
		 sizeof(filelist->files[0]),
		 &file);
}

void
add_assessment_action(IDMEFassessment *assessment, IDMEFaction *action) {
	add_elem((void**)&assessment->actions, &assessment->nactions, 
		 &assessment->actions_capacity,
		 sizeof(assessment->actions[0]),
		 &action);
}

void
add_toolalert_alertident(IDMEFtoolalert *ta, IDMEFalertident *alertident) {
	add_elem((void**)&ta->alertidents, &ta->nalertidents, 
		 &ta->alertidents_capacity,
		 sizeof(ta->alertidents[0]),
		 &alertident);
}

void
add_correlationalert_alertident(IDMEFcorrelationalert *ca, IDMEFalertident *alertident) {
	add_elem((void**)&ca->alertidents, &ca->nalertidents, 
		 &ca->alertidents_capacity,
		 sizeof(ca->alertidents[0]),
		 &alertident);
}

void
add_alert_source(IDMEFalert *alert, IDMEFsource *source) {
	add_elem((void**)&alert->sources, &alert->nsources, 
		 &alert->sources_capacity,
		 sizeof(alert->sources[0]),
		 &source);
}

void
add_alert_target(IDMEFalert *alert, IDMEFtarget *target) {
	add_elem((void**)&alert->targets, &alert->ntargets, 
		 &alert->targets_capacity,
		 sizeof(alert->targets[0]),
		 &target);
}

void
add_alert_additionaldata(IDMEFalert *alert, IDMEFadditionaldata *d) {
	add_elem((void**)&alert->additionaldatas, &alert->nadditionaldatas, 
		 &alert->additionaldatas_capacity,
		 sizeof(alert->additionaldatas[0]),
		 &d);
}

void
add_heartbeat_additionaldata(IDMEFheartbeat *hb, IDMEFadditionaldata *d) {
	add_elem((void**)&hb->additionaldatas, &hb->nadditionaldatas, 
		 &hb->additionaldatas_capacity,
		 sizeof(hb->additionaldatas[0]),
		 &d);
}

void
add_message_alert(IDMEFmessage *message, IDMEFalert *alert) {
	add_elem((void**)&message->alerts, &message->nalerts, 
		 &message->alerts_capacity,
		 sizeof(message->alerts[0]),
		 &alert);
}

void
add_message_heartbeat(IDMEFmessage *message, IDMEFheartbeat *heartbeat) {
	add_elem((void**)&message->heartbeats, &message->nheartbeats, 
		 &message->heartbeats_capacity,
		 sizeof(message->heartbeats[0]),
		 &heartbeat);
}



/*
** The next section contains the parsing routines.  All of these
** functions take an xmlNodePtr pointing to the element it is
** to parse and a pointer to the C structure representing that
** element type.
** These parsing routines can be used by themselves by the user
** if need be but for normal operation the user need only call
** the get_idmef_message() or get_idmef_message_from_file()
** functions below which internally call each parsing routine
** upon encountering an element of that type in the message.
** I include one comment block for all the functions
*/

/*
** Name: parse_XYZ where XYZ is an element type defined in the
** IDMEF message exchange format specification.  Types are in
** lowercase in all cases.
**
** Purpose: The parse_XYZ function parses the element XYZ and
** populates it's corresponding C structure as defined in the
** header file.
**
** Arguments: In all cases the first argument is an xmlNodePtr
** that is assumed to contain the element XYZ.  The second
** argument is always the corresponding C structure for the
** element type XYZ.
**
** Returns: All functions return 1 on success, 0 on failure.
**
** Notes:
**
** 1. Functions that encounter ** arrays in the C structures
** they populate will ALLOCATE space as nessesary.  The user
** is responsible for freeing space allocated by these
** functions when done.  For convenience there is a series
** of free_XYZ() functions which will free all occurrences of
** such arrays that appear in the associated type.
**
** 2. The functions are somewhat recursive in nature.  While
** none of them are truly recursive (no function ever calls
** itself) one of the parsing functions will call another
** when a child node of that type is found.  It will pass a
** pointer to the C structure for that corresponding element
** type.  Obviously a function will only call another function
** of a type that appears as a child of the calling function
** type.
**
** 3. All functions expect the child elements to be present
** when they are required to be there by the specification!
**
** 4. All functions expect that child elements to be in the
** order that is dictated by the specification.
**
** 5. Attempting to parse messages that fail to comply with
** notes 3 and 4 will result in undefined behavior!
*/

int
parse_userid(const xmlNode * cur, IDMEFuserid *userid) {
	const char *p = 0;

	userid->ident = get_attribute_dup(cur, "ident");

	userid->type = get_userid_type(get_attribute(cur, "type"));

	cur = cur->children;
	if(!cur) return 1;

	if(!strcasecmp(cur->name, "name")) {
		userid->name = get_value_dup(cur);
		cur = cur->next;
		if(!cur) return 1;
	}

	if(!strcasecmp(cur->name, "number")) {
		p = get_value(cur);
		if(p) userid->number = new_int(atoi(p));
		cur = cur->next;
	}

	return 1;
}

int
parse_user(const xmlNode * cur, IDMEFuser *user) {
	int i, n = 0;
	
	user->ident = get_attribute_dup(cur, "ident");
	
	user->category = get_user_category(get_attribute(cur, "category"));

	cur = cur->children;
	if(!cur) return 0;          /* missing required "UserId" element */

	n = count_elements(cur, "UserId");

	if(n) {
		resize_list((void**)&user->userids, 
			    &user->userids_capacity,
			    sizeof(user->userids[0]), 
			    n);
		user->nuserids = n;

		for(i = 0; i < n && cur; i++) {
			if(DEBUG) idmef_debug("(parse_user) next element is %s -- calling parse_userid()",cur->name);
			user->userids[i] = new_userid();
			if(!parse_userid(cur, user->userids[i])) {
				idmef_error( "error parsing userid");
				return 0;
			}
			cur = cur->next;
		}
	}
	else return 0;              /* missing required "UserId" element */

	return 1;
}

int
parse_time(const xmlNode * cur, IDMEFtime *time) {
	char *start = 0, *end = 0;
	double d = 0.0;
	

	time->ntpstamp = get_attribute_dup(cur, "ntpstamp");

	if(!time->ntpstamp) return 0; /* missing required "ntpstamp" attr */

	time->string = get_value_dup(cur);

	start = time->ntpstamp;

	time->tv.tv_sec = strtoul(start, &end, 16) - 2208988800UL;

	start = ++end;

	d = ((double)strtoul(start, 0, 16) * 1000000.0) / 4294967296.0;

	time->tv.tv_usec = d;

	if((d - (double)time->tv.tv_usec) > 0.5) time->tv.tv_usec++;

	return 1;
}

int
parse_address(const xmlNode * cur, IDMEFaddress *address) {
	const char *p = 0;

	address->ident = get_attribute_dup(cur, "ident");

	address->vlan_name = get_attribute_dup(cur, "vlan-name");

	p = get_attribute(cur, "vlan-num");

	if(p) address->vlan_num = new_int(atoi(p));

	address->category = 
		get_address_category(get_attribute(cur, "category"));

	cur = cur->children;
	if(!cur) return 0;          /* missing required "address" element */

	if(strcasecmp(cur->name, "address")) 
		return 0; /* "address" element must be first */


	address->address = get_value_dup(cur);

	cur = cur->next;
	if(!cur) return 1;

	if(strcasecmp(cur->name, "netmask")) 
		return 0;               /* only netmask may follow address */

	address->netmask = get_value_dup(cur);

	return 1;
}

int
parse_process(const xmlNode * cur, IDMEFprocess *process) {
	const char *p = 0;
	int i = 0;

	process->ident = get_attribute_dup(cur, "ident");

	cur = cur->children;
	if(!cur) return 0;          /* missing required "name" element */

	if(strcasecmp(cur->name, "name")) return 0; /* "name" element must be first */

	process->name = get_value_dup(cur);
	cur = cur->next;
	if(!cur) return 1;

	if(!strcasecmp(cur->name, "pid")) {
		p = get_value(cur);
		if(p) process->pid = new_int(atoi(p));
		cur = cur->next;
		if(!cur) return 1;
	}

	if(!strcasecmp(cur->name, "path")) {
		process->path = get_value_dup(cur);
		cur = cur->next;
		if(!cur) return 1;
	}

	process->arg = get_values(cur, "arg", &process->narg);

	for(i = 0; i < process->narg; i++) cur = cur->next;

	process->env = get_values(cur, "env", &process->nenv);

	for(i = 0; i < process->nenv; i++) cur = cur->next;

	return 1;
}

int
parse_additionaldata(const xmlNode * cur, IDMEFadditionaldata *additionaldata) {
	const char *data;

	additionaldata->type = 
		get_additionaldata_type(get_attribute(cur, "type"));

	additionaldata->meaning = get_attribute_dup(cur, "meaning");

	data = get_value(cur);

	switch(additionaldata->type) {
	case IDMEF_BOOLEAN:
		additionaldata->data.data_boolean = get_boolean(data);
		break;
	case IDMEF_BYTE:
		/* avoid this type.  can't represent arbitrary
		 * byte values due to xml restriction on character references.
		 */
		additionaldata->data.data_byte = strdup(data);
		break;
	case IDMEF_CHARACTER:
		/* could confirm this is a single (UTF-8) char */
		additionaldata->data.data_character = strdup(data);
		break;
	case IDMEF_DATETIME:
		additionaldata->data.data_datetime = strdup(data);
		break;
	case IDMEF_INTEGER:
		additionaldata->data.data_integer = get_integer(data);
		break;
	case IDMEF_NTPSTAMP:
		additionaldata->data.data_ntpstamp = strdup(data);
		break;
	case IDMEF_PORTLIST:
		/* would be nice to parse portlist */
		additionaldata->data.data_portlist = strdup(data);
		break;
	case IDMEF_REAL:
		additionaldata->data.data_real = strdup(data);
		break;
	case IDMEF_STRING:
		additionaldata->data.data_string = strdup(data);
		break;
	case IDMEF_XML:
		additionaldata->data.data_xml = xmlCopyNodeList(cur->children);
		break;
	}

	return 1;
}

int
parse_classification(const xmlNode * cur, IDMEFclassification *classification) {
	int i, n;
	classification->ident = get_attribute_dup(cur, "ident");
	classification->text = get_attribute_dup(cur, "text");

	cur = cur->children;

	n = count_elements(cur, "Reference");

	if(n) {
		resize_list((void**)&classification->references,
			    &classification->references_capacity,
			    sizeof(classification->references[0]),
			    n);

		classification->nreferences = n;

		for(i = 0; i < n && cur; i++) {
			if(DEBUG) idmef_debug("(parse_classification) next element is %s -- calling parse_reference()",cur->name);
			classification->references[i] = new_reference();
			if(!parse_reference(cur, classification->references[i])) {
				idmef_error( "error parsing reference");
				return 0;
			}
			cur = cur->next;
		}
	}

	return 1;
}

int
parse_reference(const xmlNode * cur, IDMEFreference *reference) {
	reference->origin = 
		get_reference_origin(get_attribute(cur, "origin"));

	reference->meaning = 
		get_attribute_dup(cur, "meaning");

	cur = cur->children;
	if(!cur) return 0;          /* missing required "name" element */

	if(strcasecmp(cur->name, "name")) return 0; /* "name" elt must be first */

	reference->name = get_value_dup(cur);

	cur = cur->next;
	if(!cur) return 0;          /* missing required "url" element */

	if(strcasecmp(cur->name, "url")) return 0; /* "url" elt must be second */

	reference->url = get_value_dup(cur);

	return 1;
}

int
parse_impact(const xmlNode * cur, IDMEFimpact *impact) {
	impact->severity = 
		get_impact_severity(get_attribute(cur, "severity"));
	
	impact->completion = 
		get_impact_completion(get_attribute(cur, "completion"));

	impact->type = get_impact_type(get_attribute(cur, "type"));

	impact->data = get_value_dup(cur);

	return 1;
}

int
parse_action(const xmlNode * cur, IDMEFaction *action) {
	action->category = 
		get_action_category(get_attribute(cur, "category"));

	action->data = get_value_dup(cur);

	return 1;
};

int
parse_confidence(const xmlNode * cur, IDMEFconfidence *confidence) {
	confidence->rating = 
		get_confidence_rating(get_attribute(cur, "rating"));

	confidence->data = get_value_dup(cur);

	return 1;
};

int
parse_assessment(const xmlNode * cur, IDMEFassessment *assessment) {
	int n = 0, i = 0;

	cur = cur->children;
	if(!cur) return 1;

	if(!strcasecmp(cur->name, "Impact")) {
		if(DEBUG) idmef_debug("(parse_assessment) next element is %s -- calling parse_impact()",cur->name);
		assessment->impact = new_impact();
		if(!parse_impact(cur, assessment->impact)) {
			idmef_error( "error parsing Impact");
			return 0;
		}
		cur = cur->next;
	}

	if(!cur) return 1;

	n = count_elements(cur, "Action");

	if(n) {
		resize_list((void**)&assessment->actions,
			    &assessment->actions_capacity,
			    sizeof(assessment->actions[0]),
			    n);

		assessment->nactions = n;

		for(i = 0; i < n && cur; i++) {
			if(DEBUG) idmef_debug("(parse_assessment) next element is %s -- calling parse_action()",cur->name);
			assessment->actions[i] = new_action();
			if(!parse_action(cur, assessment->actions[i])) {
				idmef_error(
				"error parsing Action");
				return 0;
			}
			cur = cur->next;
		}
	}

	if(!cur) return 1;

	if(!strcasecmp(cur->name, "Confidence")) {
		if(DEBUG) idmef_debug("(parse_assessment) next element is %s -- calling parse_confidence()",cur->name);
		assessment->confidence = new_confidence();
		if(!parse_confidence(cur, assessment->confidence)) {
			idmef_error( "error parsing Confidence");
			return 0;
		}
		cur = cur->next;
	}

	return 1;
}

int
parse_node(const xmlNode * cur, IDMEFnode *node) {
	int i = 0, n = 0;

	node->ident = get_attribute_dup(cur, "ident");

	node->category = get_node_category(get_attribute(cur, "category"));

	cur = cur->children;
	if(!cur) return 0;          /* neither "name" nor "Address" present */

	if(!strcasecmp(cur->name, "location")) {
		node->location = get_value_dup(cur);
		cur = cur->next;
	}

	if(!strcasecmp(cur->name, "name")) {
		node->name = get_value_dup(cur);
		cur = cur->next;
	}

	if(!cur) return 1;

	n = count_elements(cur, "Address");

	if(n) {
		resize_list((void**)&node->addresses,
			    &node->addresses_capacity,
			    sizeof(node->addresses[0]),
			    n);

		node->naddresses = n;

		for(i = 0; i < n && cur; i++) {
			if(DEBUG) idmef_debug("(parse_node) next element is %s -- calling parse_address()",cur->name);
			node->addresses[i] = new_address();
			if(!parse_address(cur, node->addresses[i])) {
				idmef_error(
				"error parsing Address");
				return 0;
			}
			cur = cur->next;
		}
	}

	if(node->naddresses < 1 && !node->name) return 0; /* neither "name" nor "Address" present */

	return 1;
}

int
parse_webservice(const xmlNode * cur, IDMEFwebservice *webservice) {
	cur = cur->children;
	if(!cur) return 0;          /* missing required "url" element */
	
	if(!strcasecmp(cur->name, "url")) {
		webservice->url = get_value_dup(cur);
	}
	else return 0;              /* first element must be "url" */

	cur = cur->next;
	if(!cur) return 1;

	if(!strcasecmp(cur->name, "cgi")) {
		webservice->cgi = get_value_dup(cur);
		cur = cur->next;
		if(!cur) return 1;
	}

	if(!strcasecmp(cur->name, "http-method")) {
		webservice->http_method = get_value_dup(cur);
		cur = cur->next;
		if(!cur) return 1;
	}

	webservice->arg = get_values(cur, "arg", &webservice->narg);

	return 1;
}

int
parse_snmpservice(const xmlNode * cur, IDMEFSNMPservice *snmpservice) {
	cur = cur->children;

	if(!cur) return 1;

	if(!strcasecmp(cur->name, "oid")) {
		snmpservice->oid = get_value_dup(cur);
		cur = cur->next;
		if(!cur) return 1;
	}

	if(!strcasecmp(cur->name, "community")) {
		snmpservice->community = get_value_dup(cur);
		cur = cur->next;
		if(!cur) return 1;
	}

	if(!strcasecmp(cur->name, "command")) {
		snmpservice->command = get_value_dup(cur);
		cur = cur->next;
		if(!cur) return 1;
	}

	return 1;
}

int
parse_service(const xmlNode * cur, IDMEFservice *service) {
	const char * p = 0;

	service->ident = get_attribute_dup(cur, "ident");

	p = get_attribute(cur, "ip_version");
	if(p) service->ip_version = new_int(atoi(p));

	p = get_attribute(cur, "iana_protocol_number");
	if(p) service->iana_protocol_number = new_int(atoi(p));

	service->iana_protocol_name = 
		get_attribute_dup(cur, "iana_protocol_name");

	cur = cur->children;
	if(!cur) return 0;	/* name or port or portlist required */

	if(!strcasecmp(cur->name, "name")) {
		service->name = get_value_dup(cur);
		cur = cur->next;
		if(!cur) return 1;
	}

	if(!strcasecmp(cur->name, "port")) {
		p = get_value(cur);
		if(p) service->port = new_int(atoi(p));
		cur = cur->next;
		if(!cur) return 1;
	}

	/* need to check for 'name' again since name/port can come in either
	 * order */
	if(service->name == NULL && !strcasecmp(cur->name, "name")) {
		service->name = get_value_dup(cur);
		cur = cur->next;
		if(!cur) return 1;
	}

	if(!strcasecmp(cur->name, "portlist")) {
		service->portlist = get_value_dup(cur);
		cur = cur->next;
		if(!cur) return 1;
	}

	if(!service->name && !service->port && !service->portlist) return 0; /* need "name" or "port" or "portlist" */

	if(!strcasecmp(cur->name, "protocol")) {
		service->protocol = get_value_dup(cur);
		cur = cur->next;
		if(!cur) return 1;
	}

	if(!strcasecmp(cur->name, "SNMPService")) {
		if(DEBUG) idmef_debug("(parse_service) next element is %s -- calling parse_snmpservice()",cur->name);
		service->snmpservice = new_snmpservice();
		if(!parse_snmpservice(cur, service->snmpservice)) {
			idmef_error( "error parsing SNMPService");
			return 0;
		}
		cur = cur->next;
		if(!cur) return 1;
	}

	if(!strcasecmp(cur->name, "WebService")) {
		if(DEBUG) idmef_debug("(parse_service) next element is %s -- calling parse_webservice()",cur->name);
		service->webservice = new_webservice();
		if(!parse_webservice(cur, service->webservice)) {
			idmef_error( "error parsing WebService");
			return 0;
		}
		cur = cur->next;
		if(!cur) return 1;
	}

	return 1;
}

int
parse_linkage(const xmlNode * cur, IDMEFlinkage *linkage) {
	linkage->category = 
		get_linkage_category(get_attribute(cur, "category"));

	cur = cur->children;
	if(!cur) return 0;          /* need either "name" and "path" or "File" */

	if(!strcasecmp(cur->name, "name")) {
		linkage->name = get_value_dup(cur);
		cur = cur->next;
	}

	if(!cur) return 0;          /* need "path" with "name" */

	if(!strcasecmp(cur->name, "path")) {
		linkage->path = get_value_dup(cur);
		cur = cur->next;
	}

	if(linkage->name && linkage->path) {
		if(!cur) return 1;
		else return 0;          /* extra elements after name,path */
	}

	if(!cur) return 0;          /* need either "name" and "path" or "File" */

	if(!strcasecmp(cur->name, "File")) {
		if(!parse_file(cur, linkage->file)) {
			idmef_error( "error parsing File");
			return 0;
		}
		cur = cur->next;
	}

	if(linkage->file) return 1;

	if(!linkage->name || !linkage->path) return 0; /* need either "name" and "path" or "File" */

	return 1;
}

int
parse_inode(const xmlNode * cur, IDMEFinode *inode) {
	const char *p = 0;

	cur = cur->children;
	if(!cur) return 1;

	if(!strcasecmp(cur->name, "change-time")) {
		inode->change_time = get_value_dup(cur);
		cur = cur->next;
	}

	if(!cur) return 1;

	if(!strcasecmp(cur->name, "number")) {
		p = get_value(cur);
		inode->number = new_int(atoi(p));
		cur = cur->next;
	}
	
	if(!cur) return 0;          /* XXX only bad if number was given */

	if(!strcasecmp(cur->name, "major-device")) {
		p = get_value(cur);
		inode->major_device = new_int(atoi(p));
		cur = cur->next;
	}

	if(!cur) return 0;          /* XXX only bad if major-device was given */

	if(!strcasecmp(cur->name, "minor-device")) {
		p = get_value(cur);
		inode->minor_device = new_int(atoi(p));
		cur = cur->next;
	}

	if((inode->number || inode->major_device || inode->minor_device)
	   && !(inode->number && inode->major_device && inode->minor_device))
		return 0;	/* these three must appear together */

	if(!cur) return 1;

	if(!strcasecmp(cur->name, "c-major-device")) {
		p = get_value(cur);
		inode->c_major_device = new_int(atoi(p));
		cur = cur->next;
	}

	if(!cur) return 0; /* c-major-device and c-minor-device go together */

	if(!strcasecmp(cur->name, "c-minor-device")) {
		p = get_value(cur);
		inode->c_minor_device = new_int(atoi(p));
		cur = cur->next;
	}
	
	
	/* c-major-device and c-minor-device go together */
	if(!inode->c_major_device || !inode->c_minor_device) return 0;

	return 1;
}

int
parse_checksum(const xmlNode * cur, IDMEFchecksum *checksum) {
	checksum->algorithm = 
		get_checksum_algorithm(get_attribute(cur, "algorithm"));

	cur = cur->children;
	if(!cur) return 0;	/* missing required "value" */

	if(!strcasecmp(cur->name, "value")) {
		checksum->value = get_value_dup(cur);
		cur = cur->next;
	}

	if(!cur) return 1;

	if(!strcasecmp(cur->name, "key")) {
		checksum->key = get_value_dup(cur);
	}
	
	return 1;
}

int
parse_fileaccess(const xmlNode * cur, IDMEFfileaccess *fileaccess) {
	int i;

	cur = cur->children;
	if(!cur) return 0;          /* missing required "UserId" element */

	if(!strcasecmp(cur->name, "UserId")) {
		if(DEBUG) idmef_debug("(parse_fileaccess) next element is %s -- calling parse_userid()",cur->name);
		fileaccess->userid = new_userid();
		if(!parse_userid(cur, fileaccess->userid)) {
			idmef_error( "error parsing UserId");
			return 0;
		}
		cur = cur->next;
	}

	if(!cur) return 0;          /* missing required "permission" element */

	if (!fileaccess->userid
	    || (fileaccess->userid->type != IDMEF_USER_PRIVS
		&& fileaccess->userid->type != IDMEF_GROUP_PRIVS
		&& fileaccess->userid->type != IDMEF_OTHER_PRIVS)) {
		return 0; /* invalid userid type for FileAccess */
	}

	fileaccess->permissions = 
		get_values(cur, "permission", &fileaccess->npermissions);

	for(i = 0; i < fileaccess->npermissions; i++) cur = cur->next;

	if(!fileaccess->npermissions) return 0; /* missing required "permission" element */

	return 1;
}

int
parse_file(const xmlNode * cur, IDMEFfile *file) {
	int i = 0, n = 0;
	const char *p = 0;
	
	file->ident = get_attribute_dup(cur, "ident");

	p = get_attribute(cur, "category");
	if(!p) return 0;            /* missing required "category" attr */
	file->category = get_file_category(p);

	file->fstype = get_attribute_dup(cur, "fstype");

	cur = cur->children;

	if(cur && !strcasecmp(cur->name, "name")) {
		file->name = get_value_dup(cur);
		cur = cur->next;
	} else {
		return 0;               /* missing required "name" element */
	}

	if(cur && !strcasecmp(cur->name, "path")) {
		file->path = get_value_dup(cur);
		cur = cur->next;
	} else {
		return 0;               /* missing required "path" element */
	}

	if(!cur) return 1;

	if(!strcasecmp(cur->name, "create-time")) {
		file->create_time = get_value_dup(cur);
		cur = cur->next;
		if(!cur) return 1;
	}

	if(!strcasecmp(cur->name, "modify-time")) {
		file->modify_time = get_value_dup(cur);
		cur = cur->next;
		if(!cur) return 1;
	}

	if(!strcasecmp(cur->name, "access-time")) {
		file->access_time = get_value_dup(cur);
		cur = cur->next;
		if(!cur) return 1;
	}

	if(!strcasecmp(cur->name, "data-size")) {
		p = get_value(cur);
		file->data_size = new_int(atoi(p));
		cur = cur->next;
		if(!cur) return 1;
	}

	if(!strcasecmp(cur->name, "disk-size")) {
		p = get_value(cur);
		file->disk_size = new_int(atoi(p));
		cur = cur->next;
		if(!cur) return 1;
	}

	n = count_elements(cur, "FileAccess");

	if(n) {
		resize_list((void**)&file->fileaccesses,
			    &file->fileaccesses_capacity,
			    sizeof(file->fileaccesses[0]),
			    n);

		file->nfileaccesses = n;

		for(i = 0; i < n && cur; i++) {
			if(DEBUG) idmef_debug("(parse_file) next element is %s -- calling parse_fileaccess()",cur->name);
			file->fileaccesses[i] = new_fileaccess();
			if(!parse_fileaccess (cur, file->fileaccesses[i])) {
				idmef_error( "error parsing FileAccess");
				return 0;
			}
			cur = cur->next;
		}
	}

	if(!cur) return 1;

	n = count_elements(cur, "Linkage");

	if(n) {
		resize_list((void**)&file->linkages,
			    &file->linkages_capacity,
			    sizeof(file->linkages[0]),
			    n);
		file->nlinkages = n;

		for(i = 0; i < n && cur; i++) {
			if(DEBUG) idmef_debug("(parse_file) next element is %s -- calling parse_linkage()",cur->name);
			file->linkages[i] = new_linkage();
			if(!parse_linkage (cur, file->linkages[i])) {
				idmef_error( "error parsing FileAccess");
				return 0;
			}
			cur = cur->next;
		}
	}
	
	if(!cur) return 1;

	if(!strcasecmp(cur->name, "Inode")) {
		if(DEBUG) idmef_debug("(parse_file) next element is %s -- calling parse_inode()",cur->name);
		file->inode = new_inode();
		if(!parse_inode(cur, file->inode)) {
			idmef_error( "error parsing Inode");
			return 0;
		}
		cur = cur->next;
	}

	n = count_elements(cur, "Checksum");

	if(n) {
		resize_list((void**)&file->checksums,
			    &file->checksums_capacity,
			    sizeof(file->checksums[0]),
			    n);
		file->nchecksums = n;

		for(i = 0; i < n && cur; i++) {
			if(DEBUG) idmef_debug("(parse_file) next element is %s -- calling parse_checksum()",cur->name);
			file->checksums[i] = new_checksum();
			if(!parse_checksum (cur, file->checksums[i])) {
				idmef_error( "error parsing FileAccess");
				return 0;
			}
			cur = cur->next;
		}
	}
	return 1;
}

int
parse_filelist(const xmlNode * cur, IDMEFfilelist *filelist) {
	int i = 0, n = 0;

	cur = cur->children;
	if(!cur) return 0;          /* at least one "File" element required */

	n = count_elements(cur, "File");

	if(n) {
		resize_list((void**)&filelist->files,
			    &filelist->files_capacity,
			    sizeof(filelist->files[0]),
			    n);
		filelist->nfiles = n;

		for(i = 0; i < n && cur; i++) {
			if(DEBUG) idmef_debug("(parse_filelist) next element is %s -- calling parse_file()",cur->name);
			filelist->files[i] = new_file();
			if(!parse_file (cur, filelist->files[i])) {
				idmef_error( "error parsing FileList");
				return 0;
			}
			cur = cur->next;
		}
	}
	else return 0;              /* at least one "File" element required */

	return 1;
}

int
parse_target(const xmlNode * cur, IDMEFtarget *target) {
	const char *p = 0;
	
	target->ident = get_attribute_dup(cur, "ident");

	p = get_attribute(cur, "decoy");

	target->decoy = get_decoy(p);
		
	target->interface = get_attribute_dup(cur, "interface");

	cur = cur->children;
	if(!cur) return 1;

	if(!strcasecmp(cur->name, "Node")) {
		if(DEBUG) idmef_debug("(parse_target) next element is %s -- calling parse_node()",cur->name);
		target->node = new_node();
		if(!parse_node(cur, target->node)) {
			idmef_error( "error parsing Node");
			return 0;
		}
		cur = cur->next;
		if(!cur) return 1;
	}

	if(!strcasecmp(cur->name, "User")) {
		if(DEBUG) idmef_debug("(parse_target) next element is %s -- calling parse_user()",cur->name);
		target->user = new_user();
		if(!parse_user(cur, target->user)) {
			idmef_error( "error parsing User");
			return 0;
		}
		cur = cur->next;
		if(!cur) return 1;
	}

	if(!strcasecmp(cur->name, "Process")) {
		if(DEBUG) idmef_debug("(parse_target) next element is %s -- calling parse_process()",cur->name);
		target->process = new_process();
		if(!parse_process(cur, target->process)) {
			idmef_error( "error parsing Process");
			return 0;
		}
		cur = cur->next;
		if(!cur) return 1;
	}

	if(!strcasecmp(cur->name, "Service")) {
		if(DEBUG) idmef_debug("(parse_target) next element is %s -- calling parse_service()",cur->name);
		target->service = new_service();
		if(!parse_service(cur, target->service)) {
			idmef_error( "error parsing Service");
			return 0;
		}
		cur = cur->next;
		if(!cur) return 1;
	}

	if(!strcasecmp(cur->name, "FileList")) {
		if(DEBUG) idmef_debug("(parse_target) next element is %s -- calling parse_filelist()",cur->name);
		target->filelist = new_filelist();
		if(!parse_filelist(cur, target->filelist)) {
			idmef_error( "error parsing FileList");
			return 0;
		}
		cur = cur->next;
		if(!cur) return 1;
	}

	return 1;
}

int
parse_source(const xmlNode * cur, IDMEFsource *source) {
	source->ident = get_attribute_dup(cur, "ident");

	source->spoofed = get_spoofed(get_attribute(cur, "spoofed"));
		
	source->interface = get_attribute_dup(cur, "interface");

	cur = cur->children;
	if(!cur) return 1;

	if(!strcasecmp(cur->name, "Node")) {
		if(DEBUG) idmef_debug("(parse_source) next element is %s -- calling parse_node()",cur->name);
		source->node = new_node();
		if(!parse_node(cur, source->node)) {
			idmef_error( "error parsing Node");
			return 0;
		}
		cur = cur->next;
		if(!cur) return 1;
	}

	if(!strcasecmp(cur->name, "User")) {
		if(DEBUG) idmef_debug("(parse_source) next element is %s -- calling parse_user()",cur->name);
		source->user = new_user();
		if(!parse_user(cur, source->user)) {
			idmef_error( "error parsing User");
			return 0;
		}
		cur = cur->next;
		if(!cur) return 1;
	}

	if(!strcasecmp(cur->name, "Process")) {
		if(DEBUG) idmef_debug("(parse_source) next element is %s -- calling parse_process()",cur->name);
		source->process = new_process();
		if(!parse_process(cur, source->process)) {
			idmef_error( "error parsing Process");
			return 0;
		}
		cur = cur->next;
		if(!cur) return 1;
	}

	if(!strcasecmp(cur->name, "Service")) {
		if(DEBUG) idmef_debug("(parse_source) next element is %s -- calling parse_service()",cur->name);
		source->service = new_service();
		if(!parse_service(cur, source->service)) {
			idmef_error( "error parsing Service");
			return 0;
		}
		cur = cur->next;
		if(!cur) return 1;
	}

	return 1;
}

int
parse_analyzer(const xmlNode * cur, IDMEFanalyzer *analyzer) {
	analyzer->analyzerid = get_attribute_dup(cur, "analyzerid");

	analyzer->name = get_attribute_dup(cur, "name");

	analyzer->manufacturer = get_attribute_dup(cur, "manufacturer");

	analyzer->model = get_attribute_dup(cur, "model");

	analyzer->version = get_attribute_dup(cur, "version");

	analyzer->cls = get_attribute_dup(cur, "class");

	analyzer->ostype = get_attribute_dup(cur, "ostype");

	analyzer->osversion = get_attribute_dup(cur, "osversion");

	cur = cur->children;
	if(!cur) return 1;

	if(!strcasecmp(cur->name, "Node")) {
		if(DEBUG) idmef_debug("(parse_analyzer) next element is %s -- calling parse_node()",cur->name);
		analyzer->node = new_node();
		if(!parse_node(cur, analyzer->node)) {
			idmef_error( "error parsing Node");
			return 0;
		}
		cur = cur->next;
		if(!cur) return 1;
	}

	if(!strcasecmp(cur->name, "Process")) {
		if(DEBUG) idmef_debug("(parse_analyzer) next element is %s -- calling parse_process()",cur->name);
		analyzer->process = new_process();
		if(!parse_process(cur, analyzer->process)) {
			idmef_error( "error parsing Process");
			return 0;
		}
		cur = cur->next;
		if(!cur) return 1;
	}

	if(!strcasecmp(cur->name, "Analyzer")) {
		if(DEBUG) idmef_debug("(parse_analyzer) next element is %s -- calling parse_analyzer()",cur->name);
		analyzer->analyzer = new_analyzer();
		if(!parse_analyzer(cur, analyzer->analyzer)) {
			idmef_error( "error parsing Analyzer");
			return 0;
		}
	}

	return 1;
}

int
parse_alertident(const xmlNode * cur, IDMEFalertident *alertident) {
	alertident->data = get_value_dup(cur);
	alertident->analyzerid = get_attribute_dup(cur, "analyzerid");
	return 1;
}

int
parse_overflowalert(const xmlNode * cur, IDMEFoverflowalert *overflowalert) {
	const char *p = 0;

	cur = cur->children;
	if(!cur) return 0;          /* missing required "program" element */

	if(strcasecmp(cur->name, "program")) return 0; /* first element must be "program" */

	overflowalert->program = get_value_dup(cur);

	cur = cur->next;
	if(!cur) return 1;

	if(!strcasecmp(cur->name, "size")) {
		p = get_value(cur);
		if(p) overflowalert->size = new_int(atoi(p));
		cur = cur->next;
		if(!cur) return 1;
	}

	if(!strcasecmp(cur->name, "buffer")) {
		overflowalert->buffer = get_value_dup(cur);
		cur = cur->next;
		if(!cur) return 1;
	}


	return 1;
}

int
parse_toolalert(const xmlNode * cur, IDMEFtoolalert *toolalert) {
	int i = 0, n = 0;

	cur = cur->children;
	if(!cur) return 0;          /* missing required "name" element */

	if(strcasecmp(cur->name, "name")) return 0; /* missing required "name" element */

	toolalert->name = get_value_dup(cur);

	cur = cur->next;
	if(!cur) return 0;          /* at least one "alertident" element req'd */

	if(!strcasecmp(cur->name, "command")) {
		toolalert->command = get_value_dup(cur);
		cur = cur->next;
		if(!cur) return 0;      /* at least one "alertident" element req'd */
	}

	n = count_elements(cur, "alertident");

	if(!n) return 0;            /* at least one "alertident" element req'd */

	resize_list((void**)&toolalert->alertidents,
		    &toolalert->alertidents_capacity,
		    sizeof(toolalert->alertidents[0]),
		    n);
	toolalert->nalertidents = n;

	for(i = 0; i < n && cur; i++) {
		if(!strcasecmp(cur->name, "alertident")) {
			toolalert->alertidents[i] = new_alertident();
			parse_alertident(cur, toolalert->alertidents[i]);
		}

		cur = cur->next;
	}

	return 1;
}

int
parse_correlationalert(const xmlNode * cur,
		       IDMEFcorrelationalert *correlationalert) {

	int i = 0, n = 0;

	cur = cur->children;
	if(!cur) return 0;          /* missing required "name" element */

	if(strcasecmp(cur->name, "name")) return 0; /* first elt must be "name" */

	correlationalert->name = get_value_dup(cur);

	cur = cur->next;
	if(!cur) return 0;          /* at least one "alertident" required */

	n = count_elements(cur, "alertident");

	if(!n) return 0;            /* at least one "alertident" required */

	resize_list((void**)&correlationalert->alertidents,
		    &correlationalert->alertidents_capacity,
		    sizeof(correlationalert->alertidents[0]),
		    n);
	correlationalert->nalertidents = n;

	for(i = 0; i < n && cur; i++) {
		if(!strcasecmp(cur->name, "alertident")) {
			correlationalert->alertidents[i] = new_alertident();
			parse_alertident(cur, 
					 correlationalert->alertidents[i]);
		}

		cur = cur->next;
	}

	return 1;
}

int
parse_heartbeat(const xmlNode * cur, IDMEFheartbeat *heartbeat) {
	int n = 0, i = 0;

	heartbeat->messageid = get_attribute_dup(cur, "messageid");

	cur = cur->children;
	if(!cur) return 0;          /* missing required "Analyzer" element */

	/* Analyzer must appear here */
	if(strcasecmp(cur->name, "Analyzer")) return 0; /* "Analyzer" element must be first */

	if(DEBUG) idmef_debug("(parse_heartbeat) next element is %s -- calling parse_analyzer()",cur->name);
	heartbeat->analyzer = new_analyzer();
	if(!parse_analyzer(cur, heartbeat->analyzer)) {
		idmef_error( "error parsing Analyzer");
		return 0;
	}

	/* must return 0 since we didn't see CreateTime */
	cur = cur->next;
	if(!cur) return 0;          /* missing required "CreateTime" element */

	/* CreateTime must appear here */
	if(strcasecmp(cur->name, "CreateTime")) return 0; /* "CreateTime" element must be second */

	if(DEBUG) idmef_debug("(parse_heartbeat) next element is %s -- calling parse_time()",cur->name);
	heartbeat->createtime = new_time();
	parse_time(cur, heartbeat->createtime);

	cur = cur->next;
	if(!cur) return 1;

	if(!strcasecmp(cur->name, "AnalyzerTime")) {
		if(DEBUG) idmef_debug("(parse_heartbeat) next element is %s -- calling parse_time()",cur->name);
		heartbeat->analyzertime = new_time();
		if(!parse_time(cur, heartbeat->analyzertime)) {
			idmef_error( "error parsing AnalyzerTime");
			return 0;
		}
		cur = cur->next;
		if(!cur) return 1;
	}
		
	/* If we get here it must be AdditionalData */
	if(strcasecmp(cur->name, "AdditionalData")) return 0; /* unexpected element */

	n = count_elements(cur, "AdditionalData");

	if(n) {
		resize_list((void**)&heartbeat->additionaldatas,
			    &heartbeat->additionaldatas_capacity,
			    sizeof(heartbeat->additionaldatas[0]),
			    n);

		heartbeat->nadditionaldatas = n;

		for(i = 0; i < n && cur; i++) {
			if(DEBUG) idmef_debug("(parse_heartbeat) next element is %s -- calling parse_additionaldata()",cur->name);
			heartbeat->additionaldatas[i] = new_additionaldata();
			if(!parse_additionaldata
			(cur, heartbeat->additionaldatas[i])) {
				idmef_error(
				"error parsing AdditionalData");
				return 0;
			}
			cur = cur->next;
		}
	}

	return 1;
}

int
parse_alert(const xmlNode * cur, IDMEFalert *alert) {
	int n = 0, i = 0;

	alert->messageid = get_attribute_dup(cur, "messageid");

	cur = cur->children;
	if(!cur) return 0;          /* missing required "Analyzer" element */

	/* Analyzer must appear here */
	if(strcasecmp(cur->name, "Analyzer")) return 0; /* "Analyzer" element must be first */

	if(DEBUG) idmef_debug("(parse_alert) next element is %s -- calling parse_analyzer()",cur->name);
	alert->analyzer = new_analyzer();
	if(!parse_analyzer(cur, alert->analyzer)) {
		idmef_error( "error parsing Analyzer");
		return 0;
	}

	cur = cur->next;
	/* must return 0 since we didn't see CreateTime */
	if(!cur) return 0;          /* missing required "CreateTime" element */

	/* CreateTime must appear here */
	if(strcasecmp(cur->name, "CreateTime")) return 0; /* "CreateTime" element must be second */

	if(DEBUG) idmef_debug("(parse_alert) next element is %s -- calling parse_time()",cur->name);
	alert->createtime = new_time();
	parse_time(cur, alert->createtime);

	cur = cur->next;
	/* must return 0 since we didn't see Classification */
	if(!cur) return 0;          /* "Classification" element req'd */

	if(!strcasecmp(cur->name, "DetectTime")) {
		if(DEBUG) idmef_debug("(parse_alert) next element is %s -- calling parse_time()",cur->name);
		alert->detecttime = new_time();
		if(!parse_time(cur, alert->detecttime)) {
			idmef_error( "error parsing DetectTime");
			return 0;
		}
		cur = cur->next;
		if(!cur) return 0;      /* missing required "Classification" element */
	}

	if(!strcasecmp(cur->name, "AnalyzerTime")) {
		if(DEBUG) idmef_debug("(parse_alert) next element is %s -- calling parse_time()",cur->name);
		alert->analyzertime = new_time();
		if(!parse_time(cur, alert->analyzertime)) {
			idmef_error( "error parsing AnalyzerTime");
			return 0;
		}
		cur = cur->next;
		if(!cur) return 0;      /* missing required "Classification" element */
	}
		
	n = count_elements(cur, "Source");

	if(n) {
		resize_list((void**)&alert->sources,
			    &alert->sources_capacity,
			    sizeof(alert->sources[0]),
			    n);
		alert->nsources = n;

		for(i = 0; i < n && cur; i++) {
			if(DEBUG) idmef_debug("(parse_alert) next element is %s -- calling parse_source()",cur->name);
			alert->sources[i] = new_source();
			if(!parse_source(cur, alert->sources[i])) {
				idmef_error( "error parsing source");
				return 0;
			}
			cur = cur->next;
		}
	}

	/* must return 0 before here since we didn't see Classification */
	if(!cur) return 0;          /* missing required "Classification" element */

	n = count_elements(cur, "Target");

	if(n) {
		resize_list((void**)&alert->targets,
			    &alert->targets_capacity,
			    sizeof(alert->targets[0]),
			    n);
		alert->ntargets = n;

		for(i = 0; i < n && cur; i++) {
			if(DEBUG) idmef_debug("(parse_alert) next element is %s -- calling parse_target()",cur->name);
			alert->targets[i] = new_target();
			if(!parse_target(cur, alert->targets[i])) {
				idmef_error( "error parsing target");
				return 0;
			}
			cur = cur->next;
		}
	}

	/* must return 0 before here since we didn't see Classification */
	if(!cur) return 0;          /* missing required "Classification" element */

	/* Classification must appear here */
	if(strcasecmp(cur->name, "Classification")) return 0; /* missing required "Classification" element */

	alert->classification = new_classification();
	if(!parse_classification(cur, alert->classification)) {
		idmef_error( "error parsing Classification");
		return 0;
	}
	cur = cur->next;

	/* can return 1 here since the rest is optional */
	if(!cur) return 1;

	if(!strcasecmp(cur->name, "Assessment")) {
		if(DEBUG) idmef_debug("(parse_alert) next element is %s -- calling parse_assessment()",cur->name);
		alert->assessment = new_assessment();
		if(!parse_assessment(cur, alert->assessment)) {
			idmef_error( "error parsing Assessment");
			return 0;
		}
		cur = cur->next;
	}

	/* can return 1 here since the rest is optional */
	if(!cur) return 1;

	if(!strcasecmp(cur->name, "ToolAlert")) {
		if(DEBUG) idmef_debug("(parse_alert) next element is %s -- calling parse_toolalert()",cur->name);
		alert->toolalert = new_toolalert();
		if(!parse_toolalert(cur, alert->toolalert)) {
			idmef_error( "error parsing ToolAlert");
			return 0;
		}
		cur = cur->next;
	}

	/* can return 1 here since the rest is optional */
	if(!cur) return 1;

	if(!strcasecmp(cur->name, "OverflowAlert")) {
		if(DEBUG) idmef_debug("(parse_alert) next element is %s -- calling parse_overflowalert()",cur->name);
		alert->overflowalert = new_overflowalert();
		if(!parse_overflowalert(cur, alert->overflowalert)) {
			idmef_error( "error parsing OverflowAlert");
			return 0;
		}
		cur = cur->next;
	}

	/* can return 1 since the rest is optional */
	if(!cur) return 1;

	if(!strcasecmp(cur->name, "CorrelationAlert")) {
		if(DEBUG) idmef_debug("(parse_alert) next element is %s -- calling parse_correlationalert()",cur->name);
		alert->correlationalert = new_correlationalert();
		if(!parse_correlationalert(cur, alert->correlationalert)) {
			idmef_error( "error parsing CorrelationAlert");
			return 0;
		}
		cur = cur->next;
	}

	/* can return 1 since the rest is optional */
	if(!cur) return 1;

	/* If we get here it must be AdditionalData */
	if(strcasecmp(cur->name, "AdditionalData")) return 0; /* unexpected element */

	n = count_elements(cur, "AdditionalData");

	if(n) {
		resize_list((void**)&alert->additionaldatas,
			    &alert->additionaldatas_capacity,
			    sizeof(alert->additionaldatas[0]),
			    n);

		alert->nadditionaldatas = n;


		for(i = 0; i < n && cur; i++) {
			if(DEBUG) idmef_debug("(parse_alert) next element is %s -- calling parse_additionaldata()",cur->name);
			alert->additionaldatas[i] = new_additionaldata();
			if(!parse_additionaldata(cur, 
						 alert->additionaldatas[i])) {
				idmef_error(
				"error parsing AdditionalData");
				return 0;
			}
			cur = cur->next;
		}
	}

	return 1;
}

int
parse_message(const xmlNode * cur, IDMEFmessage *message) {
	int i, n;

	message->version = get_attribute_dup(cur, "version");

	cur = cur->children;
	/* the spec is unclear about whether or not a message with */
	/* no alerts or heartbeats is legal so I say it's illegal. */
	/* Correction: In draft 11 (July 8, 2004), at least,
	 * it's specified as 
	 *   <!ELEMENT IDMEF-Message                 (
	 *        (Alert | Heartbeat)*
	 *      )>
	 * which means an empty IDMEF-Message is legal.
	 */
	if(!cur) return 1;

	n = count_elements(cur, "Alert");

	if(n) {
		resize_list((void**)&message->alerts,
			    &message->alerts_capacity,
			    sizeof(message->alerts[0]),
			    n);

		message->nalerts = n;

		for(i = 0; i < n && cur; i++) {
			if(DEBUG) idmef_debug("(parse_message) next element is %s -- calling parse_alert()",cur->name);
			message->alerts[i] = new_alert();
			if(!parse_alert(cur, message->alerts[i])) {
				idmef_error( "error parsing alert");
				return 0;
			}
			cur = cur->next;
		}
	}

	if(!cur) return 1;

	n = count_elements(cur, "Heartbeat");

	if(n) {
		resize_list((void**)&message->heartbeats,
			    &message->heartbeats_capacity,
			    sizeof(message->heartbeats[0]),
			    n);

		message->nheartbeats = n;

		for(i = 0; i < n && cur; i++) {
			if(DEBUG) idmef_debug("(parse_message) next element is %s -- calling parse_heartbeat()",cur->name);
			message->heartbeats[i] = new_heartbeat();
			if(!parse_heartbeat(cur, message->heartbeats[i])) {
				idmef_error( "error parsing heartbeat");
				return 0;
			}
			cur = cur->next;
		}
	}

	return 1;
}

/*
** Name: free_XXX where XXX is an element type defined in the
** IDMEF message exchange format specification.  Types are in
** lowercase in all cases.
**
** Purpose: To free all the allocated memory associated with an
** an element of type XXX.
**
** Arguments: The element which you would like free
**
** Returns: void
**
** Notes:
**
*/

void
free_webservice(IDMEFwebservice *webservice) {
	int i;

	if(webservice->url) idmef_free(webservice->url);
	if(webservice->cgi) idmef_free(webservice->cgi);
	if(webservice->http_method) idmef_free(webservice->http_method);

	for(i = 0; i < webservice->narg; i++) {
		idmef_free(webservice->arg[i]);
	}

	if(webservice->arg) idmef_free(webservice->arg);

	idmef_free(webservice);
}

void
free_snmpservice(IDMEFSNMPservice *SNMPservice) {
	if(SNMPservice->oid)       idmef_free(SNMPservice->oid);
	if(SNMPservice->community) idmef_free(SNMPservice->community);
	if(SNMPservice->command)   idmef_free(SNMPservice->command);

	idmef_free(SNMPservice);
}

void
free_service(IDMEFservice *service) {
	if(service->ident)       idmef_free(service->ident);
	if(service->ip_version)  idmef_free(service->ip_version);
	if(service->iana_protocol_number) idmef_free(service->iana_protocol_number);
	if(service->iana_protocol_name)   idmef_free(service->iana_protocol_name);
	if(service->name)        idmef_free(service->name);
	if(service->port)        idmef_free(service->port);
	if(service->portlist)    idmef_free(service->portlist);
	if(service->protocol)    idmef_free(service->protocol);
	if(service->webservice)  free_webservice(service->webservice);
	if(service->snmpservice) free_snmpservice(service->snmpservice);

	idmef_free(service);
}

void
free_userid(IDMEFuserid *userid) {
	if(userid->ident) idmef_free(userid->ident);
	if(userid->name) idmef_free(userid->name);
	if(userid->number) idmef_free(userid->number);

	idmef_free(userid);
}

void
free_user(IDMEFuser *user) {
	int i;

	if(user->ident) idmef_free(user->ident);

	for(i = 0; i < user->nuserids; i++) {
		free_userid(user->userids[i]);
	}

	if(user->userids) idmef_free(user->userids);	

	idmef_free(user);	
}

void
free_time(IDMEFtime *time) {
	if(time->ntpstamp) idmef_free(time->ntpstamp);
	if(time->string) idmef_free(time->string);

	idmef_free(time);
}

void
free_address(IDMEFaddress *address) {
	if(address->ident) idmef_free(address->ident);
	if(address->vlan_name) idmef_free(address->vlan_name);
	if(address->vlan_num) idmef_free(address->vlan_num);
	if(address->address) idmef_free(address->address);
	if(address->netmask) idmef_free(address->netmask);

	idmef_free(address);
}

void
free_node(IDMEFnode *node) {
	int i;

	if(node->ident) idmef_free(node->ident);
	if(node->location) idmef_free(node->location);
	if(node->name) idmef_free(node->name);

	for(i = 0; i < node->naddresses; i++) {
		free_address(node->addresses[i]);
	}
	if(node->addresses) idmef_free(node->addresses);

	idmef_free(node);
}

void
free_process(IDMEFprocess *process) {
	int i;

	if(process->ident) idmef_free(process->ident);
	if(process->name) idmef_free(process->name);
	if(process->pid) idmef_free(process->pid);
	if(process->path) idmef_free(process->path);
	for(i = 0; i < process->narg; i++) idmef_free(process->arg[i]);
	if(process->arg) idmef_free(process->arg);
	for(i = 0; i < process->nenv; i++) idmef_free(process->env[i]);
	if(process->env) idmef_free(process->env);
	idmef_free(process);
}

void
free_fileaccess(IDMEFfileaccess *fileaccess) {
	int i;

	if(fileaccess->userid) free_userid(fileaccess->userid);

	for(i = 0; i < fileaccess->npermissions; i++) {
		idmef_free(fileaccess->permissions[i]);
	}

	if(fileaccess->permissions) idmef_free(fileaccess->permissions);

	idmef_free(fileaccess);
}

void
free_linkage(IDMEFlinkage *linkage) {
	if(linkage->name) idmef_free(linkage->name);
	if(linkage->path) idmef_free(linkage->path);

	if(linkage->file) free_file(linkage->file);

	idmef_free(linkage);
}

void
free_inode(IDMEFinode *inode) {
	if(inode->change_time) idmef_free(inode->change_time);
	if(inode->number) idmef_free(inode->number);
	if(inode->major_device) idmef_free(inode->major_device);
	if(inode->minor_device) idmef_free(inode->minor_device);
	if(inode->c_major_device) idmef_free(inode->c_major_device);
	if(inode->c_minor_device) idmef_free(inode->c_minor_device);

	idmef_free(inode);
}

void
free_checksum(IDMEFchecksum *checksum) {
	if(checksum->value) idmef_free(checksum->value);
	if(checksum->key) idmef_free(checksum->key);
	idmef_free(checksum);
}

void
free_file(IDMEFfile *file) {
	int i;

	if(file->ident) idmef_free(file->ident);
	if(file->fstype) idmef_free(file->fstype);
	if(file->name) idmef_free(file->name);
	if(file->path) idmef_free(file->path);
	if(file->create_time) idmef_free(file->create_time);
	if(file->modify_time) idmef_free(file->modify_time);
	if(file->access_time) idmef_free(file->access_time);
	if(file->data_size) idmef_free(file->data_size);
	if(file->disk_size) idmef_free(file->disk_size);

	for(i = 0; i < file->nfileaccesses; i++) {
		free_fileaccess(file->fileaccesses[i]);
	}

	if(file->fileaccesses) idmef_free(file->fileaccesses);	

	for(i = 0; i < file->nlinkages; i++) {
		free_linkage(file->linkages[i]);
	}

	if(file->linkages) idmef_free(file->linkages);	

	if(file->inode) free_inode(file->inode);

	for(i = 0; i < file->nchecksums; i++) {
		free_checksum(file->checksums[i]);
	}

	if(file->checksums) idmef_free(file->checksums);	

	idmef_free(file);
}

void
free_filelist(IDMEFfilelist *filelist) {
	int i;

	for(i = 0; i < filelist->nfiles; i++) {
		free_file(filelist->files[i]);
	}

	if(filelist->files) idmef_free(filelist->files);
	
	idmef_free(filelist);
}

void
free_source(IDMEFsource *source) {
	if(source->ident) idmef_free(source->ident);
	if(source->interface) idmef_free(source->interface);
	if(source->node) free_node(source->node);
	if(source->user) free_user(source->user);
	if(source->process) free_process(source->process);
	if(source->service) free_service(source->service);

	idmef_free(source);
}

void
free_target(IDMEFtarget *target) {
	if(target->ident) idmef_free(target->ident);
	if(target->interface) idmef_free(target->interface);
	if(target->node) free_node(target->node);
	if(target->user) free_user(target->user);
	if(target->process) free_process(target->process);
	if(target->service) free_service(target->service);
	if(target->filelist) free_filelist(target->filelist);

	idmef_free(target);
}

void
free_analyzer(IDMEFanalyzer *analyzer) {
	if(analyzer->analyzerid) idmef_free(analyzer->analyzerid);
	if(analyzer->name) idmef_free(analyzer->name);
	if(analyzer->manufacturer) idmef_free(analyzer->manufacturer);
	if(analyzer->model) idmef_free(analyzer->model);
	if(analyzer->version) idmef_free(analyzer->version);
	if(analyzer->cls) idmef_free(analyzer->cls);
	if(analyzer->ostype) idmef_free(analyzer->ostype);
	if(analyzer->osversion) idmef_free(analyzer->osversion);
	if(analyzer->node) free_node(analyzer->node);
	if(analyzer->process) free_process(analyzer->process);
	if(analyzer->analyzer) free_analyzer(analyzer->analyzer);

	idmef_free(analyzer);
}

void
free_alertident(IDMEFalertident *alertident) {
	if(alertident->data) idmef_free(alertident->data);
	if(alertident->analyzerid) idmef_free(alertident->analyzerid);

	idmef_free(alertident);
}

void
free_correlationalert(IDMEFcorrelationalert *correlationalert) {
	int i;

	if(correlationalert->name) idmef_free(correlationalert->name);

	for(i = 0; i < correlationalert->nalertidents; i++) {
		free_alertident(correlationalert->alertidents[i]);
	}
	if(correlationalert->alertidents) idmef_free(correlationalert->alertidents);

	idmef_free(correlationalert);
}

void
free_toolalert(IDMEFtoolalert *toolalert) {
	int i;

	if(toolalert->name) idmef_free(toolalert->name);
	if(toolalert->command) idmef_free(toolalert->command);

	for(i = 0; i < toolalert->nalertidents; i++) {
		free_alertident(toolalert->alertidents[i]);
	}
	if(toolalert->alertidents) idmef_free(toolalert->alertidents);

	idmef_free(toolalert);
}

void
free_overflowalert(IDMEFoverflowalert *overflowalert) {
	if(overflowalert->program) idmef_free(overflowalert->program);
	if(overflowalert->size) idmef_free(overflowalert->size);
	if(overflowalert->buffer) idmef_free(overflowalert->buffer);

	idmef_free(overflowalert);
}

void
free_additionaldata(IDMEFadditionaldata *additionaldata) {
	if(additionaldata->meaning) idmef_free(additionaldata->meaning);

	switch (additionaldata->type) {
	case IDMEF_BOOLEAN:
	case IDMEF_INTEGER:
		break;
	case IDMEF_BYTE:
		if (additionaldata->data.data_byte)
			idmef_free(additionaldata->data.data_byte);
		break;
	case IDMEF_CHARACTER:
		if (additionaldata->data.data_character)
			idmef_free(additionaldata->data.data_character);
		break;
	case IDMEF_DATETIME:
		if (additionaldata->data.data_datetime)
			idmef_free(additionaldata->data.data_datetime);
		break;
	case IDMEF_NTPSTAMP:
		if (additionaldata->data.data_ntpstamp)
			idmef_free(additionaldata->data.data_ntpstamp);
		break;
	case IDMEF_REAL:
		if (additionaldata->data.data_real)
			idmef_free(additionaldata->data.data_real);
		break;
	case IDMEF_PORTLIST:
		if (additionaldata->data.data_portlist)
			idmef_free(additionaldata->data.data_portlist);
		break;
	case IDMEF_STRING:
		if (additionaldata->data.data_string)
			idmef_free(additionaldata->data.data_string);
		break;
	case IDMEF_XML:
		if (additionaldata->data.data_xml)
			xmlFreeNodeList(additionaldata->data.data_xml);
		break;
	}
	idmef_free(additionaldata);
}

void
free_classification(IDMEFclassification *classification) {
	int i = 0;
	if(classification->ident) idmef_free(classification->ident);
	if(classification->text) idmef_free(classification->text);

	for(i = 0; i < classification->nreferences; i++)
		free_reference(classification->references[i]);

	if(classification->references) idmef_free(classification->references);

	idmef_free(classification);
}

void
free_reference(IDMEFreference *reference) {
	if(reference->meaning) idmef_free(reference->meaning);
	if(reference->name) idmef_free(reference->name);
	if(reference->url) idmef_free(reference->url);

	idmef_free(reference);
}

void
free_impact(IDMEFimpact *impact) {
	if(impact->data) idmef_free(impact->data);

	idmef_free(impact);
}

void
free_action(IDMEFaction *action) {
	if(action->data) idmef_free(action->data);

	idmef_free(action);
}

void
free_confidence(IDMEFconfidence *confidence) {
	if(confidence->data) idmef_free(confidence->data);

	idmef_free(confidence);
}

void
free_assessment(IDMEFassessment *assessment) {
	int i;

	if(assessment->impact) free_impact(assessment->impact);

	for(i = 0; i < assessment->nactions; i++)
		free_action(assessment->actions[i]);

	if(assessment->actions) idmef_free(assessment->actions);	

	if(assessment->confidence) free_confidence(assessment->confidence);

	idmef_free(assessment);
}

void
free_alert(IDMEFalert *alert) {
	int i;
	
	if(alert->messageid) idmef_free(alert->messageid);
	if(alert->analyzer) free_analyzer(alert->analyzer);
	if(alert->createtime) free_time(alert->createtime);
	if(alert->detecttime) free_time(alert->detecttime);
	if(alert->analyzertime) free_time(alert->analyzertime);
	
	for(i = 0; i < alert->nsources; i++) free_source(alert->sources[i]);
	
	if(alert->sources) idmef_free(alert->sources);
	
	for(i = 0; i < alert->ntargets; i++) free_target(alert->targets[i]);
	
	if(alert->targets) idmef_free(alert->targets);
	
	if(alert->classification) free_classification(alert->classification);
	
	if(alert->assessment) free_assessment(alert->assessment);

	for(i = 0; i < alert->nadditionaldatas; i++) {
		free_additionaldata(alert->additionaldatas[i]);
	}
	if(alert->additionaldatas) idmef_free(alert->additionaldatas);
	
	if(alert->correlationalert)
		free_correlationalert(alert->correlationalert);
	
	if(alert->toolalert) free_toolalert(alert->toolalert);

	if(alert->overflowalert) free_overflowalert(alert->overflowalert);

	idmef_free(alert);
}

void
free_heartbeat(IDMEFheartbeat *heartbeat) {
	int i;
	
	if(heartbeat->messageid) idmef_free(heartbeat->messageid);
	if(heartbeat->analyzer) free_analyzer(heartbeat->analyzer);
	if(heartbeat->createtime) free_time(heartbeat->createtime);
	if(heartbeat->analyzertime) free_time(heartbeat->analyzertime);
	
	for(i = 0; i < heartbeat->nadditionaldatas; i++) {
		free_additionaldata(heartbeat->additionaldatas[i]);
	}
	if(heartbeat->additionaldatas) idmef_free(heartbeat->additionaldatas);

	idmef_free(heartbeat);
}

void
free_message(IDMEFmessage *message) {
	int i;

	if(message->version) idmef_free(message->version);

	for(i = 0; i < message->nalerts; i++) {
		free_alert(message->alerts[i]);
	}

	if(message->alerts) idmef_free(message->alerts);

	for(i = 0; i < message->nheartbeats; i++) {
		free_heartbeat(message->heartbeats[i]);
	}

	if(message->heartbeats) idmef_free(message->heartbeats);

	idmef_free(message);
}

/*
** Name: get_idmef_message_from_doc
**
** Purpose: Creates an IDMEFmessage structure from an xmlDocPtr.
**
** Arguments: The xmlDocPtr, and a flag indicating whether to
**            validate the document against the IDMEF DTD before
**            parsing.
**
** Returns: A pointer to a newly allocated IDMEFmessage structure,
**          or NULL on failure.
**          Caller should free the returned structure with free_message().
**
*/

IDMEFmessage *
get_idmef_message_from_doc(xmlDocPtr doc, int validate) {
	IDMEFmessage *message = 0;
	const xmlNode * cur;

	if(!(cur = xmlDocGetRootElement(doc))) {
		idmef_error( "get_idmef_message_from_doc(): error: xmlDocGetRootElement()");
		return 0;
	}
	
	if(validate && validateDoc(NULL, doc) == 0) {
		idmef_error( "get_idmef_message_from_doc(): XML validation failure");
		return 0;
	}

	if(xmlStrcmp(cur->name, "IDMEF-Message")) {
		idmef_error( "get_idmef_message_from_doc(): not a valid IDMEF-Message (root element \"%s\")", 
				cur->name);
		return 0;
	}

	message = new_message();

	if(!parse_message(cur, message)) {
		idmef_error( "not a valid IDMEF-Message");
		free_message(message);
		message = 0;
	}

	return message;
}


/*
** Name: get_idmef_message_from_file
**
** Purpose: Creates an IDMEFmessage structure from one IDMEF message
** found in a file.
**
** Arguments: The name of the file containing the message, and a flag
**            indicating whether to validate the document against the
**            IDMEF DTD before parsing.
**
** Returns: A pointer to a newly allocated IDMEFmessage structure,
**          or NULL on failure.
**          Caller should free the returned structure with free_message().
*/

IDMEFmessage *
get_idmef_message_from_file(const char *filename, int validate) {

	IDMEFmessage *message;

	xmlDocPtr doc;

        xmlKeepBlanksDefault(0);

	if(!(doc = xmlParseFile(filename))) {
		idmef_error( "error: xmlParseFile()");
		return 0;
	}
	message = get_idmef_message_from_doc(doc, validate);
	xmlFreeDoc(doc);
	return message;
}

/*
** Name: get_idmef_message
**
** Purpose: Creates an IDMEFmessage structure from one IDMEF message
** found in the given chunk of memory.
**
** Arguments: The buffer containing the message, the size of that
**            buffer, and a flag indicating whether to validate the
**            document against the IDMEF DTD before parsing.
**
**
** Returns: A pointer to a newly allocated IDMEFmessage structure,
**          or NULL on failure.
**          Caller should free the returned structure with free_message().
**
*/

IDMEFmessage *
get_idmef_message(const char *buffer, int size, int validate) {

	IDMEFmessage *message;

	xmlDocPtr doc;

        xmlKeepBlanksDefault(0);

	if(!(doc = xmlParseMemory(buffer, size))) {
		idmef_error( "error: xmlParseMemory()");
		return 0;
	}

	message = get_idmef_message_from_doc(doc, validate);
	xmlFreeDoc(doc);
	return message;
}

/* Make emacs handle 8-column indentation used in this file:
 * Local Variables:
 * c-basic-offset:8
 * indent-tabs-mode:t
 * tab-width:8
 * End: */
